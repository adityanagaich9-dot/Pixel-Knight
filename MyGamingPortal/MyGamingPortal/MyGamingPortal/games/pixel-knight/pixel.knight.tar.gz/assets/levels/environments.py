"""Reusable palette and ambience data for each campaign environment."""

ENVIRONMENTS = {
    "forest": {
        "sky": ((13, 19, 43), (37, 49, 74)),
        "surface": (49, 91, 73), "glow": (119, 202, 215),
        "particles": ((167, 226, 175), (244, 231, 155)), "weather": "firefly",
    },
    "catacombs": {
        "sky": ((19, 17, 34), (65, 48, 66)),
        "surface": (79, 74, 89), "glow": (170, 123, 201),
        "particles": ((176, 157, 188), (113, 91, 133)), "weather": "dust",
    },
    "crystal": {
        "sky": ((14, 31, 66), (61, 80, 128)),
        "surface": (60, 85, 114), "glow": (101, 224, 248),
        "particles": ((113, 230, 250), (194, 150, 248)), "weather": "shards",
    },
    "village": {
        "sky": ((68, 35, 43), (190, 91, 56)),
        "surface": (96, 67, 59), "glow": (255, 151, 63),
        "particles": ((255, 143, 59), (255, 207, 113)), "weather": "embers",
    },
    "fields": {
        "sky": ((74, 116, 159), (241, 194, 116)),
        "surface": (144, 131, 68), "glow": (255, 218, 127),
        "particles": ((237, 204, 120), (207, 221, 158)), "weather": "leaves",
    },
    "kingdom": {
        "sky": ((58, 52, 92), (207, 124, 93)),
        "surface": (83, 84, 98), "glow": (247, 166, 114),
        "particles": ((231, 192, 145), (159, 170, 197)), "weather": "dust",
    },
    "ember": {
        "sky": ((26, 20, 34), (127, 47, 38)),
        "surface": (77, 54, 52), "glow": (255, 119, 52),
        "particles": ((255, 124, 54), (193, 147, 130)), "weather": "embers",
    },
    "drowned": {
        "sky": ((9, 36, 59), (33, 104, 123)),
        "surface": (49, 93, 99), "glow": (100, 218, 220),
        "particles": ((142, 228, 231), (101, 177, 204)), "weather": "bubbles",
    },
    "abyss": {
        "sky": ((11, 9, 31), (61, 29, 82)),
        "surface": (55, 47, 76), "glow": (190, 118, 239),
        "particles": ((190, 118, 239), (121, 157, 241)), "weather": "wisp",
    },
    "throne": {
        "sky": ((15, 14, 32), (83, 37, 62)),
        "surface": (66, 51, 71), "glow": (201, 124, 176),
        "particles": ((180, 107, 206), (255, 140, 80)), "weather": "wisp",
    },
}
