"""The Sunken Catacombs stage layout."""

NAME = "SUNKEN CATACOMBS"
THEME = "catacombs"
SLIME_STYLE = "purple"

PLATFORMS = [
    # A broad entrance hall narrows into alternating shelves over the trench.
    (300, 350, 4), (520, 310, 3), (760, 350, 4), (1010, 286, 4),
    (1290, 330, 4), (1560, 270, 3), (1810, 310, 4), (2080, 350, 4),
    (2360, 294, 4), (2660, 260, 4), (2960, 330, 4), (3240, 280, 4),
    (3440, 340, 3),
]

# Short raised patches break up the flat valley floor.
# (left, top y, width)
RAISED_GROUND = [
    (832, 416, 64), (1216, 416, 64), (1984, 416, 96), (3040, 416, 64),
]

COINS = [
    (190, 390), (345, 305), (565, 265), (805, 305),
    (1055, 241), (1335, 285), (1605, 225), (1855, 265),
    (2125, 305), (2405, 249), (2710, 215), (3005, 285),
    (3280, 235), (3460, 295),
]

BUSHES = []

# Ground patrols and slimes guarding high mossy ledges.
ENEMIES = [
    (640, 412, 580, 710), (1040, 258, 1014, 1138),
    (1330, 302, 1294, 1418), (1840, 282, 1814, 1938),
    (2380, 266, 2364, 2488), (3000, 302, 2974, 3098),
    (3290, 252, 3254, 3380),
]


# Ancient shore crawlers patrol the lower ruins.
CRABS = [
    (830, 322, 804, 918), (2680, 232, 2664, 2788),
]


# Armored bone guards patrol the old temple bridges.
BONE_GUARDS = [
    (1610, 242, 1564, 1668), (2390, 266, 2364, 2488),
]

# (left, baseline_y, width, spike_height); some traps sit on floating ledges.
HAZARDS = [
    (440, 440, 56, 20), (1160, 440, 48, 18),
    (1760, 440, 44, 18), (2810, 440, 48, 20),
]

PITS = [
    (900, 128), (1480, 140), (2150, 430), (2790, 132), (3180, 128),
]

MOVING_PLATFORMS = [
    # A lift crosses the long central chasm; short cuts remain jumpable.
    (2154, 2488, 386, 96, 88),
]

BACKDROP_PROPS = [
    (430, 440, "broken_crate", 2), (1120, 440, "crystal", 2),
    (1850, 440, "broken_crate", 2), (2980, 440, "crystal", 2),
]
SCENERY_PROPS = [
    (690, 440, "mushroom_teal", 2), (1360, 440, "sign", 2),
    (2020, 440, "mushroom_purple", 2), (2990, 440, "broken_crate", 2),
]
