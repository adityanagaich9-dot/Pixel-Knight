"""Playable stage layouts for Pixel Knight."""

from . import level1, level2
from .campaign import build_campaign_level
from .boss_arenas import BOSS_ARENAS


CAMPAIGN_ORDER = (1, 2, 3, 11, 4, 5, 6, 7, 8, 9, 10, 12)
BOSS_LEVEL_IDS = frozenset((11, 12))


LEVELS = {
    1: level1,
    2: level2,
}


def get_level(number):
    """Return a campaign traversal stage or a standalone boss arena."""
    if number in LEVELS:
        return LEVELS[number]
    if number in BOSS_ARENAS:
        return BOSS_ARENAS[number]
    if 3 <= number <= 10:
        return build_campaign_level(number)
    return level1


def next_level(number):
    """Return the next stage in the story sequence, or None after the finale."""
    try:
        index = CAMPAIGN_ORDER.index(number)
    except ValueError:
        return None
    return CAMPAIGN_ORDER[index + 1] if index + 1 < len(CAMPAIGN_ORDER) else None
