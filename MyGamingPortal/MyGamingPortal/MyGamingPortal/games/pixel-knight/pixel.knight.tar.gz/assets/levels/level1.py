"""The Forgotten Forest vertical slice."""

NAME = "THE FORGOTTEN FOREST"
THEME = "forest"

PLATFORMS = [
    # Low stepping ledges lead into the first lookout, then gradually climb.
    (360, 350, 4), (650, 292, 3), (900, 365, 4), (1210, 315, 4),
    (1510, 260, 4), (1770, 350, 4), (2100, 300, 4), (2420, 350, 4),
    (2700, 270, 4), (3020, 330, 4), (3320, 285, 4),
    # Optional canopy route branches above the second clearing and reconnects.
    (1870, 220, 3), (1980, 176, 3), (2090, 210, 3),
]

COINS = [
    (220, 390), (400, 305), (710, 245),
    (970, 320), (1050, 390), (1260, 265), (1560, 210),
    (1850, 305), (2180, 255), (2490, 305), (2760, 225),
    (3080, 285), (3380, 240),
    (1900, 178), (2000, 134), (2070, 134),
    (3210, 246),
]

BUSHES = []
BACKDROP_PROPS = [
    (80, 440, "tree", 2), (820, 440, "tree", 2),
    (1660, 440, "tree", 2), (2350, 440, "tree", 2), (3160, 440, "tree", 2),
]
SCENERY_PROPS = [
    (250, 440, "mushroom_gold", 2), (785, 440, "bush", 2),
    (1360, 440, "mushroom_cream", 2), (2190, 440, "mushroom_gold", 2),
    (3030, 440, "bush", 2), (3400, 440, "mushroom_cream", 2),
]

ENEMIES = [
    (912, 337, 900, 970),
    (1135, 412, 1100, 1210),
    (1965, 412, 1910, 2070),
    (2860, 412, 2800, 2990),
]

FLYING_ENEMIES = []  # Keep Bats out of the first-stage introduction.

BONE_GUARDS = [
    (2495, 398, 2440, 2605),
]

# Three optional-looking crossings and an upper route make the forest road
# teach dashes, double jumps, and moving-platform timing gradually.
PITS = [
    (980, 150),
    (2035, 142),
    (2820, 176),
]

MOVING_PLATFORMS = [
    (994, 1054, 386, 96, 54),
    (2044, 2100, 386, 96, 58),
    (2828, 2904, 386, 96, 62),
]

HAZARDS = [
    (730, 440, 44, 18),
    (1830, 440, 50, 18),
    (2360, 440, 48, 18),
    (3160, 440, 52, 18),
]

RAISED_GROUND = [
    (2280, 416, 160),
]

# Ground-mounted crossbow turrets replace the old wooden lookout structures.
TURRETS = [
    (554, 440),
    (1704, 440),
    (2624, 440),
]


# Falling stones mark the exposed clearings in the forest.
FALLING_ROCKS = [
    # x, landing_y, delay, spawn_bottom_y
    (1100, 440, 0.8, -112),
    (1790, 440, 2.2, -112),
    (2290, 440, 3.6, -112),
    (2890, 440, 5.0, -112),
]
