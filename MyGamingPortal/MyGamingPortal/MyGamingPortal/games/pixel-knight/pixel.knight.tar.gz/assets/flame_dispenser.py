"""Visible automatic flame-dispenser hazard for Pixel Knight."""
import math
import pygame


class FlameDispenser:
    COOLDOWN = 5.0
    WARNING_TIME = 1.05
    BEAM_TIME = 0.72

    def __init__(self, x, platform_top):
        self.x = float(x)
        self.platform_top = int(platform_top)
        self.width = 28
        self.height = 34
        self.rect = pygame.Rect(
            round(self.x - self.width // 2),
            self.platform_top - self.height // 2,
            self.width,
            self.height,
        )
        # The body is deliberately half sunk into the platform.
        self.body_rect = pygame.Rect(
            round(self.x - 14), self.platform_top - 28, 28, 40
        )
        self.timer = 2.2
        self.beam_timer = 0.0
        self.flash = 0.0
        self.phase = 0.0

    @property
    def warning(self):
        return 0 < self.timer <= self.WARNING_TIME and self.beam_timer <= 0

    @property
    def firing(self):
        return self.beam_timer > 0

    def update(self, dt):
        self.phase += dt
        self.flash = max(0.0, self.flash - dt)
        if self.beam_timer > 0:
            self.beam_timer -= dt
            if self.beam_timer <= 0:
                self.timer = self.COOLDOWN
            return

        self.timer -= dt
        if self.timer <= 0:
            self.beam_timer = self.BEAM_TIME
            self.flash = 0.12

    def beam_rect(self, beam_top=0):
        # Narrow central column, from above the dispenser to the platform top.
        return pygame.Rect(
            round(self.x - 11), beam_top, 22, max(1, self.platform_top - beam_top)
        )

    def damages(self, player_rect, beam_top=0):
        if not self.firing:
            return False
        beam = self.beam_rect(beam_top)
        return beam.colliderect(player_rect)

    def draw(self, screen, camera, beam_top=0):
        r = camera.apply(self.body_rect)
        cx = r.centerx
        top = r.top

        # Warning light pulses before firing.
        pulse = (math.sin(self.phase * 12.0) + 1.0) * 0.5
        if self.warning:
            radius = 8 + round(pulse * 5)
            pygame.draw.circle(screen, (255, 78, 35), (cx, top + 4), radius, 2)

        # Vertical beam.
        if self.firing:
            beam_world = self.beam_rect(beam_top)
            b = camera.apply(beam_world)
            glow = pygame.Surface((max(30, b.width * 3), b.height), pygame.SRCALPHA)
            glow_x = glow.get_width() // 2
            pygame.draw.rect(glow, (255, 72, 20, 55), (glow_x - 12, 0, 24, b.height))
            pygame.draw.rect(glow, (255, 154, 38, 105), (glow_x - 6, 0, 12, b.height))
            screen.blit(glow, (b.centerx - glow.get_width() // 2, b.top))
            pygame.draw.rect(screen, (255, 235, 150), (b.centerx - 3, b.top, 6, b.height))
            pygame.draw.line(screen, (255, 255, 230), (b.centerx, b.top), (b.centerx, b.bottom), 2)

        # Base, half embedded into the platform.
        pygame.draw.rect(screen, (35, 29, 30), r.inflate(4, 2), border_radius=3)
        pygame.draw.rect(screen, (74, 47, 40), (r.x + 3, r.y + 4, r.width - 6, r.height - 5), border_radius=2)
        pygame.draw.rect(screen, (115, 65, 45), (r.x + 6, r.y + 7, r.width - 12, 10), border_radius=2)
        pygame.draw.rect(screen, (29, 28, 32), (r.x + 6, r.y + 17, r.width - 12, 13), border_radius=2)
        pygame.draw.circle(screen, (255, 112, 32) if self.firing else (196, 68, 32), (cx, r.y + 12), 5)
        pygame.draw.circle(screen, (255, 220, 106), (cx, r.y + 12), 2)
        pygame.draw.rect(screen, (170, 104, 51), (r.x - 5, r.bottom - 8, r.width + 10, 8), border_radius=2)
