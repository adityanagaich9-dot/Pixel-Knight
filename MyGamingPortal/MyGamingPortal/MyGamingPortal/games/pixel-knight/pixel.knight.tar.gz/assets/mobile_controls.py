"""Large translucent touchscreen controls for the mobile layout."""

import pygame


class MobileControls:
    """A compact multi-touch gamepad drawn over the lower screen edge."""

    BUTTONS = {
        "left": pygame.Rect(22, 440, 76, 76),
        "down": pygame.Rect(204, 444, 72, 72),
        "right": pygame.Rect(116, 440, 76, 76),
        "ability": pygame.Rect(530, 444, 72, 72),
        "shield": pygame.Rect(620, 444, 72, 72),
        "attack": pygame.Rect(710, 430, 82, 82),
        "dash": pygame.Rect(803, 444, 72, 72),
        "jump": pygame.Rect(878, 414, 76, 82),
    }

    ORDER = ("down", "left", "right", "ability", "shield", "attack", "dash", "jump")
    COLORS = {
        "left": (75, 161, 187),
        "right": (75, 161, 187),
        "down": (75, 161, 187),
        "ability": (210, 130, 60),
        "shield": (91, 164, 183),
        "attack": (196, 121, 65),
        "dash": (112, 155, 198),
        "jump": (193, 165, 91),
    }

    def hit_test(self, position):
        for name in self.ORDER:
            if self.BUTTONS[name].collidepoint(position):
                return name
        return None

    def draw(self, screen, font, active=(), roll_ready=None):
        active = set(active)
        for name in self.ORDER:
            rect = self.BUTTONS[name]
            color = self.COLORS[name]
            pressed = name in active
            layer = pygame.Surface(rect.size, pygame.SRCALPHA)
            alpha = 192 if pressed else 112
            pygame.draw.ellipse(layer, (*color, alpha), layer.get_rect())
            pygame.draw.ellipse(layer, (245, 225, 174, 225 if pressed else 145), layer.get_rect(), 2)
            pygame.draw.ellipse(layer, (16, 22, 29, 155), layer.get_rect().inflate(-10, -10), 1)
            self._draw_icon(layer, name, pressed)
            screen.blit(layer, rect.topleft)
            if name == "down" and roll_ready is not None:
                caption = font.render("ROLL" if roll_ready else "FALL", True, (246, 238, 210))
                screen.blit(caption, (rect.centerx - caption.get_width() // 2, rect.bottom - 17))
            elif name == "ability":
                caption = font.render("SKILL", True, (246, 238, 210))
                screen.blit(caption, (rect.centerx - caption.get_width() // 2, rect.bottom - 17))

    @staticmethod
    def _draw_icon(surface, name, pressed):
        w, h = surface.get_size()
        cx, cy = w // 2, h // 2
        ink = (255, 247, 218) if pressed else (232, 226, 203)
        if name in ("left", "right", "down"):
            if name == "left":
                points = [(cx - 13, cy), (cx + 9, cy - 15), (cx + 9, cy + 15)]
            elif name == "right":
                points = [(cx + 13, cy), (cx - 9, cy - 15), (cx - 9, cy + 15)]
            else:
                points = [(cx, cy + 13), (cx - 15, cy - 9), (cx + 15, cy - 9)]
            pygame.draw.polygon(surface, ink, points)
        elif name == "jump":
            pygame.draw.polygon(surface, ink, [(cx, cy - 16), (cx - 15, cy + 2), (cx + 15, cy + 2)])
            pygame.draw.rect(surface, ink, (cx - 5, cy, 10, 17))
        elif name == "attack":
            pygame.draw.line(surface, ink, (cx - 17, cy + 12), (cx + 17, cy - 12), 5)
            pygame.draw.line(surface, (255, 206, 115), (cx + 10, cy - 19), (cx + 21, cy - 19), 2)
            pygame.draw.line(surface, (255, 206, 115), (cx + 17, cy - 25), (cx + 17, cy - 13), 2)
        elif name == "dash":
            for offset in (-11, 0, 11):
                pygame.draw.line(surface, ink, (cx - 15, cy + offset), (cx + 12, cy + offset), 3)
            pygame.draw.polygon(surface, ink, [(cx + 17, cy), (cx + 7, cy - 8), (cx + 7, cy + 8)])
        elif name == "shield":
            points = [(cx - 13, cy - 15), (cx + 13, cy - 15), (cx + 11, cy + 5), (cx, cy + 17), (cx - 11, cy + 5)]
            pygame.draw.polygon(surface, ink, points, 3)
            pygame.draw.line(surface, ink, (cx, cy - 9), (cx, cy + 10), 2)
        elif name == "ability":
            # Star/Rune burst icon for skill
            pygame.draw.circle(surface, (255, 215, 80), (cx, cy), 9)
            pygame.draw.circle(surface, ink, (cx, cy), 5)
            for ang in (0, 1.57, 3.14, 4.71):
                import math
                px = cx + math.cos(ang) * 15
                py = cy + math.sin(ang) * 15
                pygame.draw.line(surface, (255, 220, 100), (cx, cy), (px, py), 2)
