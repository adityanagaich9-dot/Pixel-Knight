"""Animated falling-rock trap used by selected Pixel Knight levels."""
import pygame


class FallingRock:
    FALL_SPEED = 560.0
    FALL_FRAME_TIME = 0.075
    IMPACT_FRAME_TIME = 0.085
    IMPACT_TIME = 0.42
    RESET_DELAY = 1.8

    def __init__(self, x, target_y, fall_frames, impact_frames, delay=0.0, spawn_y=-48):
        self.x = float(x)
        self.target_y = int(target_y)
        self.spawn_y = int(spawn_y)
        self.fall_frames = fall_frames
        self.impact_frames = impact_frames
        self.width = 112
        self.height = 112
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = round(self.x)
        self.rect.bottom = self.target_y
        self.state = "waiting"
        self.timer = -float(delay)
        self.frame_timer = 0.0
        self.frame = 0
        self.damage_done = False

    @property
    def active(self):
        return self.state in ("falling", "impact")

    def _start_fall(self):
        self.state = "falling"
        self.rect.centerx = round(self.x)
        self.rect.bottom = self.spawn_y
        self.frame = 0
        self.frame_timer = 0.0
        self.damage_done = False

    def update(self, dt):
        if self.state == "waiting":
            self.timer += dt
            if self.timer >= 0:
                self._start_fall()
            return

        if self.state == "falling":
            self.rect.y += round(self.FALL_SPEED * dt)
            self.frame_timer += dt
            while self.frame_timer >= self.FALL_FRAME_TIME:
                self.frame_timer -= self.FALL_FRAME_TIME
                self.frame += 1
                if self.frame >= len(self.fall_frames):
                    self.frame = len(self.fall_frames) - 1

            if self.rect.bottom >= self.target_y:
                self.rect.bottom = self.target_y
                self.state = "impact"
                self.frame = 0
                self.frame_timer = 0.0
            return

        if self.state == "impact":
            self.frame_timer += dt
            while self.frame_timer >= self.IMPACT_FRAME_TIME:
                self.frame_timer -= self.IMPACT_FRAME_TIME
                self.frame += 1
                if self.frame >= len(self.impact_frames):
                    self.state = "waiting"
                    self.timer = -self.RESET_DELAY
                    self.frame = 0
                    self.frame_timer = 0.0
                    return

    def damage_rect(self):
        # Only the rock itself hurts, not the long falling trail.
        if not self.active:
            return pygame.Rect(0, 0, 0, 0)
        if self.state == "impact":
            return pygame.Rect(self.rect.centerx - 34, self.target_y - 36, 68, 36)
        return pygame.Rect(self.rect.centerx - 22, self.rect.bottom - 42, 44, 42)

    def draw(self, screen, camera):
        if self.state == "waiting":
            return
        frames = self.fall_frames if self.state == "falling" else self.impact_frames
        image = frames[self.frame]
        screen_rect = camera.apply(self.rect)
        screen.blit(
            image,
            (
                screen_rect.centerx - image.get_width() // 2,
                screen_rect.bottom - image.get_height() + (7 if self.state == "impact" else 0),
            ),
        )
