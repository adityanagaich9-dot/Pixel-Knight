"""Pixel-art title screen and options panel for Pixel Knight."""

import math
import random

import pygame

from settings import WIDTH, HEIGHT, GOLD


class Menu:
    PANEL_WIDTH = 356

    def __init__(self, font, title_font, assets=None, micro_font=None, touch_controls_enabled=False):
        self.font = font
        self.title_font = title_font
        self.micro_font = micro_font or font
        self.assets = assets
        self.settings_open = False
        self.explore_mode = False
        self.music_enabled = True
        self.touch_controls_enabled = bool(touch_controls_enabled)
        self.control_slider_dragging = False
        self.continue_available = False
        self.focus_index = 0
        self.settings_focus = 0
        self.selected_hero = "knight"
        self.hero_rect = pygame.Rect(834, 20, 108, 108)

        self.main_buttons = [
            pygame.Rect(34, 190, 278, 48),
            pygame.Rect(34, 248, 278, 48),
            pygame.Rect(34, 306, 278, 48),
            pygame.Rect(34, 364, 278, 48),
        ]
        self.music_rect = pygame.Rect(34, 194, 278, 52)
        self.explore_rect = pygame.Rect(34, 264, 278, 52)
        self.controls_rect = pygame.Rect(34, 326, 278, 52)
        self.back_rect = pygame.Rect(34, 398, 278, 48)
        self.particles = [
            [random.randrange(370, WIDTH), random.randrange(24, HEIGHT - 20),
             random.choice((-1, 1)), random.uniform(0.18, 0.55), random.choice((1, 1, 2))]
            for _ in range(24)
        ]
        self.last_particle_tick = pygame.time.get_ticks()

    def handle_click(self, position):
        if self.settings_open:
            if self.music_rect.collidepoint(position):
                self.music_enabled = not self.music_enabled
                return "music"
            if self.explore_rect.collidepoint(position) and not self.continue_available:
                self.explore_mode = not self.explore_mode
                return "mode"
            if self.controls_rect.collidepoint(position):
                self.control_slider_dragging = True
                return self._set_touch_mode_from_x(position[0])
            if self.back_rect.collidepoint(position):
                self.settings_open = False
                self.control_slider_dragging = False
                return "back"
            return None

        for index, rect in enumerate(self.main_buttons):
            if rect.collidepoint(position):
                self.focus_index = index
                return self._main_action(index)
        if self.hero_rect.collidepoint(position):
            return "heroes"
        return None

    def _mode_track_rect(self):
        return pygame.Rect(self.controls_rect.left + 104, self.controls_rect.centery - 4, 151, 8)

    def _set_touch_mode_from_x(self, x):
        enabled = x < self._mode_track_rect().centerx
        if enabled == self.touch_controls_enabled:
            return None
        self.touch_controls_enabled = enabled
        return "controls"

    def handle_pointer_motion(self, position):
        if self.settings_open and self.control_slider_dragging:
            return self._set_touch_mode_from_x(position[0])
        return None

    def end_pointer(self):
        self.control_slider_dragging = False

    def handle_key(self, key):
        if self.settings_open:
            if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.settings_open = False
                return "back"
            if key in (pygame.K_UP, pygame.K_w):
                self.settings_focus = (self.settings_focus - 1) % 4
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.settings_focus = (self.settings_focus + 1) % 4
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                if self.settings_focus == 0:
                    self.music_enabled = not self.music_enabled
                    return "music"
                if self.settings_focus == 1:
                    if not self.continue_available:
                        self.explore_mode = not self.explore_mode
                        return "mode"
                    return None
                if self.settings_focus == 2:
                    self.touch_controls_enabled = not self.touch_controls_enabled
                    return "controls"
                self.settings_open = False
                self.control_slider_dragging = False
                return "back"
            return None

        if key in (pygame.K_UP, pygame.K_w):
            self._move_focus(-1)
        elif key in (pygame.K_DOWN, pygame.K_s):
            self._move_focus(1)
        elif key in (pygame.K_h, pygame.K_v):
            return "heroes"
        elif key in (pygame.K_RETURN, pygame.K_SPACE):
            return self._main_action(self.focus_index)
        return None

    def _move_focus(self, direction):
        for _ in self.main_buttons:
            self.focus_index = (self.focus_index + direction) % len(self.main_buttons)
            if self.focus_index != 1 or self.continue_available:
                break

    def _main_action(self, index):
        if index == 0:
            return "play"
        if index == 1:
            return "continue" if self.continue_available else None
        if index == 2:
            self.settings_open = True
            self.settings_focus = 0
            return "settings"
        if index == 3:
            return "quit"
        return None

    def draw(self, screen, world=None):
        self._draw_backdrop(screen, world)
        self._draw_pixel_panel(screen)
        self._draw_knight(screen)
        self._draw_particles(screen)
        if self.settings_open:
            self._draw_settings(screen)
        else:
            self._draw_title(screen)
            self._draw_hero_icon(screen)

    def _draw_backdrop(self, screen, world):
        if world is not None:
            world.draw_background(screen, 0)
        else:
            top, bottom = (25, 75, 115), (42, 117, 139)
            for y in range(0, HEIGHT, 8):
                amount = y / HEIGHT
                color = tuple(round(top[i] + (bottom[i] - top[i]) * amount) for i in range(3))
                pygame.draw.rect(screen, color, (0, y, WIDTH, 8))
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((8, 13, 27, 92))
        screen.blit(veil, (0, 0))

    def _draw_pixel_panel(self, screen):
        panel = pygame.Surface((self.PANEL_WIDTH, HEIGHT), pygame.SRCALPHA)
        panel.fill((27, 31, 61, 246))
        for row, y in enumerate(range(12, HEIGHT, 30)):
            offset = 0 if row % 2 == 0 else 17
            pygame.draw.line(panel, (43, 46, 78, 150), (12, y), (self.PANEL_WIDTH - 10, y), 1)
            for x in range(20 + offset, self.PANEL_WIDTH - 15, 72):
                pygame.draw.line(panel, (41, 45, 76, 130), (x, y - 18), (x, y), 1)
        screen.blit(panel, (0, 0))
        pygame.draw.rect(screen, (13, 20, 34), (0, 0, self.PANEL_WIDTH, HEIGHT), 3)
        pygame.draw.line(screen, (100, 91, 68), (8, 8), (self.PANEL_WIDTH - 11, 8), 2)
        pygame.draw.line(screen, (14, 20, 32), (8, HEIGHT - 9), (self.PANEL_WIDTH - 11, HEIGHT - 9), 2)
        for y in range(0, HEIGHT, 4):
            x = 347 + round(math.sin(y * 0.006) * 7)
            pygame.draw.rect(screen, (194, 159, 82), (x, y, 2, 4))
            pygame.draw.rect(screen, (45, 47, 62), (x + 3, y, 1, 4))
        for x, y in ((12, 12), (self.PANEL_WIDTH - 28, 12), (12, HEIGHT - 25),
                     (self.PANEL_WIDTH - 28, HEIGHT - 25)):
            pygame.draw.rect(screen, (207, 173, 100), (x, y, 12, 12))
            pygame.draw.rect(screen, (77, 68, 53), (x + 4, y + 4, 4, 4))

    def _draw_title(self, screen):
        self._center(screen, self.title_font, "PIXEL", 46, GOLD, shadow=True)
        self._center(screen, self.title_font, "KNIGHT", 91, (244, 222, 167), shadow=True)
        self._center(screen, self.font, "A DARK FANTASY QUEST", 143, (203, 207, 172))
        self._draw_rune_line(screen, 164)
        labels = ("NEW GAME", "CONTINUE", "OPTIONS", "QUIT")
        mouse = pygame.mouse.get_pos()
        for index, (rect, label) in enumerate(zip(self.main_buttons, labels)):
            enabled = index != 1 or self.continue_available
            self._draw_button(screen, rect, label,
                              active=(index == self.focus_index or rect.collidepoint(mouse)),
                              enabled=enabled)
        self._center(screen, self.micro_font, "UP / DOWN  SELECT", 440, (184, 190, 167))
        self._center(screen, self.micro_font, "ENTER / SPACE  CONFIRM", 462, (145, 156, 147))
        hint = "CONTINUE RESUMES THIS RUN" if self.continue_available else "START A RUN TO ENABLE CONTINUE"
        self._center(screen, self.micro_font, hint, 494, (124, 139, 143))

    def _draw_settings(self, screen):
        self._center(screen, self.title_font, "OPTIONS", 73, GOLD, shadow=True)
        self._center(screen, self.font, "GAME SETTINGS", 127, (203, 207, 172))
        self._draw_rune_line(screen, 151)
        mouse = pygame.mouse.get_pos()
        self._draw_button(screen, self.music_rect,
                          "MUSIC   [ ON ]" if self.music_enabled else "MUSIC   [ OFF ]",
                          active=(self.settings_focus == 0 or self.music_rect.collidepoint(mouse)))
        explore_locked = self.continue_available
        explore_label = ("EXPLORE   [ LOCKED ]" if explore_locked else
                         "EXPLORE   [ ON ]" if self.explore_mode else "EXPLORE   [ OFF ]")
        self._draw_button(screen, self.explore_rect, explore_label,
                          active=(self.settings_focus == 1 or self.explore_rect.collidepoint(mouse)),
                          enabled=not explore_locked)
        self._draw_mode_slider(screen, mouse)
        self._draw_button(screen, self.back_rect, "RETURN",
                          active=(self.settings_focus == 3 or self.back_rect.collidepoint(mouse)))
        hint = "SLIDE TO CHOOSE TOUCH BUTTONS OR PC KEYS"
        self._center(screen, self.micro_font, hint, 466, (184, 190, 167))
        self._center(screen, self.micro_font, "ESC  RETURN", 489, (145, 156, 147))

    def _draw_hero_icon(self, screen):
        rect = self.hero_rect
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(screen, (8, 13, 23), rect.move(4, 5))
        pygame.draw.rect(screen, (34, 46, 57), rect)
        pygame.draw.rect(screen, GOLD if hovered else (104, 127, 131), rect, 2)
        pygame.draw.rect(screen, (16, 25, 35), rect.inflate(-8, -8), 1)
        label = self.micro_font.render("HERO", True, GOLD)
        screen.blit(label, label.get_rect(center=(rect.centerx, rect.top + 12)))
        if self.assets:
            from hero_sprites import create_hero_frames
            from heroes import get_hero
            hero_obj = get_hero(self.selected_hero)
            frames = create_hero_frames(self.assets, self.selected_hero)["idle"]
            frame = frames[(pygame.time.get_ticks() // 320) % len(frames)]
            portrait = pygame.transform.scale(frame, (56, 56))
            screen.blit(portrait, portrait.get_rect(center=(rect.centerx, rect.top + 51)))
            caption = self.micro_font.render(hero_obj.name.split()[0], True, (218, 229, 211))
            screen.blit(caption, caption.get_rect(center=(rect.centerx, rect.bottom - 13)))
        if hovered:
            pygame.draw.rect(screen, (150, 222, 176), rect.inflate(2, 2), 1)

    def _draw_mode_slider(self, screen, mouse):
        rect = self.controls_rect
        pygame.draw.rect(screen, (12, 17, 29), rect.move(4, 5))
        pygame.draw.rect(screen, (95, 72, 49), rect)
        pygame.draw.rect(screen, (228, 205, 160), rect.inflate(-4, -4))
        active = self.settings_focus == 2 or rect.collidepoint(mouse)
        pygame.draw.rect(screen, (244, 223, 176), rect.inflate(-9, -9), 1)
        label = self.micro_font.render("CONTROL", True, (48, 43, 40))
        screen.blit(label, (rect.left + 12, rect.centery - label.get_height() // 2))
        track = self._mode_track_rect()
        pygame.draw.rect(screen, (59, 58, 51), track, border_radius=4)
        pygame.draw.rect(screen, (167, 130, 70), track, 1, border_radius=4)
        touch_x = track.left + 7
        pc_x = track.right - 7
        knob_x = touch_x if self.touch_controls_enabled else pc_x
        pygame.draw.circle(screen, (38, 49, 49), (knob_x, track.centery + 1), 11)
        pygame.draw.circle(screen, (247, 220, 158) if active else (231, 211, 167), (knob_x, track.centery), 8)
        touch_color = (38, 47, 42) if self.touch_controls_enabled else (96, 78, 52)
        pc_color = (38, 47, 42) if not self.touch_controls_enabled else (96, 78, 52)
        touch_label = self.micro_font.render("TOUCH", True, touch_color)
        pc_label = self.micro_font.render("PC", True, pc_color)
        screen.blit(touch_label, (rect.left + 115, rect.bottom - 13))
        screen.blit(pc_label, (rect.left + 213, rect.bottom - 13))
        if active:
            pygame.draw.rect(screen, GOLD, rect.inflate(2, 2), 1)

    def _draw_knight(self, screen):
        if not self.assets or not getattr(self.assets, "idle_frames", None):
            return
        from hero_sprites import create_hero_frames
        frames = create_hero_frames(self.assets, self.selected_hero)["idle"]
        index = (pygame.time.get_ticks() // 360) % len(frames)
        hero = pygame.transform.scale(frames[index], (320, 320))
        center_x, ground_y = 682, 448
        pygame.draw.rect(screen, (15, 28, 36), (center_x - 90, ground_y, 180, 22))
        pygame.draw.rect(screen, (88, 127, 73), (center_x - 90, ground_y, 180, 5))
        pygame.draw.rect(screen, (150, 125, 76), (center_x - 90, ground_y + 5, 180, 2))
        for x in range(center_x - 82, center_x + 82, 24):
            pygame.draw.rect(screen, (48, 58, 49), (x, ground_y + 10, 12, 3))
        screen.blit(hero, (center_x - hero.get_width() // 2, ground_y - hero.get_height()))

    def _draw_particles(self, screen):
        now = pygame.time.get_ticks()
        dt = min(40, now - self.last_particle_tick) / 1000.0
        self.last_particle_tick = now
        for particle in self.particles:
            x, y, direction, speed, size = particle
            y -= speed * 9.0 * dt
            x += direction * speed * 2.0 * dt
            if y < 20:
                y = HEIGHT - 24
                x = random.randrange(self.PANEL_WIDTH + 24, WIDTH - 12)
            particle[0], particle[1] = x, y
            pygame.draw.rect(screen, (142, 176, 158), (round(x), round(y), size, size))

    def _draw_button(self, screen, rect, label, active=False, enabled=True):
        pygame.draw.rect(screen, (12, 17, 29), rect.move(4, 5))
        pygame.draw.rect(screen, (95, 72, 49), rect)
        fill = (228, 205, 160) if enabled else (137, 132, 119)
        if active and enabled:
            fill = (245, 222, 174)
        pygame.draw.rect(screen, fill, rect.inflate(-4, -4))
        pygame.draw.rect(screen, (244, 223, 176) if enabled else (163, 153, 130), rect.inflate(-9, -9), 1)
        pygame.draw.line(screen, (248, 231, 193), (rect.left + 9, rect.top + 5),
                         (rect.right - 9, rect.top + 5), 1)
        color = (48, 43, 40) if enabled else (84, 81, 75)
        self._center_in_rect(screen, self.font, label, rect, color)
        if active and enabled:
            pygame.draw.rect(screen, GOLD, rect.inflate(2, 2), 1)

    @staticmethod
    def _draw_rune_line(screen, y):
        pygame.draw.line(screen, (111, 105, 77), (52, y), (130, y), 2)
        pygame.draw.line(screen, (111, 105, 77), (226, y), (304, y), 2)
        pygame.draw.rect(screen, GOLD, (43, y - 3, 6, 6))
        pygame.draw.rect(screen, GOLD, (307, y - 3, 6, 6))
        pygame.draw.polygon(screen, GOLD, [(178, y - 7), (185, y), (178, y + 7), (171, y)])
        pygame.draw.rect(screen, (52, 61, 63), (176, y - 2, 4, 4))

    @staticmethod
    def _center(screen, font, text, y, color, shadow=False):
        image = font.render(text, True, color)
        x = WIDTH // 2 - image.get_width() // 2
        top = y - image.get_height() // 2
        if shadow:
            shade = font.render(text, True, (18, 22, 36))
            screen.blit(shade, (x + 3, top + 4))
        screen.blit(image, (x, top))

    @staticmethod
    def _center_in_rect(screen, font, text, rect, color):
        image = font.render(text, True, color)
        screen.blit(image, (rect.centerx - image.get_width() // 2,
                            rect.centery - image.get_height() // 2))
