import pygame
from heroes import get_hero


def tint_surface(surface, tint_color):
    """Multiplies or colorizes the sprite with an ethereal tint while keeping alphas."""
    if tint_color is None:
        return surface.copy()
    copy = surface.copy()
    tint = pygame.Surface(copy.get_size(), pygame.SRCALPHA)
    tint.fill((*tint_color, 255))
    copy.blit(tint, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    # Give it an extra soft glowing rim
    glow = pygame.Surface(copy.get_size(), pygame.SRCALPHA)
    glow.fill((*tint_color, 45))
    copy.blit(glow, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
    return copy


def create_hero_frames(assets, hero_id):
    """Returns a full set of animation frames for the specified hero."""
    hero_def = get_hero(hero_id)
    base_type = getattr(hero_def, "base_hero", "knight")
    tint = getattr(hero_def, "sprite_tint", None)

    # Base animation sourcing
    if base_type == "archer":
        idle = assets.archer_idle_frames
        walk = assets.archer_walk_frames
        run = assets.archer_run_frames
        attack = assets.archer_bow_frames
        multi = assets.archer_multi_frames
        defend = assets.archer_defend_frames
        jump = assets.archer_jump_frames
        hurt = assets.archer_hurt_frames
        skill = assets.archer_dash_frames
        roll = assets.archer_dash_frames
    elif base_type == "choco":
        idle = assets.choco_idle_frames
        walk = assets.choco_walk_frames
        run = assets.choco_run_frames
        attack = assets.choco_shoot_frames
        multi = None
        defend = assets.choco_idle_frames
        jump = assets.choco_jump_frames
        hurt = assets.choco_hurt_frames
        skill = assets.choco_run_frames
        roll = assets.choco_run_frames
    else:  # Knight base or generic melee
        idle = assets.idle_frames
        walk = getattr(assets, "walk_frames", assets.run_frames)
        run = assets.run_frames
        attack = getattr(assets, "attack_frames", assets.run_frames)
        multi = None
        defend = getattr(assets, "defend_frames", assets.idle_frames)
        jump = getattr(assets, "jump_frames", assets.run_frames)
        hurt = getattr(assets, "hurt_frames", assets.idle_frames)
        skill = getattr(assets, "skill_frames", assets.run_frames)
        roll = getattr(assets, "roll_frames", assets.run_frames)

    # If this hero has a specific palette tint, apply it seamlessly across all frames
    if tint:
        return {
            "idle": [tint_surface(f, tint) for f in idle],
            "walk": [tint_surface(f, tint) for f in walk],
            "run": [tint_surface(f, tint) for f in run],
            "attack": [tint_surface(f, tint) for f in attack],
            "multi": [tint_surface(f, tint) for f in multi] if multi else None,
            "defend": [tint_surface(f, tint) for f in defend],
            "jump": [tint_surface(f, tint) for f in jump],
            "hurt": [tint_surface(f, tint) for f in hurt],
            "skill": [tint_surface(f, tint) for f in skill],
            "roll": [tint_surface(f, tint) for f in roll],
        }

    return {
        "idle": idle,
        "walk": walk,
        "run": run,
        "attack": attack,
        "multi": multi,
        "defend": defend,
        "jump": jump,
        "hurt": hurt,
        "skill": skill,
        "roll": roll,
    }
