"""Stage layouts, scrolling scenery, hazards, and platform rendering."""

import math
import pygame

from settings import WORLD_WIDTH, GROUND_Y, TILE
from levels import get_level
from levels.environments import ENVIRONMENTS
from moving_platform import MovingPlatform
from flame_dispenser import FlameDispenser


TERRAIN_COLUMNS = {
    "forest": 0, "catacombs": 8, "crystal": 6, "village": 5,
    "fields": 2, "kingdom": 3, "ember": 5, "drowned": 7,
    "abyss": 8, "throne": 5,
}


class World:
    def __init__(self, assets, level_number=1):
        self.assets = assets
        self.level_number = level_number
        self.layout = get_level(level_number)
        self.name = self.layout.NAME
        self.boss_arena = getattr(self.layout, "BOSS_ARENA", None)
        self.world_width = (
            self.boss_arena[1] if self.boss_arena
            else getattr(self.layout, "WORLD_WIDTH", WORLD_WIDTH)
        )
        self.boss_arena_active = False
        terrain_column = TERRAIN_COLUMNS.get(self.layout.THEME, 0)
        self.tile_ground, terrain_fill = assets.terrain_tiles[terrain_column]
        self.ground_fill_tiles = [terrain_fill]
        wall_tints = {
            "forest": (65, 88, 62), "catacombs": (78, 83, 100),
            "crystal": (58, 92, 112), "village": (103, 73, 61),
            "fields": (96, 92, 56), "kingdom": (70, 77, 94),
            "ember": (112, 64, 50), "drowned": (58, 102, 110),
            "abyss": (72, 54, 99), "throne": (76, 46, 79),
        }
        tint = wall_tints.get(self.layout.THEME, (65, 88, 62))
        self.wall_fill_tiles = []
        for source in self.ground_fill_tiles:
            tile = source.copy()
            tile.fill((*tint, 255), special_flags=pygame.BLEND_RGBA_MULT)
            self.wall_fill_tiles.append(tile)
        self.wall_accent = {
            "forest": (107, 145, 83), "catacombs": (129, 142, 111),
            "crystal": (103, 204, 206), "village": (176, 116, 68),
            "fields": (183, 161, 77), "kingdom": (133, 139, 127),
            "ember": (202, 112, 58), "drowned": (91, 171, 157),
            "abyss": (142, 99, 179), "throne": (166, 93, 126),
        }.get(self.layout.THEME, (107, 145, 83))
        self.platform_top = self.tile_ground
        self.backdrop_props = getattr(self.layout, "BACKDROP_PROPS", [])
        self.scenery_props = getattr(self.layout, "SCENERY_PROPS", [])
        self.prop_images = {}
        for _, _, prop_name, scale in (*self.backdrop_props, *self.scenery_props):
            key = (prop_name, scale)
            if key not in self.prop_images:
                source = assets.world_props[prop_name]
                self.prop_images[key] = pygame.transform.scale(
                    source, (source.get_width() * scale, source.get_height() * scale)
                )
        self.pits = getattr(self.layout, "PITS", [])
        self.platforms = self._ground_segments()
        self.raised_ground = [
            pygame.Rect(x, y, width, 24)
            for x, y, width in getattr(self.layout, "RAISED_GROUND", [])
        ]
        self.platforms.extend(self.raised_ground)
        self.platforms.extend(self._platform_rect(platform) for platform in self.layout.PLATFORMS)
        self.turret_spawns = list(getattr(self.layout, "TURRETS", []))
        self.moving_platforms = [
            MovingPlatform(*values)
            for values in getattr(self.layout, "MOVING_PLATFORMS", [])
        ]
        self.platforms.extend(platform.rect for platform in self.moving_platforms)

        self.coins = [
            pygame.Rect(x, y, 20, 20)
            for x, y in self.layout.COINS
        ]
        self.candy_stashes = [
            pygame.Rect(x, y, 26, 26)
            for x, y in getattr(self.layout, "CANDY_STASHES", [])
        ]
        goal_x = self.boss_arena[1] - 96 if self.boss_arena else self.world_width - 120
        self.goal = pygame.Rect(goal_x, GROUND_Y - 96, 40, 96)
        self.bushes = self.layout.BUSHES
        self.enemy_spawns = self.layout.ENEMIES
        self.crab_spawns = getattr(self.layout, "CRABS", [])
        self.bone_guard_spawns = getattr(self.layout, "BONE_GUARDS", [])
        self.flying_enemy_spawns = getattr(self.layout, "FLYING_ENEMIES", [])
        self.demon_spawns = getattr(self.layout, "DEMONS", [])
        self.boss_spawn = getattr(self.layout, "BOSS", None)
        self.storm_orb_spawns = getattr(self.layout, "STORM_ORBS", [])
        self.fire_wisp_spawns = getattr(self.layout, "FIRE_WISPS", [])
        self.hazard_visuals = getattr(self.layout, "HAZARDS", [])
        self.crystal_flash_timer = 0.0
        self.crystal_flash_x = -10000
        self.hazards = [
            pygame.Rect(x, base_y - height + 4, width, height + 2)
            for x, base_y, width, height in self.hazard_visuals
        ]

        # Automatic flame-dispenser placements.  A level can override these
        # with FLAME_DISPENSERS=[(x, platform_top_y), ...].  Otherwise we pick
        # safe-looking ground/raised platforms so every chapter gets the hazard.
        custom_dispensers = getattr(self.layout, "FLAME_DISPENSERS", None)
        if self.level_number in (1, 5):
            # Peaceful + Cold levels use falling rocks instead of flame dispensers.
            dispenser_positions = []
        elif custom_dispensers is not None:
            dispenser_positions = custom_dispensers
        else:
            # Flame dispensers are ground-mounted only. Never place them on
            # floating/raised platforms.
            candidates = [
                r for r in self.platforms
                if r.width >= 80 and r.top == GROUND_Y and r.height > 100
            ]
            candidates.sort(key=lambda r: r.left)
            dispenser_positions = []
            last_x = -9999
            for rect in candidates:
                x = rect.centerx
                if x >= 620 and x - last_x >= 700:
                    dispenser_positions.append((x, GROUND_Y))
                    last_x = x

        self.flame_dispensers = [
            FlameDispenser(x, top_y)
            for x, top_y in dispenser_positions
        ]

    @staticmethod
    def _platform_rect(platform):
        x, y = platform[:2]
        tile_count = platform[2] if len(platform) > 2 else 4
        return pygame.Rect(x, y, TILE * tile_count, 24)

    def _ground_segments(self):
        segments = []
        ground_start = 0
        for pit_x, pit_width in sorted(self.pits):
            if pit_x > ground_start:
                segments.append(
                    pygame.Rect(
                        ground_start,
                        GROUND_Y,
                        pit_x - ground_start,
                        400,
                    )
                )
            ground_start = max(ground_start, pit_x + pit_width)

        if ground_start < self.world_width:
            segments.append(
                pygame.Rect(
                    ground_start,
                    GROUND_Y,
                    self.world_width - ground_start,
                    400,
                )
            )
        return segments

    def update(self, dt, player=None):
        self.crystal_flash_timer = max(0.0, self.crystal_flash_timer - dt)
        for dispenser in self.flame_dispensers:
            dispenser.update(dt)

        for moving_platform in self.moving_platforms:
            moving_platform.update(dt)
            if (
                player is not None
                and player.standing_platform is moving_platform.rect
            ):
                # Carry a grounded knight along with the platform this frame.
                player.rect.x += moving_platform.delta_x

    def react_to_attack(self, world_x, camera_x=0):
        """Pulse a nearby cave crystal when the Knight attacks beside it."""
        if self.layout.THEME != "crystal":
            return False
        crystals = (360, 910, 1570, 2240, 3010, 3470)
        nearest = min(crystals, key=lambda crystal_x: abs(crystal_x + camera_x * 0.73 - world_x))
        if abs(nearest + camera_x * 0.73 - world_x) > 190:
            return False
        self.crystal_flash_x = nearest
        self.crystal_flash_timer = 0.42
        return True

    @staticmethod
    def _tint_tile(image, tint=(170, 180, 210, 255), shade=(0, 12, 38, 0)):
        tinted = image.copy()
        tinted.fill(
            tint,
            special_flags=pygame.BLEND_RGBA_MULT,
        )
        tinted.fill(
            shade,
            special_flags=pygame.BLEND_RGBA_ADD,
        )
        return tinted

    def draw_background(self, screen, camera_x):
        """Render a distinct multi-layer background for every campaign chapter."""
        level = self.level_number
        theme = getattr(self.layout, "THEME", "green")

        if theme == "forest":
            self._draw_forest_background(screen, camera_x)
            return
        if theme == "catacombs":
            self._draw_catacombs_background(screen, camera_x)
            return
        if theme in ("crystal", "village", "fields", "kingdom"):
            self._draw_mountain_background(screen, camera_x, theme)
            return
        if theme in ("ember", "drowned", "abyss", "throne"):
            self._draw_underworld_background(screen, camera_x, theme)
            return

        # Level 1: bright valley with three parallax depth layers.
        width, height = screen.get_size()
        sky_top = (25, 132, 216)
        sky_bottom = (80, 190, 231)
        for y in range(0, height, 8):
            amount = y / height
            color = tuple(round(sky_top[c] + (sky_bottom[c] - sky_top[c]) * amount) for c in range(3))
            pygame.draw.rect(screen, color, (0, y, width, 8))

        # Distant cloud layer.
        cloud_layer = pygame.Surface((width, 190), pygame.SRCALPHA)
        for world_x, y in ((130, 42), (720, 105), (1510, 26), (2320, 81), (3040, 50)):
            x = int(world_x - camera_x * 0.08) % (WORLD_WIDTH + 180) - 90
            self._draw_cloud(cloud_layer, x, y, 0.8)
        screen.blit(cloud_layer, (0, 0))

        # Far mountains.
        shift = int(camera_x * 0.10) % 390
        for index in range(-1, width // 390 + 3):
            x = index * 390 - shift
            pygame.draw.polygon(
                screen, (93, 184, 208),
                [(x, 378), (x + 92, 280), (x + 174, 345), (x + 258, 270), (x + 390, 378)],
            )

        # Midground hills.
        shift = int(camera_x * 0.23) % 260
        for index in range(-1, width // 260 + 3):
            x = index * 260 - shift
            pygame.draw.polygon(
                screen, (67, 163, 194),
                [(x, 420), (x + 65, 346), (x + 130, 392), (x + 196, 335), (x + 260, 420)],
            )

        # Foreground grass silhouettes.
        shift = int(camera_x * 0.40) % 170
        for index in range(-1, width // 170 + 3):
            x = index * 170 - shift
            pygame.draw.polygon(
                screen, (42, 124, 106),
                [(x, 440), (x + 38, 392), (x + 75, 423), (x + 111, 385), (x + 170, 440)],
            )

    def _draw_forest_background(self, screen, camera_x):
        """Layer a moonlit, pixel-crisp forest behind the playable route."""
        width, height = screen.get_size()
        sky_top = (13, 19, 43)
        sky_bottom = (37, 49, 74)
        for y in range(0, height, 8):
            amount = y / height
            color = tuple(round(sky_top[i] + (sky_bottom[i] - sky_top[i]) * amount) for i in range(3))
            pygame.draw.rect(screen, color, (0, y, width, 8))

        moon_x = int(width * 0.77 - camera_x * 0.025) % (width + 100) - 50
        pygame.draw.circle(screen, (181, 194, 218), (moon_x, 91), 27)
        pygame.draw.circle(screen, (224, 228, 231), (moon_x - 5, 86), 19)
        for star_x, star_y, size in ((76, 65, 2), (214, 128, 2), (388, 54, 3), (573, 111, 2), (850, 52, 2), (920, 157, 2)):
            x = (star_x - int(camera_x * 0.035)) % width
            pygame.draw.rect(screen, (190, 213, 225), (x, star_y, size, size))

        shift = int(camera_x * 0.10) % 360
        for index in range(-1, width // 360 + 3):
            x = index * 360 - shift
            pygame.draw.polygon(
                screen, (36, 57, 78),
                [(x, 388), (x + 94, 285), (x + 184, 350), (x + 275, 274), (x + 360, 388)],
            )

        # Two irregular tree lines make a layered woodland instead of a tiled
        # row of identical triangles. Integer patterns keep the silhouettes
        # stable from frame to frame while the parallax layers drift naturally.
        for layer, (spacing, parallax, base_y, color, crown) in enumerate((
            (188, 0.18, 429, (25, 45, 57), 116),
            (146, 0.34, 440, (15, 31, 40), 142),
        )):
            shift = int(camera_x * parallax) % spacing
            for index in range(-2, width // spacing + 3):
                x = index * spacing - shift
                seed = index * 47 + layer * 83
                tree_h = crown + (seed % 47) - 18
                center_x = x + spacing // 2 + (seed % 19) - 9
                trunk_w = 10 if layer else 12
                trunk_h = max(18, tree_h // 3)
                canopy_h = tree_h - trunk_h // 2
                canopy_w = 68 + (seed * 3 % 47)
                canopy_top = base_y - trunk_h - canopy_h
                trunk_color = tuple(max(0, component - 7) for component in color)
                pygame.draw.polygon(screen, trunk_color, (
                    (center_x - trunk_w // 2, base_y),
                    (center_x - trunk_w // 3, base_y - trunk_h),
                    (center_x + trunk_w // 3, base_y - trunk_h),
                    (center_x + trunk_w // 2, base_y),
                ))
                canopy_points = [
                    (center_x - canopy_w // 3, canopy_top + 18),
                    (center_x - canopy_w // 2, canopy_top + canopy_h // 3),
                    (center_x - canopy_w // 2 + 7, canopy_top + canopy_h * 2 // 3),
                    (center_x - canopy_w // 4, canopy_top + canopy_h - 5),
                    (center_x + canopy_w // 4, canopy_top + canopy_h),
                    (center_x + canopy_w // 2, canopy_top + canopy_h * 3 // 4),
                    (center_x + canopy_w // 2 - 5, canopy_top + canopy_h // 3),
                    (center_x + canopy_w // 5, canopy_top + 7),
                ]
                pygame.draw.polygon(screen, color, canopy_points)
                # A few uneven crowns soften the angular outline without blur.
                for dx, dy, radius in ((-canopy_w // 3, canopy_h // 3, 25),
                                       (canopy_w // 3, canopy_h // 2, 29),
                                       (-canopy_w // 5, canopy_h * 2 // 3, 26)):
                    pygame.draw.circle(screen, color, (center_x + dx, canopy_top + dy), radius)
                accent = tuple(min(255, component + 7) for component in color)
                pygame.draw.ellipse(screen, accent, (center_x - canopy_w // 4, canopy_top + canopy_h // 2, canopy_w // 3, 12))

        mist = pygame.Surface((width, 92), pygame.SRCALPHA)
        pygame.draw.rect(mist, (126, 158, 177, 12), (0, 18, width, 42))
        for index in range(-1, width // 260 + 3):
            mist_x = index * 260 - int(camera_x * 0.12) % 260
            pygame.draw.ellipse(mist, (146, 173, 185, 9), (mist_x, 4 + (index % 3) * 13, 310, 54))
        screen.blit(mist, (0, 332))

        for world_x, world_y in ((290, 330), (840, 304), (1380, 355), (2160, 302), (2780, 346), (3290, 316)):
            x = int(world_x - camera_x * 0.28)
            if -8 <= x <= width + 8:
                pygame.draw.rect(screen, (209, 173, 101), (x, world_y, 3, 3))

        # A distant castle marks the forest's end and gives the road a destination.
        castle_x = round(3260 - camera_x * 0.14)
        if -220 < castle_x < width + 220:
            pygame.draw.rect(screen, (28, 38, 58), (castle_x, 223, 154, 155))
            pygame.draw.rect(screen, (39, 48, 67), (castle_x - 16, 238, 186, 140))
            for tower_x, top_y in ((castle_x - 7, 187), (castle_x + 42, 204), (castle_x + 114, 174), (castle_x + 151, 213)):
                pygame.draw.rect(screen, (31, 41, 61), (tower_x, top_y, 25, 190 - top_y))
                pygame.draw.polygon(screen, (41, 49, 68), ((tower_x - 4, top_y), (tower_x + 12, top_y - 22), (tower_x + 29, top_y)))
                pygame.draw.rect(screen, (116, 151, 171), (tower_x + 10, top_y + 29, 4, 9))

    def _draw_catacombs_background(self, screen, camera_x):
        """Buried stone halls, hanging chains, and a cold underground river."""
        width, height = screen.get_size()
        top, bottom = ENVIRONMENTS["catacombs"]["sky"]
        for y in range(0, height, 6):
            t = y / height
            color = tuple(round(top[c] + (bottom[c] - top[c]) * t) for c in range(3))
            pygame.draw.rect(screen, color, (0, y, width, 6))
        for i in range(24):
            x = (i * 127 + 19) % width
            y = 36 + (i * 61) % 210
            pygame.draw.rect(screen, (142, 131, 161), (x, y, 2, 2))
        shift = int(camera_x * 0.16) % 310
        for index in range(-1, width // 310 + 3):
            x = index * 310 - shift
            pygame.draw.rect(screen, (39, 37, 52), (x + 22, 196, 28, 240))
            pygame.draw.rect(screen, (66, 61, 78), (x + 8, 186, 56, 18))
            pygame.draw.rect(screen, (50, 45, 62), (x + 15, 204, 8, 225))
            pygame.draw.rect(screen, (50, 45, 62), (x + 48, 204, 8, 225))
            pygame.draw.arc(screen, (92, 77, 104), (x + 19, 220, 34, 40), 0, 3.14, 3)
            # A short broken chain hangs from the vaulted ceiling.
            chain_x = x + 105
            for link in range(7 + index % 4):
                pygame.draw.rect(screen, (91, 83, 103), (chain_x + (link % 2) * 2, 82 + link * 9, 3, 7), 1)
        pygame.draw.rect(screen, (23, 45, 62), (0, 434, width, height - 434))
        pygame.draw.line(screen, (88, 143, 169), (0, 438), (width, 438), 2)
        for x in range(-24, width + 24, 96):
            wave_x = (x - int(camera_x * 0.24)) % (width + 96) - 48
            pygame.draw.line(screen, (116, 154, 170), (wave_x, 448), (wave_x + 26, 448), 2)
        for world_x in (510, 1430, 2470, 3260):
            x = round(world_x - camera_x * 0.26)
            if -90 < x < width + 90:
                pygame.draw.circle(screen, (190, 182, 157), (x, 389), 10, 2)
                pygame.draw.circle(screen, (44, 39, 51), (x, 389), 4)

    def _draw_mountain_background(self, screen, camera_x, theme="mountain"):
        width, height = screen.get_size()
        palettes = {
            "crystal": (ENVIRONMENTS["crystal"]["sky"], (68, 106, 143), (166, 216, 234)),
            "village": (ENVIRONMENTS["village"]["sky"], (103, 65, 70), (204, 128, 93)),
            "fields": (ENVIRONMENTS["fields"]["sky"], (135, 138, 103), (223, 198, 132)),
            "kingdom": (ENVIRONMENTS["kingdom"]["sky"], (96, 83, 103), (221, 157, 121)),
        }
        sky, ridge_color, peak_color = palettes[theme]
        top, bottom = sky
        for y in range(0, height, 6):
            t = y / height
            color = tuple(round(top[c] + (bottom[c] - top[c]) * t) for c in range(3))
            pygame.draw.rect(screen, color, (0, y, width, 6))
        sun_x = int(width * 0.72 - camera_x * 0.025) % (width + 100) - 40
        sun_colors = {"crystal": (175, 223, 250), "village": (255, 153, 88),
                      "fields": (255, 225, 157), "kingdom": (248, 183, 139)}
        pygame.draw.circle(screen, sun_colors[theme], (sun_x, 92), 34)
        shift = int(camera_x * 0.12) % 390
        for i in range(-1, width // 390 + 3):
            x = i * 390 - shift
            peak = 235 + (i % 3) * 36
            points = [(x - 40, 405), (x + 120, peak), (x + 280, 405)]
            pygame.draw.polygon(screen, ridge_color, points)
            pygame.draw.polygon(screen, peak_color, [(x + 120, peak), (x + 78, peak + 72), (x + 145, peak + 54)])
        shift = int(camera_x * 0.24) % 300
        for i in range(-1, width // 300 + 3):
            x = i * 300 - shift
            color = {"crystal": (45, 67, 106), "village": (72, 51, 58),
                     "fields": (92, 111, 76), "kingdom": (63, 62, 82)}[theme]
            pygame.draw.polygon(screen, color, [(x - 30, 435), (x + 115, 304), (x + 280, 435)])
        self._draw_mountain_landmarks(screen, camera_x, theme)
        pygame.draw.rect(screen, ENVIRONMENTS[theme]["surface"], (0, 431, width, height - 431))

    def _draw_mountain_landmarks(self, screen, camera_x, theme):
        width = screen.get_width()
        if theme == "crystal":
            # Clusters of tall faceted crystals mark the cave ceiling and floor.
            for world_x, size in ((360, 72), (910, 98), (1570, 64), (2240, 108), (3010, 82), (3470, 112)):
                x = round(world_x - camera_x * 0.27)
                if -120 < x < width + 120:
                    pygame.draw.polygon(screen, (38, 76, 118), ((x, 418), (x + size // 3, 307 - size // 3), (x + size, 418)))
                    pygame.draw.polygon(screen, (56, 130, 171), ((x + size // 3, 418), (x + size // 3, 307 - size // 3), (x + size, 418)))
                    pygame.draw.line(screen, (138, 234, 250), (x + size // 3, 410), (x + size // 3, 329 - size // 3), 3)
                    if self.crystal_flash_timer > 0 and abs(world_x - self.crystal_flash_x) < 40:
                        radius = 22 + round((0.42 - self.crystal_flash_timer) * 58)
                        pygame.draw.circle(screen, (164, 247, 255), (x + size // 2, 375), radius, 2)
        elif theme == "village":
            for world_x, h in ((420, 98), (1020, 134), (1780, 111), (2520, 145), (3260, 104)):
                x = round(world_x - camera_x * 0.25)
                body_y = 423 - h
                pygame.draw.rect(screen, (61, 43, 48), (x, body_y, 116, h))
                pygame.draw.polygon(screen, (91, 44, 44), ((x - 13, body_y + 5), (x + 55, body_y - 49), (x + 128, body_y + 5)))
                pygame.draw.rect(screen, (255, 132, 57), (x + 20, body_y + 35, 18, 28))
                pygame.draw.rect(screen, (255, 182, 82), (x + 68, body_y + 76, 21, 30))
                pygame.draw.ellipse(screen, (71, 54, 61), (x + 15, body_y - 66, 52, 31))
                pygame.draw.ellipse(screen, (88, 62, 66), (x + 34, body_y - 91, 62, 34))
        elif theme == "fields":
            # Windmills and long, alternating crop lines establish open farmland.
            for world_x, height in ((470, 116), (1350, 145), (2330, 122), (3210, 152)):
                x = round(world_x - camera_x * 0.2)
                top_y = 423 - height
                pygame.draw.polygon(screen, (113, 94, 67), ((x - 18, 423), (x + 18, 423), (x + 11, top_y), (x - 9, top_y)))
                pygame.draw.circle(screen, (198, 156, 87), (x, top_y), 5)
                for angle in (0, 90, 180, 270):
                    rad = math.radians(angle + pygame.time.get_ticks() * 0.015)
                    end = (x + round(math.cos(rad) * 37), top_y + round(math.sin(rad) * 37))
                    pygame.draw.line(screen, (207, 183, 137), (x, top_y), end, 4)
                    pygame.draw.circle(screen, (155, 122, 79), end, 4)
            for row in range(8):
                y = 380 + row * 7
                pygame.draw.line(screen, (102 + row * 2, 123 + row, 67), (0, y), (width, y), 1)
            # A distant storm bank rolls in without affecting the route.
            cloud_x = (width - 170 - int(camera_x * 0.07) - pygame.time.get_ticks() // 70) % (width + 280) - 140
            for dx, dy, rw, rh in ((0, 0, 112, 24), (28, -18, 96, 34), (72, -9, 112, 27)):
                pygame.draw.ellipse(screen, (111, 119, 133), (cloud_x + dx, 116 + dy, rw, rh))
        else:  # Ruined Kingdom: sunset, walls, and the distant crown of a castle.
            for world_x, h in ((430, 156), (990, 210), (2070, 176), (2810, 235), (3440, 194)):
                x = round(world_x - camera_x * 0.2)
                pygame.draw.rect(screen, (57, 55, 75), (x, 426 - h, 105, h))
                pygame.draw.rect(screen, (83, 72, 88), (x - 12, 420 - h, 129, 15))
                for tower_x in (x + 8, x + 73):
                    pygame.draw.rect(screen, (69, 61, 83), (tower_x, 395 - h, 22, 46))
                    pygame.draw.polygon(screen, (98, 72, 91), ((tower_x - 4, 395 - h), (tower_x + 11, 372 - h), (tower_x + 27, 395 - h)))
                pygame.draw.rect(screen, (36, 43, 67), (x + 44, 352 - h, 12, 27))

    @staticmethod
    def _draw_storm_bolt(screen, width, camera_x):
        flash = (pygame.time.get_ticks() // 1000 + int(camera_x // 500)) % 7 == 0
        if flash:
            x = (int(camera_x * 0.17) + width * 2 // 3) % width
            points = [(x, 92), (x - 16, 137), (x + 2, 132), (x - 12, 180)]
            pygame.draw.lines(screen, (245, 232, 183), False, points, 3)

    def _draw_underworld_background(self, screen, camera_x, theme="gate"):
        width, height = screen.get_size()
        palettes = {
            "ember": ENVIRONMENTS["ember"]["sky"],
            "drowned": ENVIRONMENTS["drowned"]["sky"],
            "abyss": ENVIRONMENTS["abyss"]["sky"],
            "throne": ENVIRONMENTS["throne"]["sky"],
        }
        top, bottom = palettes[theme]
        for y in range(0, height, 6):
            t = y / height
            color = tuple(round(top[c] + (bottom[c] - top[c]) * t) for c in range(3))
            pygame.draw.rect(screen, color, (0, y, width, 6))
        for i in range(34):
            x = (i * 149 + int(camera_x * 0.08)) % width
            y = 65 + (i * 53) % 260
            particle = ENVIRONMENTS[theme]["particles"][i % 2]
            if theme == "drowned":
                pygame.draw.circle(screen, particle, (x, y), 2 + i % 2, 1)
            else:
                pygame.draw.circle(screen, particle, (x, y), 2 + i % 2)
        shift = int(camera_x * 0.17) % 340
        for i in range(-1, width // 340 + 3):
            x = i * 340 - shift
            ridge = {"ember": (54, 35, 54), "drowned": (17, 66, 83),
                     "abyss": (36, 24, 61), "throne": (54, 35, 54)}[theme]
            pygame.draw.polygon(screen, ridge, [(x - 40, 432), (x + 70, 292), (x + 145, 380), (x + 260, 250), (x + 390, 432)])
        shift = int(camera_x * 0.32) % 250
        for i in range(-1, width // 250 + 3):
            x = i * 250 - shift
            ground = {"ember": (42, 34, 48), "drowned": (17, 55, 69),
                      "abyss": (30, 22, 49), "throne": (42, 34, 48)}[theme]
            pygame.draw.ellipse(screen, ground, (x, 387, 300, 115))
        if theme == "ember":
            for x in range(-20, width + 100, 180):
                glow_x = (x - int(camera_x * 0.45)) % (width + 180) - 60
                pygame.draw.ellipse(screen, (157, 55, 34), (glow_x, 468, 116, 25))
                pygame.draw.ellipse(screen, (245, 111, 50), (glow_x + 12, 476, 90, 11))
        elif theme == "drowned":
            pygame.draw.rect(screen, (11, 58, 77), (0, 430, width, height - 430))
            for wave in range(5):
                y = 438 + wave * 13
                offset = int(camera_x * (0.08 + wave * 0.025) + pygame.time.get_ticks() * 0.02)
                for x in range(-60, width + 80, 120):
                    wave_x = (x - offset) % (width + 120) - 40
                    pygame.draw.line(screen, (42 + wave * 5, 116 + wave * 8, 132 + wave * 7),
                                     (wave_x, y), (wave_x + 36, y), 1)
        else:
            pygame.draw.rect(screen, ENVIRONMENTS[theme]["surface"], (0, 431, width, height - 431))
        self._draw_underworld_landmarks(screen, camera_x, theme)

    def _draw_underworld_landmarks(self, screen, camera_x, theme):
        width = screen.get_width()
        if theme == "ember":
            for world_x, h in ((430, 152), (1110, 190), (1940, 150), (2770, 208), (3370, 174)):
                x = round(world_x - camera_x * 0.21)
                pygame.draw.polygon(screen, (49, 35, 48), ((x - 135, 430), (x, 430 - h), (x + 138, 430)))
                pygame.draw.polygon(screen, (126, 50, 37), ((x - 42, 430 - h // 2), (x, 430 - h), (x + 34, 430 - h // 2)))
                pygame.draw.ellipse(screen, (239, 103, 48), (x - 35, 430 - h + 18, 70, 18))
        elif theme == "drowned":
            for world_x, h in ((400, 128), (1090, 174), (1910, 139), (2740, 186), (3330, 148)):
                x = round(world_x - camera_x * 0.21)
                pygame.draw.rect(screen, (18, 64, 79), (x, 425 - h, 104, h))
                pygame.draw.rect(screen, (30, 91, 103), (x - 11, 419 - h, 127, 13))
                for window_x in (x + 20, x + 67):
                    pygame.draw.arc(screen, (85, 168, 170), (window_x, 307 - h, 19, 35), 0, math.pi, 2)
                for coral in (-28, 122):
                    pygame.draw.line(screen, (63, 150, 151), (x + coral, 427), (x + coral - 9, 389), 3)
                    pygame.draw.line(screen, (63, 150, 151), (x + coral - 3, 408), (x + coral + 9, 392), 2)
            for fish_i in range(6):
                fish_x = (fish_i * 183 - int(camera_x * 0.33) + pygame.time.get_ticks() // 18) % (width + 60) - 30
                fish_y = 185 + fish_i * 31 % 150
                pygame.draw.ellipse(screen, (78, 166, 177), (fish_x, fish_y, 20, 9))
                pygame.draw.polygon(screen, (78, 166, 177), ((fish_x, fish_y + 4), (fish_x - 7, fish_y), (fish_x - 7, fish_y + 8)))
        elif theme == "abyss":
            moon_x = (width * 2 // 3 - int(camera_x * 0.018)) % (width + 160) - 80
            pygame.draw.circle(screen, (153, 122, 193), (moon_x, 113), 60)
            pygame.draw.circle(screen, (102, 77, 149), (moon_x + 19, 94), 49)
            for world_x in (380, 1010, 1790, 2550, 3320):
                x = round(world_x - camera_x * 0.2)
                pygame.draw.rect(screen, (34, 28, 57), (x, 214, 22, 218))
                pygame.draw.rect(screen, (50, 38, 75), (x - 10, 201, 43, 16))
                pygame.draw.arc(screen, (71, 48, 97), (x - 22, 240, 72, 81), 0, math.pi, 6)
            # A distant, non-interactive silhouette hints at something watching from the deep.
            silhouette_x = round(width * 0.82 - camera_x * 0.035) % (width + 140) - 70
            pygame.draw.ellipse(screen, (20, 16, 39), (silhouette_x - 25, 308, 50, 78))
            pygame.draw.circle(screen, (20, 16, 39), (silhouette_x, 292), 23)
            pygame.draw.circle(screen, (207, 151, 242), (silhouette_x - 8, 293), 2)
            pygame.draw.circle(screen, (207, 151, 242), (silhouette_x + 8, 293), 2)
        elif theme == "throne":  # Broken halls and the final empty throne.
            for world_x in (620, 1760, 2920):
                x = round(world_x - camera_x * 0.22)
                if -160 < x < width + 160:
                    pygame.draw.rect(screen, (45, 34, 52), (x, 238, 34, 202))
                    pygame.draw.rect(screen, (63, 41, 54), (x - 16, 226, 66, 18))
                    pygame.draw.arc(screen, (242, 92, 56), (x + 18, 285, 122, 142), 0, 3.14, 8)
                    pygame.draw.arc(screen, (255, 168, 76), (x + 36, 305, 86, 120), 0, 3.14, 3)
            throne_x = round(3470 - camera_x)
            if -180 < throne_x < width + 180:
                pygame.draw.rect(screen, (80, 45, 62), (throne_x, 275, 115, 142))
                pygame.draw.polygon(screen, (110, 61, 76), [(throne_x - 18, 300), (throne_x - 18, 250), (throne_x + 12, 250), (throne_x + 28, 275)])
                pygame.draw.polygon(screen, (110, 61, 76), [(throne_x + 94, 275), (throne_x + 112, 250), (throne_x + 140, 250), (throne_x + 140, 300)])

    def _draw_ruins_background(self, screen, camera_x):
        width, height = screen.get_size()
        top = (28, 35, 70)
        bottom = (128, 91, 91)
        for y in range(0, height, 6):
            amount = y / height
            color = tuple(
                round(top[channel] + (bottom[channel] - top[channel]) * amount)
                for channel in range(3)
            )
            pygame.draw.rect(screen, color, (0, y, width, 6))

        # A pale moon and small stars establish the cool night-time palette.
        moon_x = int(width * 0.76 - camera_x * 0.025) % (width + 100) - 50
        pygame.draw.circle(screen, (242, 218, 165), (moon_x, 112), 42)
        pygame.draw.circle(screen, (224, 190, 151), (moon_x + 15, 100), 36)
        for index in range(38):
            star_x = (index * 137 + 31) % width
            star_y = 32 + (index * 47) % 170
            twinkle = 150 + (index * 19) % 100
            pygame.draw.rect(screen, (twinkle, twinkle, 208), (star_x, star_y, 2, 2))

        # Distant broken towers and archways scroll more slowly than the ground.
        shift = int(camera_x * 0.18) % 440
        for index in range(-1, width // 440 + 3):
            x = index * 440 - shift
            variation = (index % 3 + 3) % 3
            self._draw_ruin_tower(screen, x + 36, 382, 0.8 + variation * 0.13)
            self._draw_ruin_arch(screen, x + 210, 390, 0.82 + variation * 0.12)

        # Dark, layered ridges keep the playable platforms easy to read.
        shift = int(camera_x * 0.31) % 230
        for index in range(-1, width // 230 + 3):
            x = index * 230 - shift
            pygame.draw.ellipse(screen, (71, 79, 92), (x, 350, 285, 145))
        shift = int(camera_x * 0.44) % 310
        for index in range(-1, width // 310 + 3):
            x = index * 310 - shift
            pygame.draw.ellipse(screen, (55, 67, 78), (x, 397, 350, 140))

    @staticmethod
    def _draw_ruin_tower(screen, x, base_y, scale):
        stone = (76, 75, 94)
        edge = (105, 96, 105)
        width = int(45 * scale)
        height = int(102 * scale)
        top = base_y - height
        pygame.draw.rect(screen, stone, (x, top, width, height))
        pygame.draw.rect(screen, edge, (x, top, max(3, int(7 * scale)), height))
        pygame.draw.rect(screen, stone, (x - int(5 * scale), top - int(8 * scale), int(18 * scale), int(9 * scale)))
        pygame.draw.rect(screen, stone, (x + int(25 * scale), top - int(12 * scale), int(24 * scale), int(13 * scale)))
        window_w = max(4, int(8 * scale))
        pygame.draw.rect(screen, (39, 49, 70), (x + width // 2 - window_w // 2, top + int(27 * scale), window_w, int(22 * scale)))
        pygame.draw.rect(screen, (39, 49, 70), (x + width // 2 - window_w // 2, top + int(67 * scale), window_w, int(18 * scale)))
        pygame.draw.line(screen, edge, (x - int(9 * scale), base_y), (x + width + int(8 * scale), base_y), max(2, int(4 * scale)))

    @staticmethod
    def _draw_ruin_arch(screen, x, base_y, scale):
        stone = (83, 78, 94)
        edge = (113, 96, 103)
        pillar_w = max(8, int(15 * scale))
        pillar_h = int(64 * scale)
        gap = int(48 * scale)
        pygame.draw.rect(screen, stone, (x, base_y - pillar_h, pillar_w, pillar_h))
        pygame.draw.rect(screen, stone, (x + gap, base_y - pillar_h, pillar_w, pillar_h))
        pygame.draw.rect(screen, edge, (x - int(4 * scale), base_y - pillar_h - int(10 * scale), gap + int(24 * scale), int(12 * scale)))
        pygame.draw.line(screen, (45, 52, 72), (x + pillar_w, base_y - pillar_h + int(20 * scale)), (x + gap, base_y - pillar_h + int(20 * scale)), max(2, int(4 * scale)))

    @staticmethod
    def _draw_cloud(surface, x, y, scale):
        color = (248, 252, 235, 115)
        cloud_width = int(116 * scale)
        cloud_height = int(30 * scale)
        pygame.draw.ellipse(
            surface,
            color,
            (x, y + int(14 * scale), cloud_width, cloud_height),
        )
        for dx, dy, radius in [
            (24, 17, 19), (51, 7, 26), (81, 14, 22),
        ]:
            pygame.draw.circle(
                surface,
                color,
                (x + int(dx * scale), y + int(dy * scale)),
                int(radius * scale),
            )

    def draw(self, screen, camera):
        view_left = camera.offset.x - 64
        view_right = camera.offset.x + screen.get_width() + 64
        self._draw_cave_ceiling(screen, camera, view_left, view_right)
        self._draw_boss_arena_background(screen, camera)
        self._draw_pits(screen, camera, view_left, view_right)
        self._draw_props(screen, camera, self.backdrop_props, view_left, view_right)

        for rect in self.platforms:
            if rect.right < view_left or rect.left > view_right:
                continue
            if any(rect is item.rect for item in self.moving_platforms):
                continue
            if rect.height > 100:
                self._draw_ground(screen, camera, rect)

        for rect in self.platforms:
            if rect.height > 100 or any(rect is item.rect for item in self.moving_platforms):
                continue
            self._draw_ledge_walls(screen, camera, rect)

        for rect in self.platforms:
            if any(rect is item.rect for item in self.moving_platforms):
                continue
            if any(rect is patch for patch in self.raised_ground):
                self._draw_raised_ground(screen, camera, rect)
            elif rect.height <= 100:
                self._draw_ledge(screen, camera, rect)

        for moving_platform in self.moving_platforms:
            if view_left <= moving_platform.rect.right and moving_platform.rect.left <= view_right:
                self._draw_moving_platform(screen, camera, moving_platform.rect, self.layout.THEME)

        self._draw_props(screen, camera, self.scenery_props, view_left, view_right)

        self._draw_hazards(screen, camera, view_left, view_right)

        for world_x, variant in self.bushes:
            if view_left <= world_x <= view_right:
                bush_ground_y = GROUND_Y
                for patch in self.raised_ground:
                    if patch.left <= world_x < patch.right:
                        bush_ground_y = patch.top
                        break
                self._draw_bush(
                    screen,
                    int(world_x - camera.offset.x),
                    bush_ground_y,
                    variant,
                    self.layout.THEME,
                )

        ticks = pygame.time.get_ticks()
        for coin in self.coins:
            screen_rect = camera.apply(coin)
            frame = self.assets.coin_frames[(ticks // 100) % len(self.assets.coin_frames)]
            screen.blit(frame, (screen_rect.centerx - frame.get_width() // 2, screen_rect.y - 5))

        for stash in self.candy_stashes:
            screen_rect = camera.apply(stash)
            bob = round(math.sin(ticks * 0.004 + stash.x) * 2)
            x, y = screen_rect.x, screen_rect.y + bob
            pygame.draw.rect(screen, (36, 20, 25), (x - 2, y - 2, 30, 30))
            pygame.draw.rect(screen, (238, 157, 69), (x, y, 26, 26))
            pygame.draw.rect(screen, (102, 39, 35), (x + 3, y + 3, 20, 20))
            pygame.draw.rect(screen, (255, 215, 117), (x + 7, y + 7, 12, 12))
            pygame.draw.rect(screen, (111, 57, 44), (x + 10, y + 10, 6, 6))
            pygame.draw.rect(screen, (255, 245, 196), (x + 5, y + 5, 3, 3))

        self._draw_goal(screen, camera)
        self._draw_boss_arena_gate(screen, camera)

    def _draw_cave_ceiling(self, screen, camera, view_left, view_right):
        """Pixelated cave roof with jagged rock and a few mossy hanging roots."""
        theme = self.layout.THEME
        roof = {
            "forest": (7, 19, 25), "catacombs": (13, 16, 28),
            "crystal": (8, 24, 39), "village": (24, 16, 23),
            "fields": (22, 23, 22), "kingdom": (13, 17, 29),
            "ember": (24, 14, 20), "drowned": (7, 24, 32),
            "abyss": (13, 9, 27), "throne": (17, 8, 25),
        }.get(theme, (7, 19, 25))
        edge = self.wall_accent
        first = int(view_left // 48) * 48
        for world_x in range(first, int(view_right) + 48, 48):
            screen_x = round(world_x - camera.offset.x)
            depth = 44 + int(13 * (1 + math.sin(world_x * 0.0067)))
            wobble = int(6 * math.sin(world_x * 0.021))
            lower = depth + wobble
            shape = ((screen_x, 0), (screen_x + 48, 0),
                     (screen_x + 48, depth - 8), (screen_x + 35, lower),
                     (screen_x + 22, depth - 4), (screen_x + 10, lower - 4),
                     (screen_x, depth - 7))
            pygame.draw.polygon(screen, roof, shape)
            pygame.draw.line(screen, (31, 46, 43), (screen_x, depth - 7),
                             (screen_x + 15, lower - 4), 2)
            if (world_x // 48) % 4 == 1:
                tip_x = screen_x + 28
                tip_y = lower + 14
                pygame.draw.polygon(screen, roof,
                                    ((tip_x - 5, lower - 2), (tip_x + 5, lower - 2),
                                     (tip_x + 1, tip_y)))
            if (world_x // 48) % 5 == 2:
                moss_x = screen_x + 7
                moss_y = lower - 1
                pygame.draw.line(screen, edge, (moss_x, moss_y),
                                 (moss_x + 2, moss_y + 9), 2)
                pygame.draw.line(screen, edge, (moss_x + 10, moss_y),
                                 (moss_x + 12, moss_y + 5), 2)

    def _draw_ledge_walls(self, screen, camera, rect):
        """Continue each ledge down to the next support, like solid cave terrain."""
        view_left = camera.offset.x - 64
        view_right = camera.offset.x + screen.get_width() + 64
        if rect.right < view_left or rect.left > view_right:
            return
        overlaps = [other.top for other in self.platforms
                    if other is not rect
                    and other.top >= rect.bottom
                    and other.left < rect.right
                    and other.right > rect.left]
        wall_top = rect.top + TILE
        wall_bottom = min(screen.get_height(), min(overlaps, default=screen.get_height()))
        if wall_bottom <= wall_top:
            return

        left = round(rect.left - camera.offset.x)
        right = round(rect.right - camera.offset.x)
        pygame.draw.rect(screen, (12, 18, 21),
                         (left, wall_top, max(1, right - left), wall_bottom - wall_top))
        for tile_x in range(rect.left, rect.right, TILE):
            x = round(tile_x - camera.offset.x)
            piece_width = min(TILE, rect.right - tile_x)
            for y in range(wall_top, wall_bottom, TILE):
                piece_height = min(TILE, wall_bottom - y)
                tile_index = (tile_x // TILE + y // TILE) % len(self.wall_fill_tiles)
                source = self.wall_fill_tiles[tile_index]
                piece = source if piece_width == TILE and piece_height == TILE else source.subsurface(
                    pygame.Rect(0, 0, piece_width, piece_height)
                )
                screen.blit(piece, (x, y))
        pygame.draw.line(screen, (20, 26, 29), (left, wall_top), (left, wall_bottom), 3)
        pygame.draw.line(screen, (20, 26, 29), (right - 2, wall_top), (right - 2, wall_bottom), 3)
        pygame.draw.line(screen, self.wall_accent, (left + 3, wall_top + 2),
                         (right - 4, wall_top + 2), 2)

    def _draw_boss_arena_background(self, screen, camera):
        if not self.boss_arena:
            return
        start, end = self.boss_arena
        left = round(start - camera.offset.x)
        right = round(end - camera.offset.x)
        clip_left, clip_right = max(0, left), min(screen.get_width(), right)
        if clip_right <= clip_left:
            return
        theme = self.layout.THEME
        if theme == "crystal":
            wall, mortar, accent = (12, 35, 58), (31, 68, 91), (75, 178, 218)
        else:
            wall, mortar, accent = (31, 18, 43), (65, 35, 66), (215, 75, 117)
        room = pygame.Rect(clip_left, 0, clip_right - clip_left, GROUND_Y)
        pygame.draw.rect(screen, wall, room)
        pygame.draw.rect(screen, mortar, (clip_left, 34, clip_right - clip_left, 5))
        pygame.draw.line(screen, accent, (clip_left, 42), (clip_right, 42), 2)
        for row, y in enumerate((88, 150, 212, 274, 336, 398)):
            pygame.draw.line(screen, mortar, (clip_left, y), (clip_right, y), 1)
            offset = 34 if row % 2 else 0
            for world_x in range(start + offset, end, 68):
                px = round(world_x - camera.offset.x)
                pygame.draw.line(screen, mortar, (px, y - 26), (px, y), 1)

        for world_x in (start + 62, end - 92):
            x = round(world_x - camera.offset.x)
            pygame.draw.rect(screen, mortar, (x - 18, 76, 36, GROUND_Y - 76))
            pygame.draw.rect(screen, accent, (x - 22, 76, 44, 8))
            pygame.draw.rect(screen, wall, (x - 7, 92, 14, GROUND_Y - 92))

        if theme == "crystal":
            for world_x, height in ((start + 115, 112), (end - 154, 148), (end - 250, 82)):
                x = round(world_x - camera.offset.x)
                points = ((x, GROUND_Y - height), (x + 17, GROUND_Y - height + 28),
                          (x + 28, GROUND_Y), (x - 24, GROUND_Y),
                          (x - 13, GROUND_Y - height + 26))
                pygame.draw.polygon(screen, (25, 107, 140), points)
                pygame.draw.polygon(screen, (112, 220, 245), points, 2)
                pygame.draw.line(screen, (190, 244, 250), (x, GROUND_Y - height + 6),
                                 (x - 4, GROUND_Y - 20), 2)
        else:
            center = round((start + end - 120) / 2 - camera.offset.x)
            arch = pygame.Rect(center - 128, 70, 256, 300)
            pygame.draw.arc(screen, mortar, arch, 0.0, 3.14159, 9)
            pygame.draw.line(screen, accent, (center - 126, 218), (center - 126, 366), 5)
            pygame.draw.line(screen, accent, (center + 126, 218), (center + 126, 366), 5)
            # A throne silhouette establishes a distinct final-boss room.
            tx = center + 70
            pygame.draw.rect(screen, (72, 31, 64), (tx - 35, 286, 70, 90))
            pygame.draw.rect(screen, (118, 46, 76), (tx - 48, 274, 96, 14))
            pygame.draw.rect(screen, (118, 46, 76), (tx - 37, 364, 74, 20))
            pygame.draw.polygon(screen, (154, 58, 89),
                                ((tx - 32, 280), (tx, 248), (tx + 34, 280)))
            pygame.draw.circle(screen, (239, 94, 129), (tx, 301), 5)

        floor_y = GROUND_Y - 5
        for world_x in range(start, end, 48):
            px = round(world_x - camera.offset.x)
            pygame.draw.line(screen, mortar, (px, floor_y), (px + 24, floor_y), 2)

    def _draw_boss_arena_gate(self, screen, camera):
        if not self.boss_arena:
            return
        start, end = self.boss_arena
        theme = self.layout.THEME
        stone = (39, 79, 103) if theme == "crystal" else (76, 43, 75)
        glow = (86, 209, 245) if theme == "crystal" else (244, 73, 121)
        for world_x in (start, end - 22):
            x = round(world_x - camera.offset.x)
            if x < -70 or x > screen.get_width() + 70:
                continue
            pygame.draw.rect(screen, stone, (x - 34, GROUND_Y - 145, 18, 145))
            pygame.draw.rect(screen, stone, (x + 18, GROUND_Y - 145, 18, 145))
            pygame.draw.rect(screen, glow, (x - 40, GROUND_Y - 151, 66, 9))
            pygame.draw.arc(screen, stone, (x - 35, GROUND_Y - 175, 72, 70), 0.0, 3.14159, 8)
            if self.boss_arena_active:
                gate = pygame.Rect(x - 9, GROUND_Y - 142, 22, 142)
                pygame.draw.rect(screen, (12, 27, 42), gate)
                pygame.draw.rect(screen, glow, gate, 2)
                for y in range(gate.top + 12, gate.bottom, 24):
                    pygame.draw.line(screen, glow, (gate.left + 3, y), (gate.right - 3, y), 2)
    def _draw_pits(self, screen, camera, view_left, view_right):
        theme = self.layout.THEME
        for pit_x, pit_width in self.pits:
            if pit_x + pit_width < view_left or pit_x > view_right:
                continue

            left = pit_x - round(camera.offset.x)
            right = left + pit_width
            if theme == "ember":
                deep, near, shimmer = (87, 31, 33), (148, 55, 37), (255, 148, 61)
            elif theme == "drowned":
                deep, near, shimmer = (9, 47, 65), (18, 83, 100), (106, 218, 222)
            elif theme == "forest":
                deep, near, shimmer = (11, 30, 37), (17, 45, 49), (65, 112, 107)
            elif theme == "catacombs":
                deep, near, shimmer = (22, 31, 48), (34, 55, 74), (116, 154, 178)
            elif theme == "abyss":
                deep, near, shimmer = (19, 13, 42), (45, 27, 70), (166, 115, 218)
            else:
                deep, near, shimmer = (16, 44, 64), (21, 69, 91), ENVIRONMENTS.get(theme, ENVIRONMENTS["forest"])["glow"]
            pygame.draw.rect(screen, deep, (left, GROUND_Y, pit_width, screen.get_height() - GROUND_Y))
            pygame.draw.rect(screen, near, (left, GROUND_Y + 24, pit_width, screen.get_height() - GROUND_Y - 24))
            pygame.draw.line(screen, shimmer, (left, GROUND_Y + 5), (right, GROUND_Y + 5), 2 if theme == "forest" else 3)
            wave_step = 38 if theme == "forest" else 28
            for wave_x in range(left + 8, right, wave_step):
                pygame.draw.rect(screen, shimmer, (wave_x, GROUND_Y + 2, 7 if theme == "forest" else 10, 2 if theme == "forest" else 3))
                pygame.draw.rect(screen, near, (wave_x + 5, GROUND_Y + 18, 3, 4))
            pygame.draw.line(screen, near, (left, GROUND_Y), (left + 10, screen.get_height()), 3)
            pygame.draw.line(screen, near, (right, GROUND_Y), (right - 10, screen.get_height()), 3)

    def _draw_hazards(self, screen, camera, view_left, view_right):
        glow = ENVIRONMENTS.get(self.layout.THEME, ENVIRONMENTS["forest"])["glow"]
        for x, baseline_y, width, spike_height in self.hazard_visuals:
            if x + width < view_left or x > view_right:
                continue

            left = x - round(camera.offset.x)
            base_y = baseline_y
            pygame.draw.rect(
                screen,
                (39, 43, 62),
                (left, base_y - 4, width, 8),
            )

            for spike_left in range(left, left + width, 24):
                spike_right = min(spike_left + 24, left + width)
                if spike_right - spike_left < 8:
                    continue
                point_x = (spike_left + spike_right) // 2
                points = [
                    (spike_left, base_y),
                    (point_x, base_y - spike_height),
                    (spike_right, base_y),
                ]
                pygame.draw.polygon(screen, (143, 157, 177), points)
                pygame.draw.polygon(screen, (42, 48, 68), points, 2)
                pygame.draw.line(
                    screen,
                    glow,
                    (point_x, base_y - spike_height + 5),
                    (point_x, base_y - 7),
                    2,
                )

    def _draw_moving_platform(self, screen, camera, rect, theme=None):
        area = camera.apply(rect)
        x, y = area.topleft
        width, height = area.size
        pygame.draw.rect(screen, (54, 40, 34), (x, y + 23, width, max(1, height - 23)))
        for tile_y in range(y + 25, y + height, TILE):
            piece_height = min(TILE, y + height - tile_y)
            for tile_x in range(x, x + width, TILE):
                piece_width = min(TILE, x + width - tile_x)
                variant = ((tile_x - x) // TILE + tile_y // TILE) % len(self.ground_fill_tiles)
                tile = self.ground_fill_tiles[variant]
                screen.blit(tile.subsurface(pygame.Rect(0, 0, piece_width, piece_height)), (tile_x, tile_y))
        self._draw_platform_top(screen, x, y, width)

    def _draw_ground(self, screen, camera, rect):
        first_world_x = (rect.left // TILE) * TILE
        last_world_x = rect.right
        bottom = min(rect.bottom, screen.get_height())

        for world_x in range(first_world_x, last_world_x, TILE):
            x = world_x - round(camera.offset.x)
            tile_index = world_x // TILE
            for y in range(rect.top, bottom, TILE):
                if y == rect.top:
                    tile = self.tile_ground
                else:
                    variant = (tile_index + y // TILE) % len(self.ground_fill_tiles)
                    tile = self.ground_fill_tiles[variant]
                screen.blit(tile, (x, y))

    def _draw_raised_ground(self, screen, camera, rect):
        left = rect.left - round(camera.offset.x)
        for tile_x in range(left, left + rect.width, TILE):
            screen.blit(self.tile_ground, (tile_x, rect.top))

    def _draw_ledge(self, screen, camera, rect):
        area = camera.apply(rect)
        self._draw_platform_top(screen, area.left, area.top, area.width)

    def _draw_platform_top(self, screen, x, y, width):
        for offset in range(0, width, TILE):
            piece_width = min(TILE, width - offset)
            piece = self.platform_top.subsurface(pygame.Rect(0, 0, piece_width, TILE))
            screen.blit(piece, (x + offset, y))

    def _draw_props(self, screen, camera, props, view_left, view_right):
        for world_x, base_y, prop_name, scale in props:
            image = self.prop_images[(prop_name, scale)]
            if world_x + image.get_width() < view_left or world_x > view_right:
                continue
            screen.blit(
                image,
                (round(world_x - camera.offset.x), round(base_y - image.get_height())),
            )

    @staticmethod
    def _draw_bush(screen, x, ground_y, variant, theme="valley"):
        if theme == "forest":
            leaf_sets = [((20, 49, 52), (31, 83, 78), (67, 134, 117)),
                         ((24, 43, 66), (39, 75, 101), (83, 131, 153)),
                         ((36, 50, 55), (56, 87, 72), (104, 137, 84))]
            shadow = (20, 29, 36)
        elif theme in ENVIRONMENTS:
            palettes = {
                "catacombs": ((50, 46, 65), (82, 71, 94), (134, 118, 145)),
                "crystal": ((37, 68, 103), (58, 111, 145), (128, 199, 210)),
                "village": ((78, 43, 42), (134, 66, 45), (224, 118, 53)),
                "fields": ((98, 96, 48), (158, 143, 62), (226, 194, 98)),
                "kingdom": ((47, 52, 69), (79, 83, 99), (146, 119, 116)),
                "ember": ((65, 40, 42), (128, 63, 43), (226, 107, 48)),
                "drowned": ((22, 65, 76), (40, 107, 112), (98, 180, 165)),
                "abyss": ((36, 28, 62), (71, 45, 94), (137, 85, 157)),
                "throne": ((54, 35, 65), (99, 52, 88), (174, 83, 119)),
            }
            leaf_sets = [palettes[theme]] * 3
            shadow = (24, 28, 39)
        else:
            leaf_sets = [
                ((48, 111, 73), (69, 145, 79), (104, 177, 88)),
                ((49, 104, 69), (68, 133, 75), (117, 171, 83)),
                ((52, 112, 77), (74, 149, 82), (138, 181, 92)),
            ]
            shadow = (67, 77, 55)
        dark, mid, light = leaf_sets[variant % len(leaf_sets)]
        pygame.draw.ellipse(screen, shadow, (x - 20, ground_y - 8, 46, 11))
        pygame.draw.circle(screen, dark, (x - 8, ground_y - 17), 12)
        pygame.draw.circle(screen, mid, (x + 3, ground_y - 19), 14)
        pygame.draw.circle(screen, light, (x + 11, ground_y - 14), 8)
        pygame.draw.line(screen, (45, 93, 63), (x - 10, ground_y - 8), (x + 14, ground_y - 8), 2)
        if variant == 1:
            pygame.draw.circle(screen, (255, 226, 123), (x + 4, ground_y - 24), 3)
            pygame.draw.circle(screen, (255, 226, 123), (x - 11, ground_y - 17), 2)

    def _draw_goal(self, screen, camera):
        flag = camera.apply(self.goal)
        if self.layout.THEME == "forest":
            cx = flag.centerx + 7
            floor_y = flag.bottom - 4
            pulse = 1 + 0.06 * (1 + __import__("math").sin(pygame.time.get_ticks() * 0.006))
            pygame.draw.ellipse(screen, (16, 28, 37), (cx - 38, floor_y - 6, 76, 17))
            pygame.draw.rect(screen, (39, 48, 59), (cx - 26, floor_y - 20, 52, 15))
            pygame.draw.rect(screen, (110, 127, 131), (cx - 21, floor_y - 25, 42, 7))
            half = round(12 * pulse)
            crystal = ((cx, floor_y - 76), (cx + half, floor_y - 53), (cx + 8, floor_y - 30),
                       (cx - 8, floor_y - 30), (cx - half, floor_y - 53))
            pygame.draw.polygon(screen, (57, 143, 168), crystal)
            pygame.draw.polygon(screen, (156, 234, 240), crystal, 2)
            pygame.draw.polygon(screen, (219, 253, 244), ((cx, floor_y - 70), (cx + 4, floor_y - 53), (cx, floor_y - 43)))
            pygame.draw.line(screen, (255, 220, 139), (cx - 31, floor_y - 28), (cx + 31, floor_y - 28), 2)
            return
        pygame.draw.ellipse(screen, (68, 82, 57), (flag.left - 5, flag.bottom - 9, 48, 15))
        pygame.draw.rect(screen, (105, 67, 47), (flag.left + 8, flag.top, 7, flag.height))
        pygame.draw.rect(screen, (238, 207, 126), (flag.left + 6, flag.top - 2, 11, 7), border_radius=3)
        pygame.draw.polygon(
            screen,
            (217, 75, 72),
            [
                (flag.left + 15, flag.top + 4),
                (flag.right + 2, flag.top + 17),
                (flag.left + 15, flag.top + 32),
            ],
        )
        pygame.draw.line(
            screen,
            (247, 130, 96),
            (flag.left + 16, flag.top + 8),
            (flag.right - 3, flag.top + 17),
            2,
        )
        pygame.draw.rect(screen, (183, 132, 73), (flag.left, flag.bottom - 8, 32, 8), border_radius=3)
