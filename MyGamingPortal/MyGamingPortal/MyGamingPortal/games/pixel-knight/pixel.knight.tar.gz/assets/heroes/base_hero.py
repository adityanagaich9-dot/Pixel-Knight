"""Base hero class defining common stats, abilities, sprites, and combat behaviors."""

import math
import pygame


class BaseHero:
    def __init__(self, hero_id, name, role, color, accent, base_hero="knight"):
        self.hero_id = hero_id
        self.name = name
        self.role = role
        self.color = color
        self.accent = accent
        self.base_hero = base_hero  # "knight", "archer", "choco", or "ranger"
        
        # Base stats
        self.max_health = 5
        self.speed_mult = 1.0
        self.attack_range_mult = 1.0
        self.damage_mult = 1
        self.defense_mult = 1.0
        self.ability_cooldown = 5.0
        
        # Descriptions
        self.perk = ""
        self.ability_name = "SPECIAL ABILITY"
        self.ability_desc = "Activates hero's unique special power"
        self.unlock_type = "free"
        self.unlock_desc = "UNLOCKED BY DEFAULT"
        self.sprite_tint = None

    def trigger_ability(self, player, game):
        """Executed when the player presses the Ability key (Q or Mobile Ability button)."""
        pass
