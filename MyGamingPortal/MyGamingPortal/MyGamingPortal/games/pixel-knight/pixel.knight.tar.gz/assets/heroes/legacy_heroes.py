import pygame
from .base_hero import BaseHero


class ClassicKnight(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="knight",
            name="KNIGHT",
            role="SWORD & SHIELD",
            color=(80, 220, 255),
            accent=(190, 240, 255),
            base_hero="knight"
        )
        self.perk = "Heavy Strikes / Stronger Guard"
        self.ability_name = "SHIELD SLAM"
        self.ability_desc = "Shield thrust that staggers & knocks back front enemies"
        self.ability_cooldown = 4.0
        self.max_health = 5
        self.speed_mult = 1.0
        self.attack_range_mult = 1.18
        self.damage_mult = 1
        self.defense_mult = 1.0
        self.unlock_type = "free"
        self.unlock_desc = "UNLOCKED BY DEFAULT"
        self.sprite_tint = None

    def trigger_ability(self, player, game):
        # Shield slam forward
        front_box = pygame.Rect(
            player.rect.centerx if player.facing > 0 else player.rect.centerx - 70,
            player.rect.top,
            70,
            player.rect.height
        )
        for enemy in game.enemies:
            if enemy.alive and front_box.colliderect(enemy.rect):
                defeated = enemy.take_hit()
                enemy.rect.x += player.facing * 35
                game.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, player.facing, heavy=True)
                if defeated:
                    game.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    game._award_coin()
                    game.assets.play("coin")
        game.effects.impact_ring(player.rect.centerx + player.facing * 30, player.rect.centery, (100, 220, 255), heavy=True)
        game.effects.camera_shake(4, 0.12)
        game.assets.play("tap")


class NightRanger(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="ranger",
            name="NIGHT RANGER",
            role="SPEED & AGILITY",
            color=(184, 130, 255),
            accent=(230, 195, 255),
            base_hero="ranger"
        )
        self.perk = "Fast Movement / Quick Dash"
        self.ability_name = "SHADOW STEP"
        self.ability_desc = "Quick burst dash leaving decoy sparks"
        self.ability_cooldown = 3.5
        self.max_health = 5
        self.speed_mult = 1.24
        self.attack_range_mult = 0.88
        self.damage_mult = 1
        self.defense_mult = 1.0
        self.unlock_type = "free"
        self.unlock_desc = "UNLOCKED BY DEFAULT"
        self.sprite_tint = (184, 130, 255)

    def trigger_ability(self, player, game):
        player.invulnerable = max(player.invulnerable, 0.3)
        player.velocity.x = player.facing * 680
        player.dashing = True
        player.dash_timer = 0.22
        game.effects.dash_burst(player.rect.centerx, player.rect.centery, player.facing)
        game.assets.play("tap")


class FlameReaper(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="mage",
            name="FLAME REAPER",
            role="ARCANE POWER",
            color=(255, 112, 48),
            accent=(255, 205, 90),
            base_hero="mage"
        )
        self.perk = "Burning Aura / Wider Reach"
        self.ability_name = "FIRE BURST"
        self.ability_desc = "Ignites ring of fire around the reaper"
        self.ability_cooldown = 4.5
        self.max_health = 5
        self.speed_mult = 0.92
        self.attack_range_mult = 1.05
        self.damage_mult = 1
        self.defense_mult = 1.0
        self.unlock_type = "free"
        self.unlock_desc = "UNLOCKED BY DEFAULT"
        self.sprite_tint = (255, 112, 48)

    def trigger_ability(self, player, game):
        game.effects.flame_burst(player.rect.centerx, player.rect.centery)
        burst_area = player.rect.inflate(110, 60)
        for enemy in game.enemies:
            if enemy.alive and burst_area.colliderect(enemy.rect):
                defeated = enemy.take_hit()
                game.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, player.facing, heavy=True)
                if defeated:
                    game.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    game._award_coin()
                    game.assets.play("coin")
        game.assets.play("tap")


class PixelArcher(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="archer",
            name="PIXEL ARCHER",
            role="BOW & ARROWS",
            color=(99, 242, 84),
            accent=(195, 255, 140),
            base_hero="archer"
        )
        self.perk = "Long Shots / Multi-Shot Skill"
        self.ability_name = "ARROW RAIN"
        self.ability_desc = "Triple piercing arrow volley"
        self.ability_cooldown = 4.0
        self.max_health = 5
        self.speed_mult = 1.06
        self.attack_range_mult = 1.0
        self.damage_mult = 1
        self.defense_mult = 1.0
        self.unlock_type = "free"
        self.unlock_desc = "UNLOCKED BY DEFAULT"
        self.sprite_tint = None

    def trigger_ability(self, player, game):
        from projectile import Arrow
        y = player.rect.centery - 4
        for dy in (-12, 0, 12):
            arrow = Arrow(player.rect.centerx + player.facing * 24, y + dy, player.facing, (150, 255, 100))
            arrow.speed = 650
            game.player_arrows.append(arrow)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (120, 255, 100))
        game.assets.play("tap")


class ChocoWarrior(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="choco",
            name="CHOCO WARRIOR",
            role="CHOCOLATE GUN",
            color=(255, 139, 52),
            accent=(255, 215, 110),
            base_hero="choco"
        )
        self.perk = "Ranged Shots / Chocolate Rain"
        self.ability_name = "CHOCO METEOR"
        self.ability_desc = "Calls down delicious chocolate meteors"
        self.ability_cooldown = 5.0
        self.max_health = 5
        self.speed_mult = 1.0
        self.attack_range_mult = 1.0
        self.damage_mult = 1
        self.defense_mult = 1.0
        self.unlock_type = "coins"
        self.unlock_coins = 50
        self.unlock_desc = "50 GOLD"
        self.sprite_tint = None

    def trigger_ability(self, player, game):
        game.activate_chocolate_rain()
