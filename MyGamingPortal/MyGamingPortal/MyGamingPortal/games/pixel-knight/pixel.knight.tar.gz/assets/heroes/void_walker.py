"""Void Walker hero implementation."""

from .base_hero import BaseHero


class VoidWalker(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="void_walker",
            name="VOID WALKER",
            role="DIMENSIONAL SCOUT",
            color=(180, 75, 255),
            accent=(230, 160, 255),
            base_hero="ranger"
        )
        self.perk = "Rift Step / Extreme Speed"
        self.ability_name = "RIFT STEP"
        self.ability_desc = "Teleports instantaneously forward, rending spacetime"
        self.ability_cooldown = 3.8
        self.max_health = 4
        self.speed_mult = 1.32
        self.attack_range_mult = 1.0
        self.damage_mult = 1
        self.defense_mult = 0.85
        self.unlock_type = "level"
        self.unlock_level = 8
        self.unlock_desc = "REACH LEVEL 8"
        self.sprite_tint = (195, 105, 255)

    def trigger_ability(self, player, game):
        # Origin rift
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (190, 80, 255), heavy=True)
        
        teleport_dist = player.facing * 180
        target_x = player.rect.x + teleport_dist
        target_x = max(20, min(game.world.world_width - 50, target_x))
        
        # Check enemies in path
        path_rect = player.rect.copy()
        if player.facing > 0:
            path_rect.width = target_x - player.rect.x + player.rect.width
        else:
            path_rect.width = player.rect.right - target_x
            path_rect.x = target_x
            
        for enemy in game.enemies:
            if enemy.alive and path_rect.colliderect(enemy.rect):
                defeated = enemy.take_hit()
                game.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, player.facing, heavy=True)
                if defeated:
                    game.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    game._award_coin()
                    game.assets.play("coin")
                    
        player.rect.x = target_x
        player.invulnerable = max(player.invulnerable, 0.4)
        
        # Destination rift
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (220, 140, 255), heavy=True)
        game.effects.camera_shake(4, 0.12)
        game.assets.play("tap")
