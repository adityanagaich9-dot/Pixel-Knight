"""Inferno Knight hero implementation."""

from .base_hero import BaseHero
from hero_abilities import FlameWaveProjectile


class InfernoKnight(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="inferno_knight",
            name="INFERNO KNIGHT",
            role="HIGH ATTACK BRAWLER",
            color=(255, 95, 40),
            accent=(255, 200, 80),
            base_hero="knight"
        )
        self.perk = "Flame Wave / Fiery Cleaves"
        self.ability_name = "FLAME WAVE"
        self.ability_desc = "Sends a surging flame wave across the ground"
        self.ability_cooldown = 5.5
        self.max_health = 5
        self.speed_mult = 0.98
        self.attack_range_mult = 1.2
        self.damage_mult = 2
        self.defense_mult = 1.0
        self.unlock_type = "level"
        self.unlock_level = 3
        self.unlock_desc = "REACH LEVEL 3"
        self.sprite_tint = (255, 110, 50)

    def trigger_ability(self, player, game):
        wave = FlameWaveProjectile(
            player.rect.centerx + player.facing * 20,
            player.rect.bottom,
            player.facing
        )
        game.active_abilities.append(wave)
        game.effects.camera_shake(5, 0.16)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (255, 110, 40), heavy=True)
        game.assets.play("tap")
