"""Thorn Ranger hero implementation."""

from .base_hero import BaseHero
from projectile import Arrow


class ThornRanger(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="thorn_ranger",
            name="THORN RANGER",
            role="MARKSMAN",
            color=(105, 220, 95),
            accent=(210, 255, 120),
            base_hero="archer"
        )
        self.perk = "Piercing Volley / Long Range"
        self.ability_name = "PIERCING VOLLEY"
        self.ability_desc = "Fires a fan of 5 penetrating razor thorn arrows"
        self.ability_cooldown = 4.2
        self.max_health = 4
        self.speed_mult = 1.12
        self.attack_range_mult = 1.4
        self.damage_mult = 1
        self.defense_mult = 0.9
        self.unlock_type = "level"
        self.unlock_level = 6
        self.unlock_desc = "REACH LEVEL 6"
        self.sprite_tint = (120, 230, 105)

    def trigger_ability(self, player, game):
        # Fire 5 arrows with different y spreads
        center_y = player.rect.centery - 4
        offsets = (-16, -8, 0, 8, 16)
        for off in offsets:
            arrow = Arrow(
                player.rect.centerx + player.facing * 24,
                center_y + off,
                player.facing,
                color=(140, 255, 120)
            )
            arrow.speed = 720
            game.player_arrows.append(arrow)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (120, 240, 110))
        game.assets.play("tap")
