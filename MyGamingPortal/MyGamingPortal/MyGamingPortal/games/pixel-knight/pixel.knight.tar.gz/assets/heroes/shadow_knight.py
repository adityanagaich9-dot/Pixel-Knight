"""Shadow Knight hero implementation."""

from .base_hero import BaseHero


class ShadowKnight(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="shadow_knight",
            name="SHADOW KNIGHT",
            role="AGILE ASSASSIN",
            color=(140, 80, 210),
            accent=(210, 160, 255),
            base_hero="ranger"
        )
        self.perk = "Shadow Dash / High Mobility"
        self.ability_name = "SHADOW DASH"
        self.ability_desc = "Dashes through enemies while dealing dark damage"
        self.ability_cooldown = 4.0
        self.max_health = 4
        self.speed_mult = 1.25
        self.attack_range_mult = 0.95
        self.damage_mult = 1
        self.defense_mult = 0.9
        self.unlock_type = "level"
        self.unlock_level = 2
        self.unlock_desc = "REACH LEVEL 2"
        self.sprite_tint = (150, 95, 220)

    def trigger_ability(self, player, game):
        # Shadow burst dash
        player.invulnerable = max(player.invulnerable, 0.45)
        player.velocity.x = player.facing * 750
        player.dashing = True
        player.dash_timer = 0.30
        
        # Damage enemies in front
        dash_box = player.rect.inflate(120, 20)
        for enemy in game.enemies:
            if enemy.alive and dash_box.colliderect(enemy.rect):
                defeated = enemy.take_hit()
                game.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, player.facing, heavy=True)
                if defeated:
                    game.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    game._award_coin()
                    game.assets.play("coin")
        
        game.effects.screen_flash((150, 70, 230), 0.05)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (190, 110, 255), heavy=True)
        game.assets.play("tap")
