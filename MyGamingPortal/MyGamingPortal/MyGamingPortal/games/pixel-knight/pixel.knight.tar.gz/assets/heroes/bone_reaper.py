"""Bone Reaper hero implementation."""

from .base_hero import BaseHero
from hero_abilities import SoulHarvestAura


class BoneReaper(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="bone_reaper",
            name="BONE REAPER",
            role="SPECTRAL SLAYER",
            color=(195, 215, 195),
            accent=(140, 245, 160),
            base_hero="knight"
        )
        self.perk = "Soul Harvest / High Ability DPS"
        self.ability_name = "SOUL HARVEST"
        self.ability_desc = "Summons ghost scythes that spin & reap surrounding foes"
        self.ability_cooldown = 4.8
        self.max_health = 4
        self.speed_mult = 1.08
        self.attack_range_mult = 1.25
        self.damage_mult = 1
        self.defense_mult = 0.95
        self.unlock_type = "level"
        self.unlock_level = 5
        self.unlock_desc = "REACH LEVEL 5"
        self.sprite_tint = (185, 205, 185)

    def trigger_ability(self, player, game):
        aura = SoulHarvestAura(player.rect.centerx, player.rect.centery)
        game.active_abilities.append(aura)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (160, 240, 180), heavy=True)
        game.effects.screen_flash((180, 255, 190), 0.04)
        game.assets.play("tap")
