"""Frost Knight hero implementation."""

from .base_hero import BaseHero
from hero_abilities import FrostNovaBurst


class FrostKnight(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="frost_knight",
            name="FROST KNIGHT",
            role="BALANCED WARRIOR",
            color=(95, 205, 245),
            accent=(180, 240, 255),
            base_hero="knight"
        )
        self.perk = "Frost Nova / Slowing Strikes"
        self.ability_name = "FROST NOVA"
        self.ability_desc = "Freezes & damages nearby enemies in a frosty blast"
        self.ability_cooldown = 5.0
        self.max_health = 5
        self.speed_mult = 1.0
        self.attack_range_mult = 1.15
        self.damage_mult = 1
        self.defense_mult = 1.0
        self.unlock_type = "free"
        self.unlock_desc = "UNLOCKED BY DEFAULT"
        self.sprite_tint = (120, 215, 255)

    def trigger_ability(self, player, game):
        nova = FrostNovaBurst(player.rect.centerx, player.rect.centery)
        game.active_abilities.append(nova)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (120, 220, 255), heavy=True)
        game.effects.camera_shake(4, 0.15)
        game.effects.screen_flash((180, 240, 255), 0.04)
        game.assets.play("tap")
