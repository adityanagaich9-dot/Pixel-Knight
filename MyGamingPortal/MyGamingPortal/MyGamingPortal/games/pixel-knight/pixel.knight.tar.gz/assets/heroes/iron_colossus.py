"""Iron Colossus hero implementation."""

from .base_hero import BaseHero
from hero_abilities import EarthshatterWave


class IronColossus(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="iron_colossus",
            name="IRON COLOSSUS",
            role="HEAVY JUGGERNAUT",
            color=(145, 155, 175),
            accent=(210, 220, 235),
            base_hero="knight"
        )
        self.perk = "Earthshatter / Ironclad Armor"
        self.ability_name = "EARTHSHATTER"
        self.ability_desc = "Slams ground creating shockwaves and screen shake"
        self.ability_cooldown = 6.0
        self.max_health = 7
        self.speed_mult = 0.82
        self.attack_range_mult = 1.3
        self.damage_mult = 2
        self.defense_mult = 1.5
        self.unlock_type = "coins"
        self.unlock_coins = 100
        self.unlock_desc = "COLLECT 100 GOLD"
        self.sprite_tint = (160, 170, 190)

    def trigger_ability(self, player, game):
        wave = EarthshatterWave(player.rect.centerx, player.rect.bottom)
        game.active_abilities.append(wave)
        game.effects.camera_shake(10, 0.25)
        game.effects.impact_ring(player.rect.centerx, player.rect.bottom, (200, 190, 170), heavy=True)
        game.assets.play("tap")
