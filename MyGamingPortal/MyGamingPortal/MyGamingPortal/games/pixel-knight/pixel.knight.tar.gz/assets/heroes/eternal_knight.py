"""Eternal Knight hero implementation."""

from .base_hero import BaseHero
from hero_abilities import CelestialRiftVortex


class EternalKnight(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="eternal_knight",
            name="ETERNAL KNIGHT",
            role="ASCENDED CHAMPION",
            color=(245, 230, 140),
            accent=(140, 240, 255),
            base_hero="knight"
        )
        self.perk = "Celestial Rift / Cosmic Mastery"
        self.ability_name = "CELESTIAL RIFT"
        self.ability_desc = "Opens a cosmic vortex that obliterates enemies"
        self.ability_cooldown = 7.0
        self.max_health = 6
        self.speed_mult = 1.18
        self.attack_range_mult = 1.3
        self.damage_mult = 2
        self.defense_mult = 1.2
        self.unlock_type = "boss"
        self.unlock_shards = 2
        self.unlock_desc = "COLLECT 2 BOSS RELICS"
        self.sprite_tint = (255, 240, 160)

    def trigger_ability(self, player, game):
        vortex = CelestialRiftVortex(
            player.rect.centerx + player.facing * 90,
            player.rect.centery
        )
        game.active_abilities.append(vortex)
        game.effects.camera_shake(8, 0.25)
        game.effects.screen_flash((240, 230, 180), 0.08)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (255, 240, 150), heavy=True)
        game.assets.play("tap")
