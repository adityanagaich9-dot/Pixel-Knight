"""Crimson King hero implementation."""

from .base_hero import BaseHero
from hero_abilities import FlameWaveProjectile


class CrimsonKing(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="crimson_king",
            name="CRIMSON KING",
            role="ROYAL OVERLORD",
            color=(215, 30, 45),
            accent=(255, 185, 75),
            base_hero="knight"
        )
        self.perk = "Royal Decree / Enormous Cleaves"
        self.ability_name = "ROYAL DECREE"
        self.ability_desc = "Empowers sword with a massive crimson blood wave"
        self.ability_cooldown = 5.5
        self.max_health = 6
        self.speed_mult = 1.05
        self.attack_range_mult = 1.35
        self.damage_mult = 2
        self.defense_mult = 1.1
        self.unlock_type = "boss"
        self.unlock_shards = 1
        self.unlock_desc = "DEFEAT A CAMPAIGN BOSS"
        self.sprite_tint = (230, 45, 60)

    def trigger_ability(self, player, game):
        # Heavy crimson wave
        wave = FlameWaveProjectile(
            player.rect.centerx + player.facing * 20,
            player.rect.bottom,
            player.facing
        )
        wave.speed = 520.0
        game.active_abilities.append(wave)
        game.effects.camera_shake(7, 0.2)
        game.effects.screen_flash((230, 30, 50), 0.06)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (230, 40, 60), heavy=True)
        game.assets.play("tap")
