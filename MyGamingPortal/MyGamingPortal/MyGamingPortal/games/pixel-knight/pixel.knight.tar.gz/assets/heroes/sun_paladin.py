"""Sun Paladin hero implementation."""

from .base_hero import BaseHero
from hero_abilities import SolarBurstExplosion


class SunPaladin(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="sun_paladin",
            name="SUN PALADIN",
            role="HOLY DEFENDER",
            color=(255, 215, 75),
            accent=(255, 245, 170),
            base_hero="knight"
        )
        self.perk = "Solar Burst / Radiant Guard"
        self.ability_name = "SOLAR BURST"
        self.ability_desc = "Detonates blinding holy light that stuns & burns"
        self.ability_cooldown = 5.0
        self.max_health = 6
        self.speed_mult = 0.95
        self.attack_range_mult = 1.1
        self.damage_mult = 1
        self.defense_mult = 1.25
        self.unlock_type = "level"
        self.unlock_level = 7
        self.unlock_desc = "REACH LEVEL 7"
        self.sprite_tint = (255, 225, 95)

    def trigger_ability(self, player, game):
        burst = SolarBurstExplosion(player.rect.centerx, player.rect.centery)
        game.active_abilities.append(burst)
        game.effects.camera_shake(6, 0.18)
        game.effects.screen_flash((255, 240, 160), 0.08)
        game.assets.play("tap")
