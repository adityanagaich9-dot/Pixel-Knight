"""Night Assassin hero implementation."""

from .base_hero import BaseHero


class NightAssassin(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="night_assassin",
            name="NIGHT ASSASSIN",
            role="LETHAL STRIKER",
            color=(235, 60, 110),
            accent=(255, 150, 180),
            base_hero="ranger"
        )
        self.perk = "Phantom Strike / Critical Hits"
        self.ability_name = "PHANTOM STRIKE"
        self.ability_desc = "Unleashes lightning-fast multi-slashes on all nearby foes"
        self.ability_cooldown = 4.5
        self.max_health = 4
        self.speed_mult = 1.28
        self.attack_range_mult = 1.15
        self.damage_mult = 2
        self.defense_mult = 0.88
        self.unlock_type = "level"
        self.unlock_level = 9
        self.unlock_desc = "REACH LEVEL 9"
        self.sprite_tint = (245, 80, 130)

    def trigger_ability(self, player, game):
        # Immediate 3 multi-slashes to nearby enemies
        strike_range = 140
        targets = [e for e in game.enemies if e.alive and abs(e.rect.centerx - player.rect.centerx) <= strike_range]
        for enemy in targets:
            # 2 hits
            defeated = enemy.take_hit()
            if not defeated:
                defeated = enemy.take_hit()
            game.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, player.facing, heavy=True)
            game.effects.floating_text(enemy.rect.centerx, enemy.rect.top - 10, "PHANTOM", (255, 80, 140))
            if defeated:
                game.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                game._award_coin()
                game.assets.play("coin")
                
        game.effects.camera_shake(5, 0.15)
        game.effects.screen_flash((255, 70, 120), 0.05)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (255, 90, 140), heavy=True)
        game.assets.play("tap")
