"""Glacier Knight hero implementation."""

from .base_hero import BaseHero
from hero_abilities import IceLanceProjectile


class GlacierKnight(BaseHero):
    def __init__(self):
        super().__init__(
            hero_id="glacier_knight",
            name="GLACIER KNIGHT",
            role="FROST TANK",
            color=(130, 225, 240),
            accent=(220, 250, 255),
            base_hero="knight"
        )
        self.perk = "Ice Lance / Tough Plating"
        self.ability_name = "ICE LANCE"
        self.ability_desc = "Fires a giant piercing ice javelin forward"
        self.ability_cooldown = 4.5
        self.max_health = 6
        self.speed_mult = 0.88
        self.attack_range_mult = 1.1
        self.damage_mult = 1
        self.defense_mult = 1.3
        self.unlock_type = "level"
        self.unlock_level = 4
        self.unlock_desc = "REACH LEVEL 4"
        self.sprite_tint = (160, 235, 255)

    def trigger_ability(self, player, game):
        lance = IceLanceProjectile(
            player.rect.centerx + player.facing * 24,
            player.rect.centery,
            player.facing
        )
        game.active_abilities.append(lance)
        game.effects.impact_ring(player.rect.centerx, player.rect.centery, (160, 235, 255), heavy=True)
        game.assets.play("tap")
