"""Slimes, quick cave bats, and glowing underworld wisps."""
import math
import pygame


class Slime:
    def __init__(self, x, y, frames, left, right, health=1):
        self.frames = frames
        self.rect = pygame.Rect(x, y, 36, 28)
        self.left, self.right = left, right
        self.direction = 1
        self.speed = 62
        self.home_x = float(self.rect.centerx)
        self.leash_distance = 520.0
        self.detect_distance = 360.0
        self.ai_state = "patrol"
        self.aggro = False
        self.idle_timer = 0.0
        self.time = 0.0
        self.alive = True
        self.max_health = max(1, int(health))
        self.health = self.max_health

    def _patrol_step(self, dt):
        # At the end of the assigned zone, pause briefly in an idle pose before
        # turning around.  This removes the old one-frame reverse/jitter.
        if self.idle_timer > 0:
            self.idle_timer = max(0.0, self.idle_timer - dt)
            self.time += dt
            if self.idle_timer <= 0:
                self.direction *= -1
            return

        step = round(self.direction * self.speed * dt)
        next_left = self.rect.left + step
        next_right = self.rect.right + step
        if next_left <= self.left:
            self.rect.left = self.left
            self.idle_timer = 0.32
            self.time += dt
            return
        if next_right >= self.right:
            self.rect.right = self.right
            self.idle_timer = 0.32
            self.time += dt
            return
        self.rect.x += step
        self.time += dt

    def update(self, dt):
        if not self.alive:
            return
        self.speed = 62
        self._patrol_step(dt)

    def update_ai(self, dt, player):
        if not self.alive:
            return
        dt = max(0.0, float(dt))
        dx = player.rect.centerx - self.rect.centerx
        home_dist = abs(self.rect.centerx - self.home_x)

        if home_dist > self.leash_distance:
            self.ai_state = "return"
            self.aggro = False
        elif abs(dx) <= self.detect_distance:
            self.ai_state = "chase"
            self.aggro = True
        else:
            self.ai_state = "patrol"
            self.aggro = False

        if self.ai_state == "chase":
            self.idle_timer = 0.0
            self.speed = 88
            if abs(dx) > 3:
                self.direction = 1 if dx > 0 else -1
            step = round(self.direction * self.speed * dt)
            # Chase is hard-limited to the assigned zone.
            self.rect.x += step
            if self.rect.left < self.left:
                self.rect.left = self.left
            if self.rect.right > self.right:
                self.rect.right = self.right
            self.time += dt

        elif self.ai_state == "return":
            self.idle_timer = 0.0
            self.speed = 120
            distance_home = self.home_x - self.rect.centerx
            if abs(distance_home) <= 3:
                self.rect.centerx = round(self.home_x)
                self.ai_state = "patrol"
                self.speed = 62
            else:
                self.direction = 1 if distance_home > 0 else -1
                step = round(self.direction * self.speed * dt)
                if abs(distance_home) <= abs(step):
                    self.rect.centerx = round(self.home_x)
                    self.ai_state = "patrol"
                    self.speed = 62
                else:
                    self.rect.x += step
            self.time += dt

        else:
            self.speed = 62
            self._patrol_step(dt)

    def take_hit(self):
        if not self.alive:
            return False
        self.health -= 1
        if self.health <= 0:
            self.alive = False
            return True
        return False

    @property
    def image(self):
        return self.frames[int(self.time * 5) % len(self.frames)]


class Crab(Slime):
    """Armored shoreline crawler with a chunky two-pose pixel walk cycle."""

    def __init__(self, x, y, left, right, health=2):
        super().__init__(x, y, self._make_frames(), left, right, health=health)
        self.rect = pygame.Rect(x, y, 40, 28)
        self.speed = 74

    @staticmethod
    def _make_frames():
        frames = []
        for pose in range(2):
            image = pygame.Surface((48, 34), pygame.SRCALPHA)
            # Dark outline / shell.
            pygame.draw.rect(image, (54, 32, 28), (11, 9, 27, 16))
            pygame.draw.rect(image, (132, 62, 43), (8, 12, 32, 13))
            pygame.draw.rect(image, (184, 86, 49), (13, 8, 22, 15))
            pygame.draw.rect(image, (218, 116, 57), (17, 11, 14, 8))
            # Eyes.
            pygame.draw.rect(image, (239, 219, 145), (16, 7, 4, 5))
            pygame.draw.rect(image, (239, 219, 145), (28, 7, 4, 5))
            pygame.draw.rect(image, (38, 27, 28), (17, 9, 2, 3))
            pygame.draw.rect(image, (38, 27, 28), (29, 9, 2, 3))
            # Claws.
            claw_y = 9 if pose == 0 else 12
            pygame.draw.line(image, (132, 62, 43), (10, 17), (3, claw_y), 4)
            pygame.draw.line(image, (38, 27, 28), (3, claw_y), (0, claw_y + 4), 2)
            pygame.draw.line(image, (132, 62, 43), (38, 17), (45, claw_y), 4)
            pygame.draw.line(image, (38, 27, 28), (45, claw_y), (48, claw_y + 4), 2)
            # Six little legs with alternating poses.
            for i, lx in enumerate((12, 18, 27, 34)):
                offset = 2 if (i + pose) % 2 else -1
                pygame.draw.line(image, (74, 42, 34), (lx, 23), (lx + offset, 30), 3)
            frames.append(image)
        return frames

    @property
    def image(self):
        return self.frames[int(self.time * 8) % len(self.frames)]


class Bat:
    """Quick flying patrol that bobs above platforms and turns at its bounds."""

    def __init__(self, x, y, left, right, health=1, kind="bat", animations=None):
        self.rect = pygame.Rect(x, y, 38, 26)
        self.left, self.right = left, right
        self.base_y = float(y)
        self.direction = 1
        self.speed = 92 if kind == "bat" else 108 if kind == "storm" else 72
        self.home_x = float(self.rect.centerx)
        self.leash_distance = 620.0
        self.detect_distance = 430.0
        self.ai_state = "patrol"
        self.time = 0.0
        self.phase = x * 0.013
        self.alive = True
        self.max_health = max(1, int(health))
        self.health = self.max_health
        self.kind = kind
        self.frames = self._make_frames(kind)
        self.animations = animations
        self.hurt_timer = 0.0
        self.dying = False
        self.death_timer = 0.0
        self.attack_timer = 0.0

    @staticmethod
    def _make_frames(kind):
        frames = []
        for pose in range(2):
            surface = pygame.Surface((44, 34), pygame.SRCALPHA)
            if kind == "bat":
                wing_top = 1 if pose == 0 else 9
                pygame.draw.polygon(surface, (38, 28, 56),
                    [(20, 15), (9, wing_top), (1, 4), (5, 23), (18, 25)])
                pygame.draw.polygon(surface, (108, 67, 129),
                    [(20, 15), (9, wing_top + 3), (4, 8), (8, 22), (18, 24)])
                pygame.draw.polygon(surface, (38, 28, 56),
                    [(23, 15), (34, wing_top), (43, 4), (39, 23), (26, 25)])
                pygame.draw.polygon(surface, (108, 67, 129),
                    [(23, 15), (34, wing_top + 3), (40, 8), (36, 22), (26, 24)])
                pygame.draw.ellipse(surface, (62, 38, 78), (15, 10, 15, 17))
                pygame.draw.polygon(surface, (62, 38, 78), [(16, 14), (16, 5), (22, 12)])
                pygame.draw.polygon(surface, (62, 38, 78), [(28, 14), (29, 5), (23, 12)])
                pygame.draw.rect(surface, (245, 116, 91), (18, 17, 3, 3))
                pygame.draw.rect(surface, (245, 116, 91), (25, 17, 3, 3))
            elif kind == "storm":
                pygame.draw.ellipse(surface, (31, 39, 83), (7, 4, 30, 27))
                pygame.draw.ellipse(surface, (82, 123, 214), (11, 8, 22, 19))
                pygame.draw.ellipse(surface, (184, 222, 255), (17, 13, 10, 9))
                pygame.draw.lines(surface, (222, 237, 255), False,
                    [(8, 3), (3, 11), (9, 13), (2, 22)], 2)
                pygame.draw.lines(surface, (222, 237, 255), False,
                    [(36, 1), (41, 9), (35, 13), (42, 22)], 2)
            else:
                lift = 0 if pose == 0 else 4
                pygame.draw.polygon(surface, (94, 39, 37),
                    [(22, 2 + lift), (39, 17), (31, 28), (26, 33), (17, 28), (5, 17)])
                pygame.draw.ellipse(surface, (231, 91, 43), (10, 9 + lift, 24, 21))
                pygame.draw.polygon(surface, (255, 190, 70),
                    [(22, 7 + lift), (29, 19), (22, 26), (15, 19)])
                pygame.draw.rect(surface, (255, 237, 146), (20, 14 + lift, 5, 7))
            frames.append(surface)
        return frames

    def update(self, dt):
        if not self.alive:
            return
        self.time += dt
        self.rect.x += round(self.direction * self.speed * dt)
        if self.rect.left < self.left or self.rect.right > self.right:
            self.direction *= -1
            self.rect.x += round(self.direction * self.speed * dt * 2)
        bob_amount = 18 if self.kind == "bat" else 23 if self.kind == "storm" else 11
        bob_speed = 3.4 if self.kind == "bat" else 4.2 if self.kind == "storm" else 2.3
        self.rect.y = round(self.base_y + math.sin(self.time * bob_speed + self.phase) * bob_amount)

    def update_ai(self, dt, player):
        if not self.alive:
            return
        dt = max(0.0, float(dt))
        if self.dying:
            self.time += dt
            self.death_timer = max(0.0, self.death_timer - dt)
            if self.death_timer <= 0:
                self.alive = False
            return
        self.hurt_timer = max(0.0, self.hurt_timer - dt)
        self.attack_timer = max(0.0, self.attack_timer - dt)
        dx = player.rect.centerx - self.rect.centerx
        if abs(self.rect.centerx - self.home_x) > self.leash_distance:
            self.ai_state = "return"
        elif abs(dx) <= self.detect_distance:
            self.ai_state = "chase"
        else:
            self.ai_state = "patrol"
        if self.ai_state == "chase":
            self.direction = 1 if dx > 0 else -1
            if abs(dx) < 68:
                self.attack_timer = max(self.attack_timer, 0.12)
            target_y = player.rect.centery - (42 if self.kind == "bat" else 70)
            self.rect.x += round(self.direction * self.speed * 1.15 * dt)
            self.rect.y += round(max(-180, min(180, target_y - self.rect.centery)) * dt)
        elif self.ai_state == "return":
            self.direction = 1 if self.home_x > self.rect.centerx else -1
            self.rect.x += round(self.direction * self.speed * 1.25 * dt)
            self.rect.y += round((self.base_y - self.rect.centery) * dt * 2.0)
            if abs(self.rect.centerx - self.home_x) < 20:
                self.rect.centerx = round(self.home_x)
                self.ai_state = "patrol"
        else:
            self.update(dt)
            return
        self.time += dt

    def take_hit(self):
        if not self.alive or self.dying:
            return False
        self.health -= 1
        if self.health <= 0:
            if self.animations:
                self.dying = True
                self.ai_state = "death"
                self.death_timer = 0.72
            else:
                self.alive = False
            return True
        self.hurt_timer = 0.16
        return False

    @property
    def image(self):
        if self.animations:
            action = ("death" if self.dying else "hurt" if self.hurt_timer > 0
                      else "attack" if self.attack_timer > 0 else
                      "fly" if self.ai_state in ("chase", "return") else "idle")
            frames = self.animations[action]
            if self.dying:
                progress = 1.0 - self.death_timer / 0.72
                index = min(len(frames) - 1, int(progress * len(frames)))
            elif self.hurt_timer > 0:
                index = int((0.16 - self.hurt_timer) * len(frames) / 0.16)
            else:
                index = int(self.time * (12 if action == "attack" else 8)) % len(frames)
            return frames[max(0, min(index, len(frames) - 1))]
        return self.frames[int(self.time * 10) % len(self.frames)]


class FlyingDemon(Bat):
    """The supplied winged demon sprite set on the familiar flying patrol AI."""

    def __init__(self, x, y, left, right, health=3, animations=None):
        super().__init__(x, y, left, right, health=health, kind="demon", animations=animations)
        self.rect.size = (52, 42)
        self.speed = 70


class FireWisp(Bat):
    """A glowing ember spirit that patrols the later underworld stages."""

    def __init__(self, x, y, left, right, health=2):
        super().__init__(x, y, left, right, health=health, kind="wisp")


class StormOrb(Bat):
    """Fast electrical flyer with a bright blue core and wider bobbing path."""

    def __init__(self, x, y, left, right, health=2):
        super().__init__(x, y, left, right, health=health, kind="storm")


class BoneGuard(Slime):
    """Ground patrol with a shield and an animated six-pose walk cycle."""

    def __init__(self, x, y, left, right, health=2, frames=None, animations=None):
        super().__init__(x, y, frames or self._make_frames(), left, right, health=health)
        self.rect = pygame.Rect(x, y, 34, 42)
        self.speed = 58
        self.animations = animations
        self.hurt_timer = 0.0
        self.dying = False
        self.death_timer = 0.0

    def update_ai(self, dt, player):
        if self.dying:
            self.time += max(0.0, dt)
            self.death_timer = max(0.0, self.death_timer - max(0.0, dt))
            if self.death_timer <= 0:
                self.alive = False
            return
        self.hurt_timer = max(0.0, self.hurt_timer - max(0.0, dt))
        self.target_dx = player.rect.centerx - self.rect.centerx
        super().update_ai(dt, player)

    def take_hit(self):
        if not self.alive or self.dying:
            return False
        self.health -= 1
        if self.health <= 0:
            if self.animations:
                self.dying = True
                self.death_timer = 0.78
            else:
                self.alive = False
            return True
        self.hurt_timer = 0.18
        return False

    @staticmethod
    def _make_frames():
        frames = []
        # Six distinct steps keep the guard moving naturally at patrol speed.
        for pose in range(6):
            image = pygame.Surface((44, 50), pygame.SRCALPHA)
            bob = 1 if pose in (1, 2, 4, 5) else 0
            stride = round(math.sin(pose * math.tau / 6) * 4)

            # Dark hood, bone skull, and glowing eyes.
            pygame.draw.polygon(image, (50, 44, 53),
                [(8, 21 + bob), (10, 9 + bob), (21, 2 + bob), (33, 8 + bob), (36, 24 + bob)])
            pygame.draw.rect(image, (218, 207, 171), (14, 11 + bob, 18, 16))
            pygame.draw.rect(image, (53, 42, 48), (17, 17 + bob, 4, 4))
            pygame.draw.rect(image, (53, 42, 48), (25, 17 + bob, 4, 4))
            pygame.draw.rect(image, (147, 69, 61), (21, 22 + bob, 5, 3))

            # Ribs rock with the stride while the shield stays raised.
            pygame.draw.line(image, (225, 215, 184), (22, 27 + bob), (22, 40), 4)
            for rib_y in (30, 34, 38):
                pygame.draw.line(image, (224, 211, 177), (15, rib_y + bob), (29, rib_y + bob), 3)
            pygame.draw.rect(image, (102, 128, 146), (3, 27 + bob, 10, 13))
            pygame.draw.rect(image, (192, 161, 99), (5, 30 + bob, 6, 2))

            # Opposing legs and a lightly swinging sword make all six poses read as a walk.
            pygame.draw.line(image, (205, 190, 158), (20, 40), (15 + stride, 48), 4)
            pygame.draw.line(image, (205, 190, 158), (25, 40), (30 - stride, 48), 4)
            sword_y = 17 + round(math.cos(pose * math.tau / 6) * 3)
            pygame.draw.line(image, (132, 147, 156), (34, 28 + bob), (39, sword_y + 5), 3)
            pygame.draw.polygon(image, (198, 206, 199),
                [(38, sword_y + 5), (43, sword_y - 1), (41, sword_y + 8)])
            frames.append(image)
        return frames

    @property
    def image(self):
        if self.animations:
            action = ("death" if self.dying else "hurt" if self.hurt_timer > 0
                      else "attack" if self.ai_state == "chase" and
                      abs(getattr(self, "target_dx", 999)) < 54 else
                      "walk" if self.ai_state in ("chase", "return") else "idle")
            frames = self.animations[action]
            if self.dying:
                progress = 1.0 - self.death_timer / 0.78
                index = min(len(frames) - 1, int(progress * len(frames)))
            elif self.hurt_timer > 0:
                index = int((0.18 - self.hurt_timer) * len(frames) / 0.18)
            else:
                index = int(self.time * (8 if action == "attack" else 6)) % len(frames)
            return frames[max(0, min(index, len(frames) - 1))]
        return self.frames[int(self.time * 9) % len(self.frames)]


class CampaignBoss:
    """Large sprite-sheet boss with a readable health bar and bounded arena AI."""

    def __init__(self, x, y, left, right, animations, name, health=14,
                 sprite_scale=1.0, hitbox_size=(88, 100)):
        self.animations = {
            action: [
                frame if sprite_scale == 1.0 else pygame.transform.scale(
                    frame,
                    (round(frame.get_width() * sprite_scale),
                     round(frame.get_height() * sprite_scale)),
                )
                for frame in frames
            ]
            for action, frames in animations.items()
        }
        self.name = name
        self.rect = pygame.Rect(x, y, *hitbox_size)
        self.left, self.right = left, right
        self.direction = -1
        self.speed = 34 if sprite_scale > 1.0 else 42
        self.base_speed = self.speed
        self.phase = 1
        self.health = self.max_health = health
        self.alive = True
        self.dying = False
        self.death_timer = 0.0
        self.hurt_timer = 0.0
        self.attack_timer = 0.0
        self.attack_cooldown = 0.0
        self.time = 0.0
        self.ai_state = "idle"
        self.is_boss = True
        self.encounter_active = False

    def update_ai(self, dt, player):
        if not self.alive:
            return
        dt = max(0.0, float(dt))
        self.time += dt
        if not self.encounter_active:
            self.ai_state = "idle"
            return
        if self.dying:
            self.death_timer = max(0.0, self.death_timer - dt)
            if self.death_timer <= 0:
                self.alive = False
            return
        self.hurt_timer = max(0.0, self.hurt_timer - dt)
        self.attack_timer = max(0.0, self.attack_timer - dt)
        self.attack_cooldown = max(0.0, self.attack_cooldown - dt)
        dx = player.rect.centerx - self.rect.centerx
        if abs(dx) > 540:
            self.ai_state = "idle"
            return
        if abs(dx) > 6:
            self.direction = 1 if dx > 0 else -1
        enraged = self.phase >= 2
        self.speed = self.base_speed * (1.38 if enraged else 1.0)
        if abs(dx) < 132 and self.attack_cooldown <= 0:
            self.attack_timer = 0.68 if enraged else 0.55
            self.attack_cooldown = 0.98 if enraged else 1.45
        if self.attack_timer > 0:
            self.ai_state = "attack"
        elif abs(dx) > 92:
            self.ai_state = "walk"
            self.rect.x += round(self.direction * self.speed * dt)
            self.rect.left = max(self.left, min(self.rect.left, self.right - self.rect.width))
        else:
            self.ai_state = "idle"

    def take_hit(self):
        if not self.alive or self.dying or not self.encounter_active:
            return False
        self.health -= 1
        if self.phase == 1 and self.health <= self.max_health // 2:
            self.phase = 2
        if self.health <= 0:
            self.health = 0
            self.dying = True
            self.ai_state = "death"
            self.death_timer = 1.2
            return True
        self.hurt_timer = 0.22
        return False

    @property
    def image(self):
        if self.dying:
            frames, progress = self.animations["death"], 1.0 - self.death_timer / 1.2
            index = min(len(frames) - 1, int(progress * len(frames)))
        elif self.hurt_timer > 0:
            frames = self.animations["hurt"]
            index = int((0.22 - self.hurt_timer) * len(frames) / 0.22)
        else:
            action = self.ai_state if self.ai_state in self.animations else "idle"
            frames = self.animations[action]
            rate = (11 if self.phase >= 2 else 8) if action == "attack" else (7 if self.phase >= 2 else 5)
            index = int(self.time * rate) % len(frames)
        return frames[max(0, min(index, len(frames) - 1))]
