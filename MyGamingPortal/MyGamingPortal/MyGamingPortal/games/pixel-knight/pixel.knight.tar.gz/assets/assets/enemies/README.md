# Supplied enemy art

These images were supplied by the project owner. Bat animations are used for later flying enemies; the two Skeleton color sets alternate between guard encounters; Flying Demon animations are used for designated upper-route flyers; the Frost Guardian and Necromancer are campaign bosses.

The Flying Demon license is included as `FLYING_DEMON_LICENSE.txt`. It allows use as part of a game project and prohibits reselling or redistributing the art as a standalone game asset. The Bat, Skeleton, Frost Guardian, and Necromancer archives did not include license files. Confirm their original authors' terms before publishing or redistributing.
