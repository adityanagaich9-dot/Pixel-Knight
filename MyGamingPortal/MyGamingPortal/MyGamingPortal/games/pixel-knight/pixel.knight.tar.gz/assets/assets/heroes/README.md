Source: the blue-and-gold Pixel Knight sprite reference sheet attached by the user (2026-10-16).

The original showcase image has a textured background rather than an alpha channel. The game frames in knight_animation_atlas.png were cropped from the RIGHT-facing columns and keyed locally from that backdrop, then packed into fixed 64x64 cells. Animation rows: idle, walk, run, attack, defend, jump, hurt, die, skill. The Knight is mirrored in-game to face left.

No external art was sourced. The attachment did not include a license or attribution notice, so its external redistribution terms are unknown; use rights remain with the asset's owner.

`archer_reference_sheet.png` is the green Pixel Archer reference sheet attached by the user (2026-10-16). `archer_animation_atlas.png` contains the cleaned transparent gameplay frames cropped from its Idle, Walk, Run, Attack (Bow), Attack (Melee), Defend, Jump, Hurt, Death, Multi-shot, and Dash-shot panels. It is packed into 64x64 cells, scaled with nearest-neighbor sampling, and anchored at the feet. The game uses the bow sequence, with every third attack producing a three-arrow volley. Archer is a playable hero only; the sheet did not add or restore an Archer enemy.

The supplied sheet did not include a license or attribution notice. No external art was sourced; public redistribution rights for the user-provided sheets remain unverified.

`choco_warrior_reference_sheet.png` is the Choco Warrior sheet supplied by the user (2026-10-16). `choco_warrior_animation_atlas.png` contains its Idle, Run, Shoot, Jump, Hurt, and Death frames, packed into fixed 64x64 transparent cells with a shared foot anchor. The supplied checkerboard and frame guides are not present in the gameplay atlas. The old Choco Shooter artwork was removed and no external hero art was sourced. The new sheet did not include a license or attribution notice, so check with its original rights holder before public redistribution.
