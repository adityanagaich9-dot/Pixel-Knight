import asyncio
import pygame

try:
    # CD quality 44.1kHz, 16-bit, stereo, 2048 sample buffer for smooth web & desktop audio
    pygame.mixer.pre_init(44100, -16, 2, 2048)
except Exception:
    pass

from game import Game


async def main():
    pygame.init()
    try:
        await Game().run_async()
    finally:
        pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())