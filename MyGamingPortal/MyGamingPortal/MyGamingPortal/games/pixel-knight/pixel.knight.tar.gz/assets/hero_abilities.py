"""Ability projectiles, area bursts, and combat effects for each of the 12 heroes."""

import math
import random
import pygame


class FrostNovaBurst:
    """Expands in a radial freeze burst, dealing damage and slowing enemies."""
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.radius = 12.0
        self.max_radius = 85.0
        self.speed = 220.0
        self.alive = True
        self.hit_enemies = set()
        self.color = (130, 225, 255)

    def update(self, dt):
        self.radius += self.speed * dt
        if self.radius >= self.max_radius:
            self.alive = False

    def check_hit(self, enemy):
        if id(enemy) in self.hit_enemies:
            return False
        dist = math.hypot(enemy.rect.centerx - self.x, enemy.rect.centery - self.y)
        if dist <= self.radius + 15:
            self.hit_enemies.add(id(enemy))
            return True
        return False

    def draw(self, screen, camera):
        pos = camera.apply(pygame.Rect(round(self.x), round(self.y), 1, 1)).center
        r = max(2, round(self.radius))
        ratio = 1.0 - (self.radius / self.max_radius)
        alpha = max(0, min(255, int(220 * ratio)))
        surf = pygame.Surface((r * 2 + 8, r * 2 + 8), pygame.SRCALPHA)
        pygame.draw.circle(surf, (*self.color, alpha), (r + 4, r + 4), r, 4)
        pygame.draw.circle(surf, (220, 250, 255, alpha // 2), (r + 4, r + 4), max(1, r - 6), 2)
        screen.blit(surf, (pos[0] - r - 4, pos[1] - r - 4))


class FlameWaveProjectile:
    """Surges along the ground in player's facing direction, burning targets."""
    def __init__(self, x, y, direction):
        self.direction = 1 if direction >= 0 else -1
        self.rect = pygame.Rect(round(x), round(y - 28), 34, 38)
        self.speed = 460.0
        self.alive = True
        self.lifetime = 0.9
        self.hit_enemies = set()
        self.time = 0.0

    def update(self, dt, platforms=()):
        self.time += dt
        self.lifetime -= dt
        if self.lifetime <= 0:
            self.alive = False
        self.rect.x += round(self.direction * self.speed * dt)

    def check_hit(self, enemy):
        if id(enemy) in self.hit_enemies:
            return False
        if self.rect.colliderect(enemy.rect):
            self.hit_enemies.add(id(enemy))
            return True
        return False

    def draw(self, screen, camera):
        area = camera.apply(self.rect)
        cx, cy = area.center
        for i in range(4):
            offset_x = (i * 8 - 12) * self.direction
            h = 16 + math.sin(self.time * 20 + i) * 12
            color = (255, 120 + i * 30, 40)
            pygame.draw.ellipse(screen, color, (cx + offset_x - 8, area.bottom - h, 16, h))
        pygame.draw.circle(screen, (255, 230, 100), (cx, area.centery), 9)


class IceLanceProjectile:
    """Piercing massive ice lance that passes through multiple foes."""
    def __init__(self, x, y, direction):
        self.direction = 1 if direction >= 0 else -1
        self.rect = pygame.Rect(x if self.direction > 0 else x - 54, y - 8, 54, 16)
        self.speed = 640.0
        self.alive = True
        self.lifetime = 1.1
        self.hit_enemies = set()

    def update(self, dt, platforms=()):
        self.lifetime -= dt
        if self.lifetime <= 0:
            self.alive = False
        self.rect.x += round(self.direction * self.speed * dt)

    def check_hit(self, enemy):
        if id(enemy) in self.hit_enemies:
            return False
        if self.rect.colliderect(enemy.rect):
            self.hit_enemies.add(id(enemy))
            return True
        return False

    def draw(self, screen, camera):
        area = camera.apply(self.rect)
        pts = [
            (area.right if self.direction > 0 else area.left, area.centery),
            (area.left if self.direction > 0 else area.right, area.top),
            (area.left + (12 if self.direction > 0 else -12), area.centery),
            (area.left if self.direction > 0 else area.right, area.bottom),
        ]
        pygame.draw.polygon(screen, (120, 230, 255), pts)
        pygame.draw.polygon(screen, (230, 250, 255), pts, 2)


class SoulHarvestAura:
    """Orbiting spectral scythe blades that strike all around."""
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.alive = True
        self.duration = 0.75
        self.hit_enemies = set()
        self.radius = 64.0
        self.time = 0.0

    def update(self, dt, player_center=None):
        if player_center:
            self.x, self.y = player_center
        self.time += dt
        self.duration -= dt
        if self.duration <= 0:
            self.alive = False

    def check_hit(self, enemy):
        if id(enemy) in self.hit_enemies:
            return False
        dist = math.hypot(enemy.rect.centerx - self.x, enemy.rect.centery - self.y)
        if dist <= self.radius + 20:
            self.hit_enemies.add(id(enemy))
            return True
        return False

    def draw(self, screen, camera):
        pos = camera.apply(pygame.Rect(round(self.x), round(self.y), 1, 1)).center
        angle = self.time * 14.0
        for i in range(3):
            blade_ang = angle + i * (math.tau / 3)
            bx = pos[0] + math.cos(blade_ang) * self.radius
            by = pos[1] + math.sin(blade_ang) * self.radius
            pygame.draw.circle(screen, (160, 255, 180), (round(bx), round(by)), 8)
            pygame.draw.circle(screen, (230, 255, 230), (round(bx), round(by)), 4)
            pygame.draw.line(screen, (100, 220, 140), pos, (round(bx), round(by)), 2)


class SolarBurstExplosion:
    """Massive radiant sun burst with radial rays."""
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.radius = 16.0
        self.max_radius = 95.0
        self.alive = True
        self.hit_enemies = set()

    def update(self, dt):
        self.radius += 260.0 * dt
        if self.radius >= self.max_radius:
            self.alive = False

    def check_hit(self, enemy):
        if id(enemy) in self.hit_enemies:
            return False
        dist = math.hypot(enemy.rect.centerx - self.x, enemy.rect.centery - self.y)
        if dist <= self.radius + 25:
            self.hit_enemies.add(id(enemy))
            return True
        return False

    def draw(self, screen, camera):
        pos = camera.apply(pygame.Rect(round(self.x), round(self.y), 1, 1)).center
        r = max(2, round(self.radius))
        ratio = max(0.0, 1.0 - self.radius / self.max_radius)
        surf = pygame.Surface((r * 2 + 10, r * 2 + 10), pygame.SRCALPHA)
        alpha = int(240 * ratio)
        pygame.draw.circle(surf, (255, 235, 120, alpha), (r + 5, r + 5), r)
        pygame.draw.circle(surf, (255, 255, 220, alpha), (r + 5, r + 5), max(1, r // 2))
        for step in range(8):
            ang = step * (math.pi / 4)
            ox = math.cos(ang) * (r + 4)
            oy = math.sin(ang) * (r + 4)
            pygame.draw.line(surf, (255, 245, 160, alpha), (r + 5, r + 5), (r + 5 + ox, r + 5 + oy), 3)
        screen.blit(surf, (pos[0] - r - 5, pos[1] - r - 5))


class EarthshatterWave:
    """Ground-slam earth fissures that rupture both left and right."""
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.width = 16.0
        self.max_width = 150.0
        self.alive = True
        self.hit_enemies = set()

    def update(self, dt):
        self.width += 320.0 * dt
        if self.width >= self.max_width:
            self.alive = False

    def check_hit(self, enemy):
        if id(enemy) in self.hit_enemies:
            return False
        dx = abs(enemy.rect.centerx - self.x)
        dy = abs(enemy.rect.bottom - self.y)
        if dx <= self.width and dy <= 45:
            self.hit_enemies.add(id(enemy))
            return True
        return False

    def draw(self, screen, camera):
        c_left = camera.apply(pygame.Rect(round(self.x - self.width), round(self.y - 18), round(self.width * 2), 22))
        ratio = max(0.0, 1.0 - self.width / self.max_width)
        alpha = int(220 * ratio)
        surf = pygame.Surface((c_left.width, c_left.height), pygame.SRCALPHA)
        pygame.draw.rect(surf, (190, 170, 140, alpha), (0, 0, c_left.width, c_left.height))
        # Spikes
        for sx in range(0, c_left.width, 16):
            pygame.draw.polygon(surf, (240, 225, 180, alpha), [(sx, c_left.height), (sx + 8, 0), (sx + 16, c_left.height)])
        screen.blit(surf, c_left.topleft)


class CelestialRiftVortex:
    """Cosmic rift that pulls and violently shocks everything nearby."""
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.alive = True
        self.lifetime = 2.0
        self.hit_enemies = set()
        self.hit_interval = 0.25
        self.time = 0.0
        self.radius = 88.0

    def update(self, dt):
        self.time += dt
        self.lifetime -= dt
        if self.lifetime <= 0:
            self.alive = False
        # Periodic hit refresh so it deals multi-ticks
        if int((self.time - dt) / self.hit_interval) != int(self.time / self.hit_interval):
            self.hit_enemies.clear()

    def check_hit(self, enemy):
        if id(enemy) in self.hit_enemies:
            return False
        dist = math.hypot(enemy.rect.centerx - self.x, enemy.rect.centery - self.y)
        if dist <= self.radius:
            self.hit_enemies.add(id(enemy))
            return True
        return False

    def draw(self, screen, camera):
        pos = camera.apply(pygame.Rect(round(self.x), round(self.y), 1, 1)).center
        r = round(self.radius)
        surf = pygame.Surface((r * 2 + 10, r * 2 + 10), pygame.SRCALPHA)
        cx, cy = r + 5, r + 5
        pulse = 1.0 + 0.15 * math.sin(self.time * 12)
        cur_r = max(5, round(r * pulse))
        pygame.draw.circle(surf, (20, 10, 45, 180), (cx, cy), cur_r)
        pygame.draw.circle(surf, (160, 90, 255, 140), (cx, cy), cur_r, 4)
        pygame.draw.circle(surf, (255, 235, 160, 190), (cx, cy), max(2, cur_r // 3))
        # Spiral arms
        for i in range(4):
            ang = self.time * 6 + i * (math.pi / 2)
            ex = cx + math.cos(ang) * cur_r
            ey = cy + math.sin(ang) * cur_r
            pygame.draw.line(surf, (140, 230, 255, 200), (cx, cy), (ex, ey), 2)
        screen.blit(surf, (pos[0] - cx, pos[1] - cy))
