"""Player controls, sprite animation, platform physics, and invulnerability."""
import pygame
from settings import (
    PLAYER_SPEED,
    PLAYER_ACCEL,
    PLAYER_DECEL,
    JUMP_SPEED,
    GRAVITY,
    WALL_SLIDE_SPEED,
    FAST_FALL_MULTIPLIER,
    JUMP_BUFFER_TIME,
    COYOTE_TIME,
    ATTACK_COOLDOWN,
    ATTACK_DURATION,
    ATTACK_HIT_START,
    ATTACK_HIT_END,
    ATTACK_RANGE,
    MAX_HEALTH,
)

ROLL_DURATION = 0.46
ROLL_COOLDOWN = 0.52
ROLL_SPEED = 410.0
ROLL_HEIGHT = 26


from heroes import get_hero
from hero_sprites import create_hero_frames


class Player:
    def __init__(self, x, y, assets, hero_type="frost_knight"):
        self.hero_type = hero_type
        self.hero_obj = get_hero(hero_type)
        self.hero_name = self.hero_obj.name
        self.hero_color = self.hero_obj.color
        
        frames_dict = create_hero_frames(assets, hero_type)
        self.idle_frames = frames_dict["idle"]
        self.walk_frames = frames_dict["walk"]
        self.run_frames = frames_dict["run"]
        self.attack_frames = frames_dict["attack"]
        self.multi_frames = frames_dict["multi"]
        self.defend_frames = frames_dict["defend"]
        self.jump_frames = frames_dict["jump"]
        self.hurt_frames = frames_dict["hurt"]
        self.skill_frames = frames_dict["skill"]
        self.roll_frames = frames_dict["roll"]
        
        # Legacy compat for choco melee
        self.choco_melee_frames = getattr(assets, "choco_melee_frames", self.attack_frames)
        self.choco_ultimate_frames = getattr(assets, "choco_ultimate_frames", self.attack_frames)

        self.image = self.idle_frames[0]
        self.rect = pygame.Rect(x, y, 30, 48)
        self.standing_height = self.rect.height
        self.velocity = pygame.Vector2()
        self.max_health = getattr(self.hero_obj, "max_health", MAX_HEALTH)
        self.health = self.max_health
        self.coins = 0
        self.speed_bonus = 0.0
        self.shield_charges = 0
        self.ultimate_charge = 0.0
        self.facing = 1
        self.on_ground = False
        self.standing_platform = None
        self.jump_buffer_timer = 0.0
        self.coyote_timer = 0.0
        self.did_jump = False
        self.did_double_jump = False
        self.jumps_used = 0
        self.double_jump_anim_timer = 0.0
        self.double_jump_trail_timer = 0.0
        self.anim_time = 0.0
        self.invulnerable = 0.0
        self.hurt_anim_timer = 0.0
        self.spawn = pygame.Vector2(x, y)
        self.attack_timer = 0.0
        self.attack_cooldown = 0.0
        self.attack_hit_targets = set()
        self.attack_shot_fired = False
        self.attack_heavy = False
        self.attack_swing = 0.0
        self.slash_effect_spawned = False
        self.attack_range = ATTACK_RANGE * getattr(self.hero_obj, "attack_range_mult", 1.0)
        self.ability_cooldown = 0.0
        self.ability_max_cooldown = getattr(self.hero_obj, "ability_cooldown", 5.0)
        self.damage_mult = getattr(self.hero_obj, "damage_mult", 1)
        self.combo_step = 0
        self.combo_window = 0.0
        self.dash_timer = 0.0
        self.dash_cooldown = 0.0
        self.dashing = False
        self.ability_anim_timer = 0.0
        self.roll_timer = 0.0
        self.roll_cooldown = 0.0
        self.rolling = False
        self.crouched = False
        self.roll_input_was_held = False
        self.rising_from_jump = False
        self.blocking = False
        self.was_blocking = False
        self.parry_timer = 0.0
        self.last_hit_blocked = False
        self.last_hit_kind = None
        self.touching_wall = 0
        self.wall_sliding = False

    def update(self, dt, keys, platforms, jump_pressed, virtual_controls=()):
        self.invulnerable = max(0.0, self.invulnerable - dt)
        self.hurt_anim_timer = max(0.0, self.hurt_anim_timer - dt)
        self.attack_cooldown = max(0.0, self.attack_cooldown - dt)
        self.ability_cooldown = max(0.0, self.ability_cooldown - dt)
        self.ability_anim_timer = max(0.0, self.ability_anim_timer - dt)
        self.combo_window = max(0.0, self.combo_window - dt)
        self.dash_cooldown = max(0.0, self.dash_cooldown - dt)
        self.roll_cooldown = max(0.0, self.roll_cooldown - dt)
        self.roll_timer = max(0.0, self.roll_timer - dt)
        self.rolling = self.roll_timer > 0.0
        if not self.rolling and self.rect.height < self.standing_height:
            expanded = self.rect.copy()
            expanded.height = self.standing_height
            expanded.bottom = self.rect.bottom
            blocked_above = any(
                expanded.colliderect(platform)
                for platform in platforms
                if platform.height <= 100
            )
            if not blocked_above:
                self.rect = expanded
                self.crouched = False
            else:
                self.crouched = True
        self.double_jump_anim_timer = max(0.0, self.double_jump_anim_timer - dt)
        self.parry_timer = max(0.0, self.parry_timer - dt)
        if self.dash_timer > 0.0:
            self.dash_timer = max(0.0, self.dash_timer - dt)
            self.dashing = self.dash_timer > 0.0
            self.invulnerable = max(self.invulnerable, 0.08)
        else:
            self.dashing = False
        if self.attack_timer > 0.0:
            self.attack_timer = max(0.0, self.attack_timer - dt)
            self.attack_swing += dt

        virtual_controls = set(virtual_controls)
        self.did_jump = False
        self.did_double_jump = False
        self.blocking = bool(keys[pygame.K_e] or "shield" in virtual_controls) and not self.dashing and not self.rolling
        if self.blocking and not self.was_blocking:
            self.parry_timer = 0.16
        self.was_blocking = self.blocking

        # Remember a jump briefly so pressing just before landing still works.
        if jump_pressed:
            self.jump_buffer_timer = JUMP_BUFFER_TIME
        else:
            self.jump_buffer_timer = max(0.0, self.jump_buffer_timer - dt)

        # Keep jump available for a moment after walking off a platform.
        if self.on_ground:
            self.coyote_timer = COYOTE_TIME
            self.jumps_used = 0
        else:
            self.coyote_timer = max(0.0, self.coyote_timer - dt)

        axis = int(keys[pygame.K_RIGHT] or keys[pygame.K_d] or "right" in virtual_controls) - int(
            keys[pygame.K_LEFT] or keys[pygame.K_a] or "left" in virtual_controls
        )
        if axis:
            self.facing = axis
        down_held = keys[pygame.K_DOWN] or keys[pygame.K_s] or "down" in virtual_controls
        roll_pressed = down_held and not self.roll_input_was_held
        self.roll_input_was_held = down_held
        if (
            roll_pressed
            and self.on_ground
            and axis != 0
            and self.roll_cooldown <= 0.0
            and not self.crouched
            and not self.blocking
            and not self.attacking
            and not self.dashing
        ):
            foot_y = self.rect.bottom
            self.rect.height = ROLL_HEIGHT
            self.rect.bottom = foot_y
            self.roll_timer = ROLL_DURATION
            self.roll_cooldown = ROLL_COOLDOWN
            self.rolling = True
            self.crouched = False
            self.blocking = False
            self.was_blocking = False
            self.velocity.y = 0
        if self.dashing:
            self.velocity.x = self.facing * 620
        elif self.rolling:
            self.velocity.x = self.facing * ROLL_SPEED
        else:
            hero_speed = getattr(self.hero_obj, "speed_mult", 1.0)
            target_x = axis * (PLAYER_SPEED * hero_speed + self.speed_bonus)
            if self.blocking:
                target_x *= 0.38
            # Attacking briefly locks horizontal control so the sword swing feels deliberate.
            if self.attacking:
                target_x *= 0.35
            approach = PLAYER_DECEL if axis == 0 or target_x == 0 else PLAYER_ACCEL
            difference = target_x - self.velocity.x
            self.velocity.x += max(-approach * dt, min(approach * dt, difference))

        if self.jump_buffer_timer > 0:
            if self.on_ground or self.coyote_timer > 0:
                self.velocity.y = -JUMP_SPEED
                self.jumps_used = 1
                self.did_jump = True
            elif self.touching_wall and axis == self.touching_wall:
                self.velocity.y = -JUMP_SPEED * 0.92
                self.velocity.x = -self.touching_wall * 330
                self.facing = -self.touching_wall
                self.jumps_used = 1
                self.did_jump = True
                self.rising_from_jump = True
            elif self.jumps_used == 1:
                self.velocity.y = -JUMP_SPEED
                self.jumps_used = 2
                self.did_jump = True
                self.did_double_jump = True
                self.double_jump_anim_timer = 0.28
                self.double_jump_trail_timer = 0.0
                self.rising_from_jump = True
            elif self.jumps_used == 0:
                # A jump pressed just after leaving an edge remains a normal
                # first jump; the player can still use one more in the air.
                self.velocity.y = -JUMP_SPEED
                self.jumps_used = 1
                self.did_jump = True
                self.rising_from_jump = True

            if self.did_jump:
                self.on_ground = False
                self.standing_platform = None
                self.jump_buffer_timer = 0.0
                self.coyote_timer = 0.0

        self.rect.x += round(self.velocity.x * dt)
        self.touching_wall = 0
        for platform in platforms:
            # Ground pieces have open sides so the knight can enter pits.
            if platform.height > 100:
                continue
            if self.rect.colliderect(platform):
                if self.velocity.x > 0:
                    self.rect.right = platform.left
                    self.touching_wall = 1
                elif self.velocity.x < 0:
                    self.rect.left = platform.right
                    self.touching_wall = -1
        previous_bottom = self.rect.bottom
        # Variable jump height: releasing the button early cuts the jump short.
        jump_held = keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP] or "jump" in virtual_controls
        if self.rising_from_jump and self.velocity.y < -200 and not jump_held:
            self.velocity.y *= 0.5
            self.rising_from_jump = False
        if self.velocity.y >= 0:
            self.rising_from_jump = False
        self.wall_sliding = bool(
            not self.on_ground
            and self.velocity.y > 0
            and self.touching_wall
            and axis == self.touching_wall
        )
        gravity_scale = FAST_FALL_MULTIPLIER if down_held and self.velocity.y > 0 else 1.0
        self.velocity.y = min(self.velocity.y + GRAVITY * gravity_scale * dt, 1120)
        if self.wall_sliding:
            self.velocity.y = min(self.velocity.y, WALL_SLIDE_SPEED)
        self.rect.y += round(self.velocity.y * dt)
        self.on_ground = False
        self.standing_platform = None
        for platform in platforms:
            overlaps_horizontally = (
                self.rect.right > platform.left
                and self.rect.left < platform.right
            )
            crossed_platform_top = (
                self.velocity.y >= 0
                and overlaps_horizontally
                and previous_bottom <= platform.top
                and self.rect.bottom >= platform.top
            )

            if crossed_platform_top:
                self.rect.bottom = platform.top
                self.on_ground = True
                self.standing_platform = platform
                self.velocity.y = 0
                self.jumps_used = 0
            elif self.velocity.y < 0 and self.rect.colliderect(platform):
                self.rect.top = platform.bottom
                self.velocity.y = 0
        self.rect.left = max(0, self.rect.left)
        if self.dashing:
            progress = 1.0 - self.dash_timer / 0.20
            index = min(len(self.skill_frames) - 1, int(max(0.0, progress) * len(self.skill_frames)))
            self.image = self.skill_frames[index]
        elif self.hero_type == "choco" and self.ability_anim_timer > 0.0:
            progress = 1.0 - self.ability_anim_timer / 0.8
            index = min(len(self.choco_ultimate_frames) - 1, int(max(0.0, progress) * len(self.choco_ultimate_frames)))
            self.image = self.choco_ultimate_frames[index]
        elif self.rolling:
            progress = 1.0 - self.roll_timer / ROLL_DURATION
            index = min(len(self.roll_frames) - 1, int(progress * len(self.roll_frames)))
            self.image = self.roll_frames[index]
        elif self.blocking:
            self.image = self.defend_frames[-1]
        elif self.attacking:
            progress = 1.0 - self.attack_timer / ATTACK_DURATION
            if self.hero_type == "choco" and self.attack_heavy:
                frames = self.choco_melee_frames
            else:
                frames = self.multi_frames if self.hero_type == "archer" and self.combo_step == 2 else self.attack_frames
            index = min(len(frames) - 1, int(progress * len(frames)))
            self.image = frames[index]
        elif self.hurt_anim_timer > 0.0:
            progress = 1.0 - self.hurt_anim_timer / 0.28
            index = min(len(self.hurt_frames) - 1, int(max(0.0, progress) * len(self.hurt_frames)))
            self.image = self.hurt_frames[index]
        elif not self.on_ground:
            if self.velocity.y < -130:
                index = 0
            elif self.velocity.y < 140:
                index = 1
            else:
                index = 2
            self.image = self.jump_frames[index]
        elif self.crouched:
            self.image = self.roll_frames[min(3, len(self.roll_frames) - 1)]
        else:
            moving = abs(self.velocity.x) > 1
            if not moving:
                frames = self.idle_frames
                rate = 4
            elif abs(self.velocity.x) < 145:
                frames = self.walk_frames
                rate = 9
            else:
                frames = self.run_frames
                rate = 12
            self.anim_time += dt * rate
            index = int(self.anim_time) % len(frames)
            self.image = frames[index]

    @property
    def attacking(self):
        return self.attack_timer > 0.0

    @property
    def attack_active(self):
        elapsed = ATTACK_DURATION - self.attack_timer
        return self.attacking and ATTACK_HIT_START <= elapsed <= ATTACK_HIT_END

    def start_attack(self, heavy=False):
        if self.attack_cooldown > 0.0 or self.attacking or self.blocking or self.rolling or self.crouched:
            return False
        if self.hero_type == "choco" and heavy:
            self.combo_step = 2
        elif self.combo_window <= 0.0:
            self.combo_step = 0
        else:
            self.combo_step = (self.combo_step + 1) % 3
        self.attack_timer = ATTACK_DURATION
        # Later combo hits come out slightly faster and hit harder through the larger hitbox.
        base_cooldown = ATTACK_COOLDOWN - (0.08 if self.hero_type == "archer" else 0.0)
        if self.hero_type == "choco" and heavy:
            base_cooldown = 0.62
        self.attack_cooldown = max(0.12, base_cooldown - self.combo_step * 0.035)
        self.attack_hit_targets.clear()
        self.attack_shot_fired = False
        self.attack_heavy = bool(heavy)
        self.attack_swing = 0.0
        self.slash_effect_spawned = False
        self.combo_window = 0.42 if self.hero_type == "archer" else 0.32
        return True

    def start_dash(self):
        if self.dash_cooldown > 0.0 or self.dashing or self.blocking or self.rolling or self.crouched:
            return False
        self.dash_timer = 0.20 if self.hero_type == "ranger" else 0.16
        self.dash_cooldown = {"knight": 0.75, "ranger": 0.48, "mage": 0.88, "archer": 0.72}.get(self.hero_type, 0.75)
        self.velocity.y = 0
        return True

    def attack_rect(self):
        if not self.attacking:
            return pygame.Rect(0, 0, 0, 0)
        width = self.attack_range + self.combo_step * 7
        height = 38 + self.combo_step * 4
        if self.facing > 0:
            return pygame.Rect(self.rect.right - 2, self.rect.centery - height // 2, width, height)
        return pygame.Rect(self.rect.left - width + 2, self.rect.centery - height // 2, width, height)

    def hit(self, source_x):
        self.last_hit_blocked = False
        self.last_hit_kind = None
        if self.invulnerable > 0:
            return False
        source_is_front = (source_x - self.rect.centerx) * self.facing >= 0
        if self.blocking and source_is_front:
            self.last_hit_blocked = True
            self.last_hit_kind = "parry" if self.parry_timer > 0 else "shield"
            self.parry_timer = 0.0
            self.invulnerable = 0.48 if self.last_hit_kind == "parry" else 0.32
            self.velocity.y = -70 if self.last_hit_kind == "parry" else 0
            self.velocity.x = -self.facing * (105 if self.last_hit_kind == "parry" else 45)
            return False
        if self.shield_charges > 0:
            self.shield_charges -= 1
            self.last_hit_kind = "ward"
        else:
            self.health -= 1
            self.last_hit_kind = "hurt"
        self.hurt_anim_timer = 0.28
        self.invulnerable = 1.15
        self.velocity.y = -300
        self.velocity.x = -220 if self.rect.centerx < source_x else 220
        return self.health <= 0

    def respawn(self):
        self.rect.height = self.standing_height
        self.rect.topleft = self.spawn
        self.velocity.update(0, 0)
        self.health = self.max_health
        self.invulnerable = 1.5
        self.hurt_anim_timer = 0.0
        self.jump_buffer_timer = 0.0
        self.coyote_timer = 0.0
        self.jumps_used = 0
        self.did_double_jump = False
        self.double_jump_anim_timer = 0.0
        self.roll_timer = 0.0
        self.roll_cooldown = 0.0
        self.rolling = False
        self.crouched = False
        self.roll_input_was_held = False
        self.blocking = False
        self.was_blocking = False
        self.parry_timer = 0.0
        self.on_ground = False
        self.standing_platform = None
