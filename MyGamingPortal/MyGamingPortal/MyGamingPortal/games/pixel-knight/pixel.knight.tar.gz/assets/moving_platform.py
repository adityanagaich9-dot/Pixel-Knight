"""A horizontal lift the knight can ride across gaps."""

import pygame


class MovingPlatform:
    def __init__(self, start_x, end_x, y, width, speed, height=22):
        self.start_x = float(start_x)
        self.end_x = float(end_x)
        self.x = float(start_x)
        self.speed = float(speed)
        self.direction = 1
        self.delta_x = 0
        self.rect = pygame.Rect(start_x, y, width, height)

    def update(self, dt):
        old_x = self.rect.x
        self.x += self.direction * self.speed * dt

        if self.x >= self.end_x:
            self.x = self.end_x
            self.direction = -1
        elif self.x <= self.start_x:
            self.x = self.start_x
            self.direction = 1

        self.rect.x = round(self.x)
        self.delta_x = self.rect.x - old_x
