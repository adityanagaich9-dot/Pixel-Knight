"""Small reusable arrow projectile for the bow unlocked in Level 4."""

import pygame


class Arrow:
    def __init__(self, x, y, direction, color=(255, 248, 205)):
        self.direction = 1 if direction >= 0 else -1
        self.rect = pygame.Rect(x if self.direction > 0 else x - 28, y, 28, 8)
        self.color = color
        self.speed = 590
        self.alive = True
        self.trail = []
        self.time = 0.0

    def update(self, dt):
        self.time += dt
        self.rect.x += round(self.direction * self.speed * dt)
        self.trail.append((self.rect.centerx, self.rect.centery))
        if len(self.trail) > 7:
            self.trail.pop(0)
        if self.rect.right < 0 or self.rect.left > 3600:
            self.alive = False

    def draw(self, screen, camera):
        for i, (tx, ty) in enumerate(self.trail):
            ratio = (i + 1) / max(1, len(self.trail))
            pos = camera.apply(pygame.Rect(round(tx), round(ty), 1, 1)).center
            trail = tuple(round(channel * 0.72) for channel in self.color)
            pygame.draw.line(screen, trail, (pos[0] - self.direction * 7, pos[1]), (pos[0] - self.direction * 2, pos[1]), max(1, round(3 * ratio)))
        area = camera.apply(self.rect)
        x, y = area.center
        color = self.color
        pygame.draw.line(screen, (94, 63, 42), area.midleft, area.midright, 3)
        tip_x = area.right if self.direction > 0 else area.left
        back_x = area.left if self.direction > 0 else area.right
        pygame.draw.polygon(
            screen,
            color,
            [(tip_x, y), (back_x, y - 5), (back_x, y + 5)],
        )
        pygame.draw.line(screen, (179, 93, 66), (back_x, y - 4), (back_x - 5 * self.direction, y - 8), 2)
        pygame.draw.line(screen, (179, 93, 66), (back_x, y + 4), (back_x - 5 * self.direction, y + 8), 2)


class ChocolateBolt:
    """A glossy cocoa shot; heavy shots burst on impact."""

    def __init__(self, x, y, direction, heavy=False):
        self.direction = 1 if direction >= 0 else -1
        self.heavy = bool(heavy)
        size = 20 if heavy else 13
        self.rect = pygame.Rect(0, 0, size, size)
        self.rect.center = (round(x), round(y))
        self.speed = 440 if heavy else 610
        self.radius = 62 if heavy else 0
        self.alive = True
        self.trail = []
        self.time = 0.0

    def update(self, dt):
        self.time += dt
        self.rect.x += round(self.direction * self.speed * dt)
        self.trail.append(self.rect.center)
        if len(self.trail) > 7:
            self.trail.pop(0)
        if self.rect.right < 0 or self.rect.left > 3600:
            self.alive = False

    def draw(self, screen, camera):
        for i, point in enumerate(self.trail):
            p = camera.apply(pygame.Rect(point[0], point[1], 1, 1)).center
            radius = max(1, round((i + 1) * (1.6 if self.heavy else 1.0)))
            pygame.draw.circle(screen, (173, 68, 28), p, radius)
        rect = camera.apply(self.rect)
        center = rect.center
        radius = rect.width // 2
        pygame.draw.circle(screen, (255, 104, 28), center, radius + 3)
        pygame.draw.circle(screen, (112, 39, 24), center, radius)
        pygame.draw.circle(screen, (218, 88, 29), (center[0] - 2, center[1] - 2), max(2, radius - 2))
        pygame.draw.circle(screen, (255, 211, 111), (center[0] - 3, center[1] - 4), max(1, radius // 3))


class ChocolateMeteor:
    """A telegraphed falling chocolate orb for the ultimate ability."""

    def __init__(self, x, target_y):
        self.x = round(x)
        self.target_y = round(target_y)
        self.rect = pygame.Rect(0, -180, 22, 24)
        self.rect.centerx = self.x
        self.speed = 720.0
        self.alive = True
        self.impact = False
        self.time = 0.0

    def update(self, dt):
        self.time += dt
        self.rect.y += round(self.speed * dt)
        if self.rect.bottom >= self.target_y:
            self.rect.bottom = self.target_y
            self.alive = False
            self.impact = True

    def draw(self, screen, camera):
        ground = camera.apply(pygame.Rect(self.x - 44, self.target_y - 4, 88, 8))
        pulse = 1.0 + 0.12 * (1 + pygame.math.Vector2(1, 0).rotate(self.time * 260).x)
        pygame.draw.ellipse(screen, (255, 96, 34), ground.inflate(round(12 * pulse), 3), 2)
        comet = camera.apply(self.rect)
        pygame.draw.line(screen, (255, 120, 33), (comet.centerx, comet.top - 28), comet.center, 5)
        pygame.draw.circle(screen, (255, 196, 79), comet.center, 12)
        pygame.draw.circle(screen, (121, 42, 25), comet.center, 8)


class ChocolatePuddle:
    """Short-lived chocolate puddle that marks and slows enemies in its area."""

    def __init__(self, x, y, radius=58, duration=2.7):
        self.x = round(x)
        self.y = round(y)
        self.radius = radius
        self.timer = duration

    def update(self, dt):
        self.timer = max(0.0, self.timer - dt)

    def contains(self, rect):
        return abs(rect.centerx - self.x) <= self.radius and abs(rect.bottom - self.y) <= 38

    def draw(self, screen, camera):
        rect = camera.apply(pygame.Rect(self.x - self.radius, self.y - 7, self.radius * 2, 17))
        alpha = min(180, round(180 * min(1.0, self.timer * 2)))
        puddle = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pygame.draw.ellipse(puddle, (255, 94, 30, alpha), puddle.get_rect())
        pygame.draw.ellipse(puddle, (101, 34, 24, min(230, alpha + 45)), puddle.get_rect().inflate(-10, -4))
        screen.blit(puddle, rect)
