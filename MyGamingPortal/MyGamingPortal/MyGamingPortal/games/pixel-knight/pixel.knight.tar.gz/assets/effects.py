"""Pixel Knight VFX: glow slashes, hit-stop, sparks, afterimages, shake."""
import math
import random
import pygame
from levels.environments import ENVIRONMENTS

MAX_PARTICLES = 320
COMBO_PALETTES = (
    ((235, 250, 255), (145, 215, 255), (255, 255, 255)),
    ((255, 236, 140), (255, 196, 72), (255, 255, 220)),
    ((255, 120, 210), (255, 230, 255), (190, 255, 140)),
)


class Particle:
    __slots__ = (
        "x", "y", "vx", "vy", "life", "max_life", "color", "size",
        "gravity", "drag", "shape", "glow",
    )

    def __init__(self, x, y, vx, vy, life, color, size=3, gravity=520, drag=0.0, shape="pixel", glow=False):
        self.x = float(x)
        self.y = float(y)
        self.vx = float(vx)
        self.vy = float(vy)
        self.life = float(life)
        self.max_life = max(0.001, float(life))
        self.color = color
        self.size = size
        self.gravity = gravity
        self.drag = drag
        self.shape = shape
        self.glow = glow

    def update(self, dt):
        self.life -= dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += self.gravity * dt
        if self.drag:
            damp = max(0.0, 1.0 - self.drag * dt)
            self.vx *= damp
            self.vy *= damp
        return self.life > 0

    def draw(self, surface, camera):
        ratio = max(0.0, min(1.0, self.life / self.max_life))
        size = max(1, round(self.size * (0.35 + 0.65 * ratio)))
        alpha = int((220 if self.glow else 255) * ratio)
        pos = camera.apply(pygame.Rect(round(self.x), round(self.y), 1, 1))
        if self.shape == "circle" or self.glow:
            radius = size + (2 if self.glow else 0)
            img = pygame.Surface((radius * 2 + 2, radius * 2 + 2), pygame.SRCALPHA)
            pygame.draw.circle(img, (*self.color, alpha), (radius + 1, radius + 1), radius)
            if self.glow and radius > 2:
                pygame.draw.circle(img, (255, 255, 255, min(255, alpha + 40)), (radius + 1, radius + 1), max(1, radius // 3))
            surface.blit(img, (pos.centerx - radius, pos.centery - radius))
        else:
            img = pygame.Surface((size * 2 + 2, size * 2 + 2), pygame.SRCALPHA)
            pygame.draw.rect(img, (*self.color, alpha), (1, 1, size, size))
            surface.blit(img, (pos.centerx - size // 2, pos.centery - size // 2))


class Effects:
    def __init__(self):
        self.particles = []
        self.slashes = []
        self.afterimages = []
        self.shake = 0.0
        self.shake_strength = 0.0
        self.flash = 0.0
        self.flash_color = (235, 248, 255)
        self.rings = []
        self.streaks = []
        self.speed_lines = []
        self.floaters = []
        self.hitstop = 0.0
        self.ambient_timer = 0.0
        self.wind_timer = 12.0
        self.vignette = 0.0
        self.low_health = False

    def update(self, dt):
        self.hitstop = max(0.0, self.hitstop - dt)
        self.particles = [p for p in self.particles if p.update(dt)]
        if len(self.particles) > MAX_PARTICLES:
            self.particles = self.particles[-MAX_PARTICLES:]

        alive = []
        for slash in self.slashes:
            slash["life"] -= dt
            if slash["life"] > 0:
                alive.append(slash)
        self.slashes = alive

        alive = []
        for image in self.afterimages:
            image["life"] -= dt
            if image["life"] > 0:
                alive.append(image)
        self.afterimages = alive

        self.shake = max(0.0, self.shake - dt)
        self.flash = max(0.0, self.flash - dt)
        self.vignette = max(0.0, self.vignette - dt)

        self.rings = [r for r in self.rings if self._update_ring(r, dt)]
        for streak in self.streaks:
            streak["life"] -= dt
        self.streaks = [s for s in self.streaks if s["life"] > 0]
        for line in self.speed_lines:
            line["life"] -= dt
        self.speed_lines = [s for s in self.speed_lines if s["life"] > 0]
        for floater in self.floaters:
            floater["life"] -= dt
            floater["y"] -= 42 * dt
        self.floaters = [f for f in self.floaters if f["life"] > 0]

    def freeze(self, duration=0.045):
        self.hitstop = max(self.hitstop, duration)

    def camera_shake(self, strength=5, duration=0.12):
        self.shake = max(self.shake, duration)
        self.shake_strength = max(self.shake_strength, strength)

    def screen_flash(self, color=(235, 248, 255), duration=0.05):
        self.flash = max(self.flash, duration)
        self.flash_color = color

    def _spawn(self, particle):
        if len(self.particles) < MAX_PARTICLES:
            self.particles.append(particle)

    @staticmethod
    def _update_ring(ring, dt):
        ring["life"] -= dt
        ring["radius"] += ring["speed"] * dt
        return ring["life"] > 0

    def impact_ring(self, x, y, color=(190, 235, 255), heavy=False):
        self.rings.append({
            "x": x, "y": y, "radius": 6 if not heavy else 10,
            "speed": 280 if heavy else 190,
            "life": 0.28 if heavy else 0.18,
            "max_life": 0.28 if heavy else 0.18,
            "color": color,
            "heavy": heavy,
        })

    def floating_text(self, x, y, text, color=(255, 236, 140)):
        self.floaters.append({
            "x": x, "y": y, "text": text, "color": color,
            "life": 0.7, "max_life": 0.7,
        })

    def hit_spark(self, x, y, facing=1, heavy=False):
        count = 22 if heavy else 12
        palette = ((255, 255, 255), (210, 240, 255), (255, 220, 90), (255, 150, 80))
        for _ in range(count):
            angle = random.uniform(-0.9, 0.9)
            if facing < 0:
                angle = math.pi - angle
            speed = random.uniform(90, 260 if heavy else 170)
            self._spawn(Particle(
                x, y,
                math.cos(angle) * speed,
                math.sin(angle) * speed - (80 if heavy else 40),
                random.uniform(0.16, 0.4),
                random.choice(palette),
                random.choice((2, 3, 3, 4)) if heavy else random.choice((2, 3)),
                420, 0.6, "pixel",
            ))
        for _ in range(6 if heavy else 3):
            self._spawn(Particle(
                x, y, random.uniform(-40, 40), random.uniform(-120, -30),
                random.uniform(0.2, 0.35), (255, 255, 255), 5, 80, 2.2, "circle", True,
            ))
        self.impact_ring(x, y, (255, 230, 170) if heavy else (220, 245, 255), heavy)
        self.camera_shake(9 if heavy else 4.0, 0.16 if heavy else 0.08)
        if heavy:
            self.freeze(0.055)
            self.screen_flash((255, 245, 210), 0.04)

    def enemy_defeat(self, x, y):
        for _ in range(28):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(70, 260)
            self._spawn(Particle(
                x, y,
                math.cos(angle) * speed,
                math.sin(angle) * speed - 90,
                random.uniform(0.3, 0.62),
                random.choice(((239, 219, 145), (184, 86, 49), (255, 255, 255), (125, 92, 154), (140, 230, 255))),
                random.choice((2, 3, 4)),
                480, 0.3, "pixel",
            ))
        for _ in range(8):
            self._spawn(Particle(
                x, y, random.uniform(-50, 50), random.uniform(-160, -40),
                random.uniform(0.4, 0.7), (255, 236, 160), 4, 90, 1.2, "circle", True,
            ))
        self.impact_ring(x, y, (255, 210, 120), True)
        self.camera_shake(6, 0.14)
        self.freeze(0.07)
        self.floating_text(x, y - 18, "+1", (255, 226, 110))

    def dash_burst(self, x, y, facing):
        for _ in range(16):
            angle = random.uniform(math.pi * 0.65, math.pi * 1.35)
            if facing < 0:
                angle += math.pi
            speed = random.uniform(40, 160)
            self._spawn(Particle(
                x, y,
                math.cos(angle) * speed,
                math.sin(angle) * speed,
                random.uniform(0.14, 0.3),
                random.choice(((180, 225, 255), (255, 255, 255), (120, 190, 255))),
                random.choice((2, 3)), 0, 1.4, "circle", True,
            ))
        for i in range(7):
            self.speed_lines.append({
                "x": x - facing * (18 + i * 10),
                "y": y + random.randint(-18, 18),
                "facing": facing,
                "life": 0.16 + i * 0.01,
                "max_life": 0.16 + i * 0.01,
                "length": 28 + i * 6,
            })
        self.impact_ring(x, y, (170, 220, 255), False)

    def landing(self, x, y, heavy=False):
        count = 16 if heavy else 8
        for _ in range(count):
            angle = random.uniform(math.pi, math.tau)
            speed = random.uniform(30, 110 if heavy else 75)
            self._spawn(Particle(
                x, y,
                math.cos(angle) * speed,
                math.sin(angle) * speed * 0.35,
                random.uniform(0.16, 0.32),
                (215, 205, 176), 2 if not heavy else 3, 240, 0.8, "pixel",
            ))
        if heavy:
            self.impact_ring(x, y, (230, 220, 190), True)
            self.camera_shake(4, 0.08)

    def jump_puff(self, x, y):
        for _ in range(7):
            self._spawn(Particle(
                x + random.uniform(-8, 8), y,
                random.uniform(-50, 50), random.uniform(-40, -8),
                random.uniform(0.12, 0.22),
                (230, 236, 220), 2, 180, 1.0, "circle", False,
            ))

    def double_jump_burst(self, x, y):
        """A cool, crisp air-burst that clearly distinguishes jump two."""
        colors = ((125, 226, 255), (225, 252, 255), (255, 211, 119))
        for index in range(18):
            angle = math.tau * index / 18 + random.uniform(-0.12, 0.12)
            speed = random.uniform(75, 185)
            self._spawn(Particle(
                x, y, math.cos(angle) * speed, math.sin(angle) * speed,
                random.uniform(0.18, 0.34), random.choice(colors),
                random.choice((2, 3, 4)), 0, 1.4, "pixel", True,
            ))
        self.impact_ring(x, y, (125, 226, 255), True)
        self.screen_flash((182, 239, 255), 0.035)
        self.freeze(0.025)

    def shield_block(self, x, y):
        self.floating_text(x, y - 20, "BLOCK", (159, 236, 255))
        self.impact_ring(x, y, (108, 224, 255), True)
        self.impact_ring(x, y, (244, 218, 150), False)
        self.camera_shake(3, 0.07)
        self.screen_flash((150, 224, 255), 0.035)
        for _ in range(12):
            angle = random.uniform(-1.2, 1.2)
            speed = random.uniform(70, 160)
            self._spawn(Particle(
                x, y, math.cos(angle) * speed, math.sin(angle) * speed,
                random.uniform(0.12, 0.24), random.choice(((130, 220, 255), (255, 255, 230))),
                3, 0, 1.1, "pixel", True,
            ))
        self.freeze(0.035)

    def perfect_parry(self, x, y):
        self.floating_text(x, y - 26, "PERFECT PARRY", (255, 226, 139))
        self.impact_ring(x, y, (255, 219, 122), True)
        self.impact_ring(x, y, (176, 236, 255), True)
        self.camera_shake(5, 0.10)
        self.screen_flash((255, 231, 158), 0.055)
        self.freeze(0.075)
        for _ in range(22):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(100, 240)
            self._spawn(Particle(
                x, y, math.cos(angle) * speed, math.sin(angle) * speed,
                random.uniform(0.18, 0.34), random.choice(((255, 216, 112), (245, 252, 255), (114, 218, 255))),
                random.choice((2, 3, 4)), 0, 1.2, "pixel", True,
            ))

    def ward_block(self, x, y):
        self.floating_text(x, y - 20, "WARD SAVED", (255, 221, 142))
        self.impact_ring(x, y, (157, 222, 255), True)
        self.impact_ring(x, y, (255, 219, 128), False)
        self.screen_flash((180, 220, 255), 0.035)
        self.freeze(0.04)

    def level_complete(self, x, y):
        self.floating_text(x, y - 26, "SHRINE REACHED", (255, 225, 142))
        self.screen_flash((255, 232, 164), 0.20)
        self.impact_ring(x, y, (255, 216, 120), True)
        for _ in range(48):
            angle = random.uniform(-math.pi, 0)
            speed = random.uniform(80, 250)
            self._spawn(Particle(
                x + random.uniform(-18, 18), y,
                math.cos(angle) * speed, math.sin(angle) * speed - 60,
                random.uniform(0.45, 0.90), random.choice(((255, 210, 95), (255, 242, 182), (171, 227, 255))),
                random.choice((2, 3, 4)), 200, 0.45, "pixel", True,
            ))

    def sword_slash(self, x, y, facing, combo=0):
        duration = 0.20 if combo < 2 else 0.28
        palette = COMBO_PALETTES[combo % 3]
        self.slashes.append({
            "x": x, "y": y, "facing": facing,
            "life": duration, "max_life": duration,
            "combo": combo,
            "palette": palette,
        })
        for _ in range(12 + combo * 7):
            angle = random.uniform(-1.35, 1.35)
            speed = random.uniform(70, 170 + combo * 50)
            self._spawn(Particle(
                x + facing * (12 + combo * 6), y,
                math.cos(angle) * facing * speed,
                math.sin(angle) * speed - random.uniform(10, 55),
                random.uniform(0.14, 0.32),
                random.choice(palette),
                random.choice((2, 2, 3)), 80, 0.8, "pixel",
            ))
        for _ in range(4 + combo * 2):
            self._spawn(Particle(
                x + facing * 16, y + random.uniform(-16, 16),
                facing * random.uniform(20, 70), random.uniform(-20, 20),
                random.uniform(0.12, 0.22), palette[0], 4, 0, 2.0, "circle", True,
            ))
        self.impact_ring(x + facing * (20 + combo * 10), y, palette[0], combo >= 2)
        if combo >= 2:
            self.camera_shake(6, 0.12)
            self.screen_flash(palette[0], 0.04)
            self.freeze(0.03)

    def flame_burst(self, x, y):
        self.camera_shake(5, 0.12)
        self.screen_flash((255, 150, 60), 0.06)
        self.vignette = max(self.vignette, 0.35)
        for _ in range(22):
            angle = random.uniform(-math.pi, math.pi)
            speed = random.uniform(80, 220)
            self._spawn(Particle(
                x, y, math.cos(angle) * speed, math.sin(angle) * speed,
                random.uniform(0.14, 0.34),
                random.choice(((255, 96, 30), (255, 172, 50), (255, 232, 132))),
                random.choice((2, 3, 4)), 220, 0.4, "circle", True,
            ))
        self.impact_ring(x, y, (255, 126, 42), True)

    def player_hurt(self, x, y):
        self.camera_shake(8, 0.18)
        self.screen_flash((255, 70, 70), 0.07)
        self.vignette = max(self.vignette, 0.55)
        self.freeze(0.06)
        for _ in range(18):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(50, 180)
            self._spawn(Particle(
                x, y, math.cos(angle) * speed, math.sin(angle) * speed - 40,
                random.uniform(0.2, 0.4),
                random.choice(((255, 80, 90), (255, 200, 200), (255, 255, 255))),
                random.choice((2, 3)), 380, 0.5, "pixel",
            ))

    def coin_burst(self, x, y):
        self.floating_text(x, y - 10, "+1", (255, 220, 90))
        for _ in range(10):
            angle = random.uniform(-math.pi, 0)
            speed = random.uniform(40, 140)
            self._spawn(Particle(
                x, y, math.cos(angle) * speed, math.sin(angle) * speed,
                random.uniform(0.22, 0.4),
                random.choice(((255, 211, 83), (255, 255, 200), (255, 180, 40))),
                random.choice((2, 3)), 240, 0.6, "circle", True,
            ))

    def ambient(self, dt, camera_x, theme="valley"):
        self.wind_timer -= dt
        self.ambient_timer -= dt
        if self.ambient_timer > 0:
            return
        self.ambient_timer = 0.08
        config = ENVIRONMENTS.get(theme, ENVIRONMENTS["forest"])
        colors = config["particles"]
        weather = config["weather"]
        count = 2 if weather in ("embers", "bubbles", "wisp") else 1
        for _ in range(count):
            x = camera_x + random.uniform(0, 980)
            y = random.uniform(40, 400)
            if weather in ("embers", "bubbles", "wisp", "firefly"):
                vy = random.uniform(-28, -8)
            elif weather == "leaves":
                vy = random.uniform(12, 42)
            else:
                vy = random.uniform(-8, 8)
            vx = random.uniform(-12, 12)
            shape = "circle" if weather in ("bubbles", "firefly", "wisp") else "pixel"
            if weather == "leaves":
                vx += random.choice((-48, 48))
            self._spawn(Particle(
                x, y, vx, vy,
                random.uniform(0.8, 1.6), random.choice(colors),
                2 if weather in ("leaves", "shards") else 1,
                12 if weather == "leaves" else 0, 0.2, shape,
                weather in ("firefly", "embers", "wisp", "shards"),
            ))

        # A brief, low density gust gives the forest and fields a living breeze.
        # It uses background particles only and never obscures hazards or platforms.
        if self.wind_timer <= 0:
            self.wind_timer = random.uniform(17, 24)
            if weather in ("leaves", "firefly"):
                for _ in range(7):
                    self._spawn(Particle(
                        camera_x + random.uniform(0, 980), random.uniform(70, 375),
                        random.uniform(70, 125), random.uniform(8, 36),
                        random.uniform(0.45, 0.8), random.choice(colors),
                        2, 8, 0.05, "pixel", False,
                    ))

    def draw(self, surface, camera):
        for image in self.afterimages:
            alpha = max(0, int(140 * image["life"] / image["max_life"]))
            ghost = image["surface"].copy()
            ghost.set_alpha(alpha)
            tint = pygame.Surface(ghost.get_size(), pygame.SRCALPHA)
            tint.fill((140, 210, 255, 50))
            ghost.blit(tint, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
            pos = camera.apply(image["rect"])
            surface.blit(ghost, (pos.centerx - ghost.get_width() // 2, pos.bottom - ghost.get_height()))

        for slash in self.slashes:
            self._draw_slash(surface, camera, slash)

        for ring in self.rings:
            ratio = max(0.0, ring["life"] / ring["max_life"])
            center = camera.apply(pygame.Rect(round(ring["x"]), round(ring["y"]), 1, 1)).center
            radius = max(2, round(ring["radius"]))
            alpha = int(200 * ratio)
            layer = pygame.Surface((radius * 2 + 8, radius * 2 + 8), pygame.SRCALPHA)
            pygame.draw.circle(layer, (*ring["color"], alpha), (radius + 4, radius + 4), radius, max(1, 4 if ring["heavy"] else 2))
            if ring["heavy"]:
                pygame.draw.circle(layer, (255, 255, 255, alpha // 2), (radius + 4, radius + 4), max(2, radius - 6), 1)
            surface.blit(layer, (center[0] - radius - 4, center[1] - radius - 4))

        for streak in self.streaks:
            ratio = max(0.0, streak["life"] / streak["max_life"])
            pos = camera.apply(pygame.Rect(round(streak["x"]), round(streak["y"]), 1, 1))
            length = round(streak["length"] * (1.0 - ratio * 0.2))
            end = pos.centerx + streak["facing"] * length
            pygame.draw.line(surface, (210, 240, 255), pos.center, (end, pos.centery), 3)
            pygame.draw.line(surface, (255, 255, 255), pos.center, (end, pos.centery), 1)

        for line in self.speed_lines:
            ratio = max(0.0, line["life"] / line["max_life"])
            pos = camera.apply(pygame.Rect(round(line["x"]), round(line["y"]), 1, 1))
            length = round(line["length"] * ratio)
            start = (pos.centerx, pos.centery)
            end = (pos.centerx - line["facing"] * length, pos.centery)
            pygame.draw.line(surface, (180, 220, 255), start, end, 2)

        for particle in self.particles:
            particle.draw(surface, camera)

        for floater in self.floaters:
            ratio = max(0.0, floater["life"] / floater["max_life"])
            pos = camera.apply(pygame.Rect(round(floater["x"]), round(floater["y"]), 1, 1))
            font = pygame.font.Font(None, 22)
            img = font.render(floater["text"], True, floater["color"])
            img.set_alpha(int(255 * ratio))
            surface.blit(img, (pos.centerx - img.get_width() // 2, pos.centery - img.get_height() // 2))

    def _draw_slash(self, surface, camera, slash):
        progress = 1.0 - slash["life"] / slash["max_life"]
        facing = slash["facing"]
        combo = slash["combo"]
        palette = slash.get("palette", COMBO_PALETTES[0])
        size = 88 + combo * 16
        rect = camera.apply(pygame.Rect(
            round(slash["x"] - size // 2),
            round(slash["y"] - size // 2),
            size,
            size,
        ))
        sweep = 0.55 + progress * 1.15
        start = -1.25 + progress * 0.45
        end = start + sweep
        if facing < 0:
            start, end = math.pi - end, math.pi - start

        img = pygame.Surface(rect.size, pygame.SRCALPHA)
        alpha = max(0, int(255 * (slash["life"] / slash["max_life"])))
        cx, cy = img.get_width() // 2, img.get_height() // 2
        pygame.draw.circle(img, (*palette[0], alpha // 6), (cx, cy), size // 2 - 4)
        outer = img.get_rect().inflate(-4, -4)
        mid = img.get_rect().inflate(-16, -16)
        inner = img.get_rect().inflate(-28, -28)
        pygame.draw.arc(img, (*palette[1], alpha // 2), outer, start, end, 12 + combo * 2)
        pygame.draw.arc(img, (*palette[0], alpha), outer, start, end, 6)
        pygame.draw.arc(img, (255, 255, 255, alpha), mid, start, end, 3)
        pygame.draw.arc(img, (*palette[2], alpha), inner, start, end, 2)

        tip = start + (end - start) * min(1.0, progress + 0.2)
        tip_x = cx + math.cos(-tip) * (size * 0.42) * (1 if facing > 0 else 1)
        tip_y = cy + math.sin(-tip) * (size * 0.42)
        pygame.draw.circle(img, (255, 255, 255, alpha), (int(tip_x), int(tip_y)), 3 + combo)
        surface.blit(img, rect.topleft)

    def add_afterimage(self, surface, rect):
        self.afterimages.append({
            "surface": surface.copy(),
            "rect": rect.copy(),
            "life": 0.16,
            "max_life": 0.16,
        })
        if len(self.afterimages) > 18:
            self.afterimages = self.afterimages[-18:]

    def draw_screen_fx(self, screen, width, height):
        if self.flash > 0:
            overlay = pygame.Surface((width, height), pygame.SRCALPHA)
            overlay.fill((*self.flash_color, int(90 * min(1.0, self.flash / 0.05))))
            screen.blit(overlay, (0, 0))
        if self.vignette > 0:
            shade = pygame.Surface((width, height), pygame.SRCALPHA)
            shade.fill((90, 8, 12, int(110 * min(1.0, self.vignette / 0.55))))
            screen.blit(shade, (0, 0))
        if self.low_health:
            pulse = (math.sin(pygame.time.get_ticks() * 0.006) + 1.0) * 0.5
            edge = pygame.Surface((width, height), pygame.SRCALPHA)
            for inset in range(0, 28, 4):
                alpha = int((1.0 - inset / 32) * (12 + pulse * 18))
                pygame.draw.rect(
                    edge, (174, 37, 56, alpha),
                    (inset, inset, width - inset * 2, height - inset * 2), 3,
                )
            screen.blit(edge, (0, 0))
