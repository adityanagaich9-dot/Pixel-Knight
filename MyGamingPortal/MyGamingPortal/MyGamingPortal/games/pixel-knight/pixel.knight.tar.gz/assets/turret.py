"""Fixed crossbow turrets and their metal bolts."""

import math

import pygame


class TurretBolt:
    """A gravity-driven bolt launched by a mounted crossbow turret."""

    def __init__(self, x, y, player):
        self.x = float(x)
        self.y = float(y)
        self.gravity = 390.0
        self.alive = True
        self.lifetime = 3.0
        self.trail = []

        target_x = player.rect.centerx
        target_y = player.rect.centery
        flight_time = max(0.22, min(0.8, abs(target_x - self.x) / 620.0))
        lead = min(0.18, flight_time * 0.28)
        target_x += player.velocity.x * lead
        target_y += max(-30, min(30, player.velocity.y * lead * 0.35))
        dx = target_x - self.x
        dy = target_y - self.y
        flight_time = max(0.22, min(0.8, abs(dx) / 620.0))
        self.vx = dx / flight_time
        self.vy = (dy - 0.5 * self.gravity * flight_time * flight_time) / flight_time
        speed = math.hypot(self.vx, self.vy)
        if speed > 780:
            self.vx *= 780 / speed
            self.vy *= 780 / speed
        self.rect = pygame.Rect(round(self.x) - 10, round(self.y) - 4, 20, 8)

    def update(self, dt, platforms):
        if not self.alive:
            return
        self.lifetime -= dt
        old = (round(self.x), round(self.y))
        self.vy += self.gravity * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.rect.center = (round(self.x), round(self.y))
        self.trail.append(old)
        if len(self.trail) > 5:
            self.trail.pop(0)
        if self.lifetime <= 0 or self.x < -32 or self.x > 3632 or self.y > 640:
            self.alive = False
            return

        new = (round(self.x), round(self.y))
        for platform in platforms:
            if platform.colliderect(self.rect) or platform.clipline(old, new):
                self.alive = False
                return

    def draw(self, screen, camera):
        points = [camera.apply(pygame.Rect(x, y, 1, 1)).center for x, y in self.trail]
        for index in range(1, len(points)):
            shade = (index + 1) / max(1, len(points))
            pygame.draw.line(
                screen,
                (round(49 + 55 * shade), round(83 + 84 * shade), round(112 + 91 * shade)),
                points[index - 1], points[index], max(1, round(2 * shade)),
            )

        center = camera.apply(self.rect).center
        angle = math.atan2(self.vy, self.vx)
        direction = pygame.Vector2(math.cos(angle), math.sin(angle))
        normal = pygame.Vector2(-direction.y, direction.x)
        tail = pygame.Vector2(center) - direction * 9
        tip = pygame.Vector2(center) + direction * 11
        fin_a = tail - direction * 4 + normal * 4
        fin_b = tail - direction * 4 - normal * 4
        point = lambda value: (round(value.x), round(value.y))
        pygame.draw.line(screen, (22, 31, 42), point(tail), point(tip), 6)
        pygame.draw.line(screen, (173, 196, 205), point(tail), point(tip - direction * 2), 3)
        pygame.draw.polygon(screen, (74, 159, 194), (point(tip), point(fin_a), point(fin_b)))
        pygame.draw.line(screen, (237, 216, 155), point(tail - direction * 2), point(tip - direction * 5), 1)


class Turret:
    """A stationary crossbow turret with Idle and Aim animation states."""

    ART_FOOT_OFFSET = 16
    AIM_DURATION = 0.62
    IDLE_FRAME_DURATION = 0.18

    def __init__(self, center_x, base_y, idle_frames, aim_frames):
        self.base_x = int(center_x)
        self.ground_y = int(base_y)
        # Seat the supplied stone pedestal into the grass while keeping the
        # level spawn coordinate as the ground reference.
        self.base_y = self.ground_y + self.ART_FOOT_OFFSET
        self.rect = pygame.Rect(self.base_x - 28, self.base_y - 39, 56, 39)
        self.idle_frames = idle_frames
        self.aim_frames = aim_frames
        self.direction = 1
        self.health = 3
        self.max_health = 3
        self.alive = True
        self.dying = False
        self.state = "idle"
        self.state_timer = 0.0
        self.animation_timer = 0.0
        self.cooldown = 0.9
        self.shot_released = False
        self.recoil = 0.0
        self.flash_timer = 0.0
        self.hit_flash_timer = 0.0

    @property
    def image(self):
        if self.state == "aim" and self.aim_frames:
            progress = 1.0 - max(0.0, self.state_timer) / self.AIM_DURATION
            index = min(len(self.aim_frames) - 1, int(progress * len(self.aim_frames)))
            return self.aim_frames[index]
        if self.idle_frames:
            index = int(self.animation_timer / self.IDLE_FRAME_DURATION) % len(self.idle_frames)
            return self.idle_frames[index]
        return pygame.Surface((96, 96), pygame.SRCALPHA)

    def _visible_to(self, player, platforms):
        dx = player.rect.centerx - self.base_x
        muzzle_y = self.base_y - 58
        dy = player.rect.centery - muzzle_y
        if abs(dx) > 520 or abs(dy) > 310:
            return False
        start = (self.base_x + self.direction * 34, muzzle_y)
        end = player.rect.center
        for platform in platforms:
            if platform.height <= 100 and platform.clipline(start, end):
                return False
        return True

    def update_ai(self, dt, player, platforms):
        if not self.alive:
            return None
        self.animation_timer += dt
        self.hit_flash_timer = max(0.0, self.hit_flash_timer - dt)
        self.flash_timer = max(0.0, self.flash_timer - dt)
        self.recoil = max(0.0, self.recoil - 80.0 * dt)

        dx = player.rect.centerx - self.base_x
        if dx > 8:
            self.direction = 1
        elif dx < -8:
            self.direction = -1

        if self.state == "aim":
            self.state_timer -= dt
            if not self.shot_released and self.state_timer <= 0.10:
                if not self._visible_to(player, platforms):
                    self.state_timer = 0.10
                    return None
                self.shot_released = True
                self.recoil = 6.0
                self.flash_timer = 0.08
                return TurretBolt(
                    self.base_x + self.direction * 37,
                    self.base_y - 58,
                    player,
                )
            if self.state_timer <= 0:
                self.state = "idle"
                self.cooldown = 1.12
            return None

        self.cooldown = max(0.0, self.cooldown - dt)
        if self.cooldown <= 0 and self._visible_to(player, platforms):
            self.state = "aim"
            self.state_timer = self.AIM_DURATION
            self.shot_released = False
        return None

    def take_hit(self):
        if not self.alive:
            return False
        self.health -= 1
        self.hit_flash_timer = 0.14
        if self.health <= 0:
            self.alive = False
            return True
        return False

    def visual_rect(self, camera):
        image = self.image
        area = camera.apply(self.rect)
        x = area.centerx - image.get_width() // 2 - round(self.direction * self.recoil)
        y = self.base_y - round(camera.offset.y) - image.get_height()
        return image.get_rect(topleft=(x, y))

    def draw(self, screen, camera):
        image = self.image
        if self.direction < 0:
            image = pygame.transform.flip(image, True, False)
        sprite_rect = self.visual_rect(camera)
        if self.hit_flash_timer > 0:
            image = image.copy()
            tint = pygame.Surface(image.get_size(), pygame.SRCALPHA)
            tint.fill((255, 92, 72, 120))
            image.blit(tint, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
        screen.blit(image, sprite_rect.topleft)

        if self.flash_timer > 0:
            spark_x = sprite_rect.centerx + self.direction * 39
            spark_y = sprite_rect.centery - 10
            pygame.draw.rect(screen, (255, 218, 139), (spark_x - 2, spark_y - 2, 5, 5))
            pygame.draw.rect(screen, (113, 219, 246), (spark_x - 1, spark_y - 1, 3, 3))
