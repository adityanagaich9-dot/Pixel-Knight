"""Shared display, physics, and asset settings for Pixel Knight."""
from pathlib import Path

WIDTH, HEIGHT = 960, 540
FPS = 60
TITLE = "Pixel Knight — The Forgotten Forest"
ROOT = Path(__file__).resolve().parent
ASSET_ROOT = ROOT / "assets" / "brackeys_platformer_assets"
SPRITES = ASSET_ROOT / "sprites"
SOUNDS = ASSET_ROOT / "sounds"
MUSIC = ASSET_ROOT / "music"
FONT_PATH = ASSET_ROOT / "fonts" / "PixelOperator8-Bold.ttf"

TILE = 32
WORLD_WIDTH = 3600
FINAL_LEVEL = 12
GROUND_Y = 440
PLAYER_SPEED = 245.0
PLAYER_ACCEL = 2600.0
PLAYER_DECEL = 3000.0
JUMP_SPEED = 570.0
GRAVITY = 1500.0
WALL_SLIDE_SPEED = 190.0
FAST_FALL_MULTIPLIER = 1.65
JUMP_BUFFER_TIME = 0.14
COYOTE_TIME = 0.12
ATTACK_COOLDOWN = 0.34
ATTACK_DURATION = 0.24
ATTACK_HIT_START = 0.07
ATTACK_HIT_END = 0.18
ATTACK_RANGE = 52
MAX_HEALTH = 5

SKY = (112, 190, 224)
INK = (29, 35, 48)
PANEL = (25, 37, 52)
GOLD = (255, 211, 83)
WHITE = (250, 246, 222)
