# PIXEL KNIGHT

A Pygame pixel-art platform adventure with a long-form campaign, collectible gold, hero unlocks, and two standalone boss sanctums.

## Launch

1. Install Python 3.10 or newer.
2. Open this folder in a terminal.
3. Run `python -m pip install -r requirements.txt`.
4. Run `python main.py`.

## Controls

| Action | Controls |
| --- | --- |
| Move | A/D or Left/Right |
| Jump / double jump | Space, W, or Up; press again in the air |
| Fast fall | S or Down while airborne |
| Roll | Hold a direction and tap S or Down while grounded |
| Attack | J or left mouse button |
| Choco Warrior heavy shot | K |
| Chocolate Rain | U when charged; tap Shield in Touch mode |
| Dash | Left or Right Shift |
| Shield / parry | Hold E |
| Pause | Esc |

The Options menu includes a draggable Touch/PC control selector. On a phone, Touch mode adds movement and action buttons.

## Heroes and gold

The hero portrait in the main menu opens character selection. The Choco Warrior costs **50 gold** to unlock; coins and unlocks save locally between sessions. The supplied Choco Warrior sprite sheet provides idle, run, shoot, jump, hurt, and death art. The older Choco Shooter art has been removed. Chocolate attacks keep their existing gameplay effects, using the new Warrior animations.

Other playable choices are the blue Knight, Pixel Archer, Night Ranger, and Flame Reaper. The Archer shoots arrows; the Knight uses sword combos and shield parries; the Choco Warrior fires chocolate shots and can charge a Chocolate Rain special attack.

## Campaign

The route is Forgotten Forest → Sunken Catacombs → Crystal Caverns → **Frost Guardian's Sanctum** → Burning Village → Forgotten Fields → Ruined Kingdom → Ember Mountains → Drowned Kingdom → The Abyss → Throne of the Deep → **The Necromancer's Throne**.

Each boss has a separate, self-contained arena stage with a sealed entrance, themed cave walls, room-specific backdrop, boss health bar, and an exit that opens after victory. Bosses grow faster and more aggressive below half health. Entering an arena sets a retry checkpoint. Hidden candy stashes award bonus gold, and each defeated boss drops a persistent relic that can buy a Ward Charm in the traveler's shop. Boss stage titles do not display a level number. The Frost Guardian is enlarged into a towering boss with a matching larger collision body.

## Assets and credits

The Choco Warrior reference sheet was supplied by the user. Its visible background and grid are removed from the transparent animation atlas used by the game. No external Choco Warrior art was sourced. The user supplied no license or attribution note for this image; check its original rights before public redistribution.

Enemy packs and boss images were also supplied by the user. The project retains the supplied license for the Flying Demon at `assets/enemies/FLYING_DEMON_LICENSE.txt`. Some other supplied enemy archives had no license file, so verify their original terms before publishing. Brackeys platformer art credits and license are in `assets/brackeys_platformer_assets/LICENSE & CREDITS.txt`.
