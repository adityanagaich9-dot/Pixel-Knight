"""Smooth camera that clamps to the level bounds."""
import pygame


class Camera:
    def __init__(self, width, height, world_width):
        self.offset = pygame.Vector2()
        self.width, self.height, self.world_width = width, height, world_width

    def update(self, target, dt):
        desired = target.centerx - self.width * 0.42
        desired = max(0, min(desired, self.world_width - self.width))
        self.offset.x += (desired - self.offset.x) * min(1.0, dt * 6.0)

    def apply(self, rect):
        return rect.move(-round(self.offset.x), 0)
