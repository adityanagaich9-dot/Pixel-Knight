"""Small direct-IP networking layer for Pixel Knight's online duel.

Uses only the Python standard library. The host runs an authoritative arena
simulation and both peers exchange newline-delimited JSON over TCP.
"""
from __future__ import annotations

import json
import socket
import threading
import time

PORT = 47880
TICK_RATE = 30
ARENA_WIDTH = 960
FLOOR_Y = 440
PLAYER_W = 30
PLAYER_H = 48
PLATFORMS = ((0, FLOOR_Y, ARENA_WIDTH, 100), (170, 354, 170, 16),
             (620, 354, 170, 16), (390, 286, 180, 16))
VALID_HEROES = {
    "frost_knight", "shadow_knight", "inferno_knight", "glacier_knight",
    "bone_reaper", "thorn_ranger", "sun_paladin", "void_walker",
    "iron_colossus", "night_assassin", "crimson_king", "eternal_knight",
    "knight", "ranger", "mage", "archer", "choco",
}


def _player_state(player_id: int) -> dict:
    x = 110.0 if player_id == 1 else 820.0
    return {
        "id": player_id, "x": x, "y": float(FLOOR_Y - PLAYER_H),
        "vx": 0.0, "vy": 0.0, "facing": 1 if player_id == 1 else -1,
        "grounded": True, "health": 5, "score": 0, "hero": "frost_knight",
        "attack_timer": 0.0, "attack_cooldown": 0.0, "attack_hit": False,
        "invulnerable": 0.0, "respawn_timer": 0.0, "last_jump": False,
        "last_attack": False, "last_rematch": False,
    }


def _default_input() -> dict:
    return {"left": False, "right": False, "jump": False, "attack": False,
            "rematch": False, "hero": "frost_knight"}


class OnlineServer:
    """Host-side direct TCP server. Player physics and hits are server-authoritative."""
    def __init__(self, port: int = PORT):
        self.port = int(port)
        self.listener = None
        self.running = threading.Event()
        self.running.set()
        self.lock = threading.RLock()
        self.clients = {}
        self.reserved = set()
        self.send_locks = {1: threading.Lock(), 2: threading.Lock()}
        self.inputs = {1: _default_input(), 2: _default_input()}
        self.players = {1: _player_state(1), 2: _player_state(2)}
        self.winner = None
        self.rematch_ready = {1: False, 2: False}
        self.accept_thread = None
        self.tick_thread = None
        self.error = ""

    def start(self):
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("0.0.0.0", self.port))
        listener.listen(2)
        listener.settimeout(0.25)
        self.listener = listener
        self.accept_thread = threading.Thread(target=self._accept_loop, name="pk-online-accept", daemon=True)
        self.tick_thread = threading.Thread(target=self._tick_loop, name="pk-online-sim", daemon=True)
        self.accept_thread.start()
        self.tick_thread.start()
        return self

    def _accept_loop(self):
        while self.running.is_set():
            try:
                conn, _address = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            conn.settimeout(0.25)
            with self.lock:
                available = next((pid for pid in (1, 2)
                                  if pid not in self.clients and pid not in self.reserved), None)
                if available is None:
                    try:
                        conn.sendall(b'{"type":"error","message":"Room is full"}\n')
                    except OSError:
                        pass
                    conn.close()
                    continue
                pid = available
                self.reserved.add(pid)
            try:
                with self.send_locks[pid]:
                    conn.sendall((json.dumps({"type": "welcome", "player_id": pid}) + "\n").encode("utf-8"))
            except OSError:
                conn.close()
                with self.lock:
                    self.reserved.discard(pid)
                continue
            with self.lock:
                self.reserved.discard(pid)
                self.clients[pid] = conn
            threading.Thread(target=self._reader_loop, args=(pid, conn),
                             name=f"pk-online-reader-{pid}", daemon=True).start()

    def _reader_loop(self, pid, conn):
        buffer = b""
        try:
            while self.running.is_set():
                try:
                    chunk = conn.recv(4096)
                except socket.timeout:
                    continue
                if not chunk:
                    break
                buffer += chunk
                if len(buffer) > 65536:
                    break
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    try:
                        message = json.loads(line.decode("utf-8"))
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if not isinstance(message, dict) or message.get("type") != "input":
                        continue
                    clean = _default_input()
                    for key in ("left", "right", "jump", "attack", "rematch"):
                        clean[key] = bool(message.get(key, False))
                    hero = message.get("hero", "frost_knight")
                    clean["hero"] = hero if hero in VALID_HEROES else "frost_knight"
                    with self.lock:
                        if self.clients.get(pid) is conn:
                            self.inputs[pid] = clean
        except (OSError, ConnectionError):
            pass
        finally:
            with self.lock:
                if self.clients.get(pid) is conn:
                    del self.clients[pid]
                    self.inputs[pid] = _default_input()
            try:
                conn.close()
            except OSError:
                pass

    @staticmethod
    def _overlap_x(a, b):
        return a["x"] + PLAYER_W > b["x"] and a["x"] < b["x"] + PLAYER_W

    def _tick_player(self, pid, dt):
        p = self.players[pid]
        inp = self.inputs[pid]
        p["attack_cooldown"] = max(0.0, p["attack_cooldown"] - dt)
        p["attack_timer"] = max(0.0, p["attack_timer"] - dt)
        p["invulnerable"] = max(0.0, p["invulnerable"] - dt)
        if p["respawn_timer"] > 0:
            p["respawn_timer"] = max(0.0, p["respawn_timer"] - dt)
            if p["respawn_timer"] == 0:
                spawn = _player_state(pid)
                score, hero = p["score"], p["hero"]
                p.update(spawn)
                p["score"], p["hero"], p["invulnerable"] = score, hero, 0.8
            return

        if inp["hero"] in VALID_HEROES:
            p["hero"] = inp["hero"]
        axis = int(inp["right"]) - int(inp["left"])
        p["vx"] = axis * 250.0
        if axis:
            p["facing"] = axis
        p["x"] = max(16.0, min(ARENA_WIDTH - PLAYER_W - 16.0, p["x"] + p["vx"] * dt))

        if inp["jump"] and not p["last_jump"] and p["grounded"]:
            p["vy"] = -535.0
            p["grounded"] = False
        p["last_jump"] = inp["jump"]

        if inp["attack"] and not p["last_attack"] and p["attack_cooldown"] <= 0:
            p["attack_timer"] = 0.22
            p["attack_cooldown"] = 0.48
            p["attack_hit"] = False
        p["last_attack"] = inp["attack"]

        old_bottom = p["y"] + PLAYER_H
        p["vy"] = min(800.0, p["vy"] + 1450.0 * dt)
        p["y"] += p["vy"] * dt
        p["grounded"] = False
        if p["vy"] >= 0:
            for px, py, pw, ph in PLATFORMS:
                new_bottom = p["y"] + PLAYER_H
                if (old_bottom <= py + 2 and new_bottom >= py and
                        p["x"] + PLAYER_W > px and p["x"] < px + pw):
                    p["y"] = py - PLAYER_H
                    p["vy"] = 0.0
                    p["grounded"] = True
                    break
        else:
            old_top = p["y"] - p["vy"] * dt
            for px, py, pw, ph in PLATFORMS[1:]:
                if (old_top >= py + ph and p["y"] <= py + ph and
                        p["x"] + PLAYER_W > px and p["x"] < px + pw):
                    p["y"] = py + ph
                    p["vy"] = 0.0
                    break

        if p["y"] > 600:
            p["x"], p["y"], p["vy"] = (110.0 if pid == 1 else 820.0), FLOOR_Y - PLAYER_H, 0.0
            p["grounded"] = True

    def _resolve_combat(self):
        if self.winner is not None or len(self.clients) < 2:
            return
        for pid, target_id in ((1, 2), (2, 1)):
            attacker = self.players[pid]
            target = self.players[target_id]
            if (attacker["attack_timer"] < 0.075 or attacker["attack_timer"] > 0.17 or
                    attacker["attack_hit"] or target["invulnerable"] > 0 or target["respawn_timer"] > 0):
                continue
            if abs((attacker["y"] + PLAYER_H / 2) - (target["y"] + PLAYER_H / 2)) > 58:
                continue
            if attacker["facing"] > 0:
                in_range = target["x"] >= attacker["x"] + 8 and target["x"] <= attacker["x"] + 95
                knockback = 1
            else:
                in_range = target["x"] <= attacker["x"] + PLAYER_W - 8 and target["x"] >= attacker["x"] - 65
                knockback = -1
            if in_range:
                attacker["attack_hit"] = True
                target["health"] -= 1
                target["invulnerable"] = 0.65
                target["vx"] = knockback * 300.0
                target["vy"] = -170.0
                target["grounded"] = False
                if target["health"] <= 0:
                    attacker["score"] += 1
                    if attacker["score"] >= 5:
                        self.winner = pid
                    target["respawn_timer"] = 0.85

    def _tick_loop(self):
        previous = time.monotonic()
        interval = 1.0 / TICK_RATE
        next_send = previous
        while self.running.is_set():
            now = time.monotonic()
            dt = max(0.0, min(0.06, now - previous))
            previous = now
            with self.lock:
                count = len(self.clients)
                if count >= 2:
                    if self.winner is None:
                        for pid in (1, 2):
                            self._tick_player(pid, dt)
                        self._resolve_combat()
                    else:
                        # Latch each player's rematch request so the two people
                        # need not press R on the exact same network frame.
                        for pid in (1, 2):
                            if self.inputs[pid]["rematch"]:
                                self.rematch_ready[pid] = True
                        if all(self.rematch_ready.values()):
                            self.winner = None
                            self.rematch_ready = {1: False, 2: False}
                            for pid in (1, 2):
                                hero = self.players[pid]["hero"]
                                self.players[pid] = _player_state(pid)
                                self.players[pid]["hero"] = hero
                                self.inputs[pid]["rematch"] = False
                if now >= next_send:
                    snapshot = {
                        "type": "state", "connected": count, "winner": self.winner,
                        "players": {str(pid): {k: v for k, v in p.items()
                                               if k not in ("last_jump", "last_attack", "last_rematch")}
                                    for pid, p in self.players.items()},
                    }
                    payload = (json.dumps(snapshot, separators=(",", ":")) + "\n").encode("utf-8")
                    recipients = list(self.clients.items())
                    next_send = now + interval
                else:
                    recipients = []
                    payload = b""
            for pid, conn in recipients:
                try:
                    with self.send_locks[pid]:
                        conn.sendall(payload)
                except OSError:
                    try:
                        conn.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
            time.sleep(0.004)

    def stop(self):
        self.running.clear()
        try:
            if self.listener:
                self.listener.close()
        except OSError:
            pass
        with self.lock:
            sockets = list(self.clients.values())
            self.clients.clear()
        for conn in sockets:
            try:
                conn.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                conn.close()
            except OSError:
                pass


class OnlineClient:
    """Threaded client that keeps rendering independent from network latency."""
    def __init__(self):
        self.sock = None
        self.running = threading.Event()
        self.running.set()
        self.lock = threading.Lock()
        self.send_lock = threading.Lock()
        self.latest = {"type": "state", "connected": 0, "players": {}, "winner": None}
        self.player_id = None
        self.connected = False
        self.error = ""
        self.thread = None
        self._last_send = 0.0

    def connect(self, address: str, port: int = PORT, timeout: float = 3.5):
        sock = socket.create_connection((address.strip(), int(port)), timeout=timeout)
        sock.settimeout(0.25)
        self.sock = sock
        self.connected = True
        self.thread = threading.Thread(target=self._reader_loop, name="pk-online-client-reader", daemon=True)
        self.thread.start()
        return self

    def _reader_loop(self):
        buffer = b""
        try:
            while self.running.is_set() and self.sock:
                try:
                    chunk = self.sock.recv(8192)
                except socket.timeout:
                    continue
                if not chunk:
                    break
                buffer += chunk
                if len(buffer) > 131072:
                    buffer = b""
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    try:
                        message = json.loads(line.decode("utf-8"))
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if message.get("type") == "welcome":
                        self.player_id = int(message.get("player_id", 0)) or None
                    elif message.get("type") == "state":
                        with self.lock:
                            self.latest = message
                    elif message.get("type") == "error":
                        self.error = str(message.get("message", "Connection error"))
        except (OSError, ConnectionError) as exc:
            if self.running.is_set():
                self.error = str(exc)
        finally:
            self.connected = False

    def send_input(self, **values):
        if not self.connected or not self.sock:
            return
        now = time.monotonic()
        if now - self._last_send < (1.0 / 40.0):
            return
        self._last_send = now
        message = {"type": "input", **values}
        try:
            payload = (json.dumps(message, separators=(",", ":")) + "\n").encode("utf-8")
            with self.send_lock:
                self.sock.sendall(payload)
        except OSError as exc:
            self.error = str(exc)
            self.connected = False

    def snapshot(self):
        with self.lock:
            return dict(self.latest)

    def close(self):
        self.running.clear()
        self.connected = False
        try:
            if self.sock:
                self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass
