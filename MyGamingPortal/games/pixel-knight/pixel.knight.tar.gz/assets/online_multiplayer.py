"""Online multiplayer UI and rendering for Pixel Knight.

The game host runs an authoritative TCP arena server (online_net.py). Both
players connect as clients; the server owns movement, collisions, hit timing,
knockouts, score and rematches. Direct IP works on a LAN. Across the internet,
the host must forward TCP port 47880 (or use a VPN/relay). There is no hosted
public matchmaking service in this package.
"""
from __future__ import annotations

import socket
import threading
import time

import pygame

from hero_sprites import create_hero_frames
from heroes import ALL_HERO_IDS
from online_net import OnlineClient, OnlineServer, PORT, PLATFORMS, ARENA_WIDTH, FLOOR_Y, PLAYER_W, PLAYER_H
from settings import WIDTH, HEIGHT, WHITE, GOLD


class OnlineLobbyScreen:
    """Host/join lobby integrated with Game's existing screen state machine."""
    def __init__(self, game):
        self.game = game
        self.font = game.font
        self.small_font = game.small_font
        self.micro_font = game.micro_font
        self.client = None
        self.server = None
        self.role = None
        self.address = "127.0.0.1"
        self.address_focused = True
        self.address_edited = False
        self.status = "Choose HOST MATCH or enter a host IP to JOIN."
        self.detail = "LAN works directly. Internet play needs TCP port forwarding on the host."
        self.error = ""
        self._lock = threading.Lock()
        self._connection_thread = None
        self._closed = False
        self._entered_duel = False
        self.host_rect = pygame.Rect(246, 291, 214, 48)
        self.join_rect = pygame.Rect(500, 291, 214, 48)
        self.address_rect = pygame.Rect(268, 217, 424, 42)
        self.back_rect = pygame.Rect(358, 402, 244, 40)
        self.port = PORT

    @staticmethod
    def _lan_ip():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # Documentation-only TEST-NET address: no packet payload is sent.
            sock.connect(("192.0.2.1", 9))
            return sock.getsockname()[0]
        except OSError:
            try:
                return socket.gethostbyname(socket.gethostname())
            except OSError:
                return "127.0.0.1"
        finally:
            sock.close()

    def _start_host(self):
        if self.client and self.client.connected:
            return
        self._cleanup_network()
        try:
            self.server = OnlineServer(self.port).start()
        except OSError as exc:
            self.error = str(exc)
            self.status = "Could not host room"
            return
        self.game.online_server = self.server
        self.role = "host"
        self.status = "Opening host connection..."
        self.detail = f"LAN IP: {self._lan_ip()}  |  Internet: share public IP + forward TCP {self.port}"
        self._connect_async("127.0.0.1")

    def _start_join(self):
        address = self.address.strip()
        if not address:
            self.status = "Enter the host IP address first."
            return
        self._cleanup_network()
        self.role = "client"
        self.status = f"Connecting to {address}:{self.port}..."
        self.detail = "Connecting in the background; the game will stay responsive."
        self._connect_async(address)

    def _connect_async(self, address):
        self._closed = False
        client = OnlineClient()
        with self._lock:
            self.client = client
        self.game.online_client = client

        def worker():
            try:
                client.connect(address, self.port, timeout=8.0)
                if self._closed:
                    client.close()
                    return
                with self._lock:
                    self.status = "Connected; waiting for both players..."
            except (OSError, ValueError) as exc:
                if not self._closed:
                    with self._lock:
                        self.error = str(exc)
                        self.status = "Connection failed"
        self._connection_thread = threading.Thread(target=worker, daemon=True, name="PixelKnightLobbyConnect")
        self._connection_thread.start()

    def update(self, _dt):
        if self._closed or self._entered_duel or not self.client:
            return
        if self.client.error and not self.client.connected:
            self.error = self.client.error
            self.status = "Connection failed"
            return
        if not self.client.connected or self.client.player_id not in (1, 2):
            return
        snapshot = self.client.snapshot()
        try:
            connected_count = int(snapshot.get("connected", 0))
        except (TypeError, ValueError):
            connected_count = 0
        if connected_count >= 2:
            self._entered_duel = True
            self.game.online_duel = OnlineDuel(self.game, self.client)
            self.game.state = "online_duel"
            pygame.display.set_caption("Pixel Knight — Online Duel")
        elif self.role == "host":
            self.status = "Room hosted — waiting for opponent..."
        else:
            self.status = "Connected to host — waiting for the room..."

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._return_to_menu()
            elif event.key == pygame.K_TAB:
                self.address_focused = True
            elif event.key == pygame.K_BACKSPACE and self.address_focused:
                self.address_edited = True
                self.address = self.address[:-1]
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._start_join()
        elif event.type == pygame.TEXTINPUT:
            if self.address_focused:
                accepted = "".join(ch for ch in event.text if ch.isalnum() or ch in ".-:")
                if not self.address_edited:
                    self.address = ""
                    self.address_edited = True
                if len(self.address) + len(accepted) <= 100:
                    self.address += accepted
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.address_rect.collidepoint(event.pos):
                self.address_focused = True
                if not self.address_edited:
                    self.address = ""
                    self.address_edited = True
            elif self.host_rect.collidepoint(event.pos):
                self._start_host()
            elif self.join_rect.collidepoint(event.pos):
                self._start_join()
            elif self.back_rect.collidepoint(event.pos):
                self._return_to_menu()

    def _return_to_menu(self):
        self.close()
        self.game.online_lobby = None
        self.game.online_duel = None
        self.game.state = "menu"
        pygame.display.set_caption("Pixel Knight")

    def _cleanup_network(self):
        # This can also be called from a retry click after a failed connection.
        old_client = self.client
        old_server = self.server
        self.client = None
        self.server = None
        if old_client:
            old_client.close()
        if old_server:
            old_server.stop()
        self.game.online_client = None
        self.game.online_server = None

    def close(self):
        self._closed = True
        self._cleanup_network()

    def draw(self, screen):
        try:
            self.game.world.draw_background(screen, 0)
        except (AttributeError, pygame.error):
            screen.fill((11, 16, 27))
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((3, 6, 13, 218))
        screen.blit(veil, (0, 0))
        panel = pygame.Rect(184, 71, 592, 407)
        pygame.draw.rect(screen, (3, 6, 12), panel.move(5, 6))
        pygame.draw.rect(screen, (23, 31, 44), panel)
        pygame.draw.rect(screen, (120, 137, 149), panel, 2)
        pygame.draw.rect(screen, (182, 70, 79), panel.inflate(-10, -10), 1)
        self._center(screen, self.font, "ONLINE DUEL", 105, (231, 213, 171))
        self._center(screen, self.micro_font, "CHALLENGE ANOTHER KNIGHT", 140, (158, 182, 190))

        label = self.micro_font.render(f"HOST IP / HOSTNAME   •   PORT {self.port}", True, (170, 185, 190))
        screen.blit(label, (self.address_rect.left, self.address_rect.top - 18))
        pygame.draw.rect(screen, (57, 38, 48) if self.address_focused else (13, 20, 30), self.address_rect)
        pygame.draw.rect(screen, (198, 83, 89) if self.address_focused else (80, 101, 114), self.address_rect, 2)
        shown_address = self.address or "Enter host IP..."
        address_img = self.small_font.render(shown_address, True, WHITE if self.address else (115, 132, 141))
        screen.blit(address_img, (self.address_rect.left + 12, self.address_rect.centery - address_img.get_height() // 2))
        if self.address_focused and int(time.monotonic() * 2) % 2 == 0:
            caret_x = self.address_rect.left + 12 + address_img.get_width() + 2
            pygame.draw.line(screen, (229, 205, 154), (caret_x, self.address_rect.top + 9), (caret_x, self.address_rect.bottom - 9), 2)

        mouse = pygame.mouse.get_pos()
        self._button(screen, self.host_rect, "HOST MATCH", self.host_rect.collidepoint(mouse))
        self._button(screen, self.join_rect, "JOIN MATCH", self.join_rect.collidepoint(mouse))
        if self.error:
            status_color = (245, 143, 125)
            status_text = self.status.upper()
        elif self.client and self.client.connected:
            status_color = (136, 226, 165)
            status_text = self.status.upper()
        else:
            status_color = (226, 198, 141)
            status_text = self.status.upper()
        status_img = self.micro_font.render(status_text[:82], True, status_color)
        screen.blit(status_img, status_img.get_rect(center=(WIDTH // 2, 361)))
        detail = self.error if self.error else self.detail
        detail_img = self.micro_font.render(detail[:94], True, (159, 176, 185))
        screen.blit(detail_img, detail_img.get_rect(center=(WIDTH // 2, 383)))
        self._button(screen, self.back_rect, "BACK TO MAIN MENU", self.back_rect.collidepoint(mouse))
        self._center(screen, self.micro_font, "LAN: SHARE THE LAN IP   •   INTERNET: FORWARD TCP PORT 47880", 458, (145, 162, 171))
        self._center(screen, self.micro_font, "ESC BACK   •   CLICK ADDRESS TO EDIT   •   ENTER TO JOIN", 496, (145, 162, 171))

    def _center(self, screen, font, text, y, color):
        image = font.render(text, True, color)
        screen.blit(image, image.get_rect(center=(WIDTH // 2, y)))

    def _button(self, screen, rect, label, active=False):
        pygame.draw.rect(screen, (4, 7, 13), rect.move(3, 4))
        pygame.draw.rect(screen, (66, 79, 92), rect)
        pygame.draw.rect(screen, (56, 36, 46) if active else (19, 30, 43), rect.inflate(-4, -4))
        pygame.draw.rect(screen, (195, 83, 87) if active else (113, 137, 150), rect.inflate(-8, -8), 1)
        image = self.small_font.render(label, True, (240, 224, 192))
        screen.blit(image, image.get_rect(center=rect.center))


class OnlineDuel:
    """Render the authoritative two-player arena fed by OnlineServer snapshots."""
    def __init__(self, game, client):
        self.game = game
        self.client = client
        self.font = game.font
        self.small_font = game.small_font
        self.micro_font = game.micro_font
        self.assets = game.assets
        self.player_id = int(client.player_id or 1)
        self.opponent_id = 2 if self.player_id == 1 else 1
        self.hero_id = game.selected_hero if game.selected_hero in ALL_HERO_IDS else "frost_knight"
        self.frames_cache = {}
        self.anim_time = 0.0
        self.attack_mouse = False
        self.rematch_requested = False
        self._last_winner = None
        self._left = False
        self._send_timer = 0.0
        self._snapshot = {"connected": 1, "players": {}, "winner": None}
        self.status_message = ""

    def update(self, dt):
        if self._left or not self.client:
            return
        dt = min(max(float(dt), 0.0), 0.05)
        self.anim_time += dt
        keys = pygame.key.get_pressed()
        left = bool(keys[pygame.K_a] or keys[pygame.K_LEFT])
        right = bool(keys[pygame.K_d] or keys[pygame.K_RIGHT])
        jump = bool(keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP])
        attack = bool(keys[pygame.K_j] or self.attack_mouse)
        rematch = bool(keys[pygame.K_r] or self.rematch_requested)
        if rematch and self._snapshot.get("winner") is None:
            self.rematch_requested = False
        self.client.send_input(left=left, right=right, jump=jump, attack=attack,
                               rematch=rematch, hero=self.hero_id)
        self._snapshot = self.client.snapshot()
        winner = self._snapshot.get("winner")
        if winner != self._last_winner:
            self._last_winner = winner
            if winner is not None:
                self.status_message = "YOU WIN!" if int(winner) == self.player_id else "YOU WERE DEFEATED"
            elif winner is None:
                self.status_message = ""
        if not self.client.connected:
            self.status_message = "CONNECTION LOST"

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._return_to_menu()
            elif event.key == pygame.K_r:
                self.rematch_requested = True
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.attack_mouse = True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.attack_mouse = False

    def _return_to_menu(self):
        if self._left:
            return
        self._left = True
        try:
            if self.game.online_lobby:
                self.game.online_lobby.close()
        except (AttributeError, OSError):
            pass
        if self.game.online_client:
            self.game.online_client.close()
        if self.game.online_server:
            self.game.online_server.stop()
        self.game.online_client = None
        self.game.online_server = None
        self.game.online_lobby = None
        self.game.online_duel = None
        self.game.state = "menu"
        pygame.display.set_caption("Pixel Knight")

    def draw(self, screen):
        try:
            self.game.world.draw_background(screen, 0)
        except (AttributeError, pygame.error):
            screen.fill((11, 16, 27))
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((5, 8, 17, 85))
        screen.blit(veil, (0, 0))
        for idx, (x, y, w, h) in enumerate(PLATFORMS):
            self._draw_platform(screen, pygame.Rect(x, y, w, h), idx == 0)
        players = self._snapshot.get("players", {})
        local = players.get(str(self.player_id), {})
        opponent = players.get(str(self.opponent_id), {})
        if local:
            self._draw_avatar(screen, local, local=True)
        if opponent:
            self._draw_avatar(screen, opponent, local=False)
        self._draw_hud(screen, local, opponent)
        connected_count = int(self._snapshot.get("connected", 0) or 0)
        if connected_count < 2:
            self._overlay(screen, "WAITING FOR OPPONENT", "Share your host IP and TCP port 47880")
        elif self._snapshot.get("winner") is not None:
            winner = int(self._snapshot["winner"])
            title = "VICTORY!" if winner == self.player_id else "DEFEAT"
            self._overlay(screen, title, "Press R when both players are ready, or ESC to leave")
        elif not self.client.connected:
            self._overlay(screen, "CONNECTION LOST", "Press ESC to return to the main menu")
        else:
            hint = self.micro_font.render("MOVE A/D OR ARROWS   J ATTACK   SPACE JUMP   R REMATCH   ESC LEAVE", True, (196, 204, 208))
            screen.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 18)))

    def _draw_platform(self, screen, platform, ground=False):
        pygame.draw.rect(screen, (10, 16, 23), platform)
        if ground:
            tile = getattr(self.assets, "tile_ground", None)
            if tile:
                for x in range(platform.left, platform.right, 32):
                    for y in range(platform.top, min(HEIGHT, platform.bottom), 32):
                        screen.blit(tile, (x, y))
        else:
            top = getattr(self.assets, "platform_top", None)
            if top:
                x = platform.left
                while x < platform.right:
                    width = min(top.get_width(), platform.right - x)
                    source = top.subsurface((0, 0, width, min(top.get_height(), platform.height)))
                    screen.blit(source, (x, platform.top))
                    x += width
            if platform.height > 18:
                pygame.draw.rect(screen, (36, 43, 51), (platform.left, platform.top + 18, platform.width, platform.height - 18))

    def _frames_for(self, hero, pose):
        hero = hero if hero in ALL_HERO_IDS else "frost_knight"
        if hero not in self.frames_cache:
            try:
                self.frames_cache[hero] = create_hero_frames(self.assets, hero)
            except (KeyError, AttributeError, IndexError, pygame.error):
                self.frames_cache[hero] = create_hero_frames(self.assets, "frost_knight")
        frames_dict = self.frames_cache[hero]
        return frames_dict.get(pose) or frames_dict.get("idle") or []

    def _draw_avatar(self, screen, state, local):
        try:
            x = float(state.get("x", 0))
            y = float(state.get("y", FLOOR_Y - PLAYER_H))
            facing = -1 if float(state.get("facing", 1)) < 0 else 1
            hero = str(state.get("hero", "frost_knight"))
            hero = hero if hero in ALL_HERO_IDS else "frost_knight"
            vx = float(state.get("vx", 0))
            grounded = bool(state.get("grounded", True))
            attack_timer = float(state.get("attack_timer", 0))
            invulnerable = float(state.get("invulnerable", 0))
        except (TypeError, ValueError):
            return
        if invulnerable > 0 and int(pygame.time.get_ticks() / 90) % 2:
            return
        pose = "attack" if attack_timer > 0 else "jump" if not grounded else "run" if abs(vx) > 1 else "idle"
        frames = self._frames_for(hero, pose)
        if not frames:
            return
        frame_rate = 10 if pose in ("run", "attack") else 5
        frame = frames[int(self.anim_time * frame_rate + (0 if local else 1.5)) % len(frames)]
        if facing < 0:
            frame = pygame.transform.flip(frame, True, False)
        rect = pygame.Rect(round(x), round(y), PLAYER_W, PLAYER_H)
        screen.blit(frame, (rect.centerx - frame.get_width() // 2, rect.bottom - frame.get_height()))
        if attack_timer > 0:
            color = (142, 204, 250, 42) if local else (239, 91, 110, 55)
            glow = pygame.Surface((62, 62), pygame.SRCALPHA)
            pygame.draw.circle(glow, color, (31, 31), 27)
            screen.blit(glow, (rect.centerx - 31, rect.centery - 31))

    def _draw_hud(self, screen, local, opponent):
        self._hud_panel(screen, pygame.Rect(16, 16, 260, 66), active=True)
        self._hud_panel(screen, pygame.Rect(WIDTH - 276, 16, 260, 66), active=False)
        local_name = str(local.get("hero", self.hero_id)).replace("_", " ").upper()
        opponent_name = str(opponent.get("hero", "RIVAL")).replace("_", " ").upper()
        self._text(screen, self.small_font, f"YOU  {local_name[:17]}", 29, 23, (237, 218, 180))
        self._text(screen, self.small_font, f"RIVAL  {opponent_name[:16]}", WIDTH - 263, 23, (237, 218, 180))
        self._draw_health(screen, 30, 54, local.get("health", 5), 5, True)
        self._draw_health(screen, WIDTH - 263, 54, opponent.get("health", 5), 5, False)
        score_text = f"RIVAL {opponent.get('score', 0)}  :  YOU {local.get('score', 0)}"
        score = self.font.render(score_text, True, (237, 218, 180))
        shadow = self.font.render(score_text, True, (5, 8, 12))
        screen.blit(shadow, shadow.get_rect(center=(WIDTH // 2 + 2, 38 + 2)))
        screen.blit(score, score.get_rect(center=(WIDTH // 2, 38)))
        subtitle = self.micro_font.render("FIRST TO 5 KNOCKOUTS", True, (165, 179, 184))
        screen.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 61)))

    @staticmethod
    def _hud_panel(screen, rect, active=True):
        pygame.draw.rect(screen, (5, 9, 15), rect.move(3, 4))
        pygame.draw.rect(screen, (28, 39, 51), rect)
        pygame.draw.rect(screen, (170, 79, 85) if active else (116, 137, 149), rect, 1)
        pygame.draw.line(screen, (185, 79, 81), (rect.left + 6, rect.top + 3), (rect.right - 6, rect.top + 3), 2)

    @staticmethod
    def _draw_health(screen, x, y, hp, maximum, local):
        try:
            hp = max(0, min(int(maximum), int(hp)))
        except (TypeError, ValueError):
            hp = maximum
        for i in range(maximum):
            rect = pygame.Rect(x + i * 23, y, 17, 12)
            pygame.draw.rect(screen, (5, 8, 12), rect)
            if i < hp:
                color = (190, 61, 74) if local else (117, 151, 178)
            else:
                color = (56, 63, 71)
            pygame.draw.rect(screen, color, rect.inflate(-2, -2))

    @staticmethod
    def _text(screen, font, text, x, y, color):
        screen.blit(font.render(text, True, color), (x, y))

    def _overlay(self, screen, title, hint):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((3, 6, 12, 190))
        screen.blit(veil, (0, 0))
        panel = pygame.Rect(175, 190, 610, 150)
        pygame.draw.rect(screen, (9, 14, 22), panel)
        pygame.draw.rect(screen, (172, 67, 77), panel, 2)
        title_image = self.font.render(title, True, (239, 214, 178))
        screen.blit(title_image, title_image.get_rect(center=(WIDTH // 2, 230)))
        hint_image = self.small_font.render(hint, True, (177, 193, 199))
        screen.blit(hint_image, hint_image.get_rect(center=(WIDTH // 2, 279)))
