"""Dark-fantasy 12-Hero Character Selection Screen for Pixel Knight.

Displays all 12 heroes in an organized responsive grid with large preview,
stats bars, ability information, unlock statuses, mouse & keyboard controls.
"""

import math
import pygame
from settings import WIDTH, HEIGHT, GOLD, WHITE
from heroes import SPRITE_BACKED_HERO_IDS, get_hero, is_hero_unlocked


class HeroSelectScreen:
    def __init__(self, font, title_font, small_font, micro_font, assets):
        self.font = font
        self.title_font = title_font
        self.small_font = small_font
        self.micro_font = micro_font
        self.assets = assets

        # Only offer heroes backed by their own full animation atlas. The
        # unfinished variants remain in the codebase for future sprite work.
        self.tab = "available"
        self.selected_hero_id = "knight"
        self.hovered_hero_id = None
        self.message = ""
        self.message_timer = 0.0

        # UI Layout:
        # Left side: three real sprite-backed hero cards. Right side: animated
        # detail showcase with stats, ability and action buttons.
        self.grid_rect = pygame.Rect(32, 85, 540, 395)
        self.detail_rect = pygame.Rect(595, 85, 335, 395)

        # Buttons
        self.select_button = pygame.Rect(615, 425, 140, 42)
        self.back_button = pygame.Rect(775, 425, 135, 42)
        self.tab_12_button = pygame.Rect(34, 48, 175, 30)
        self.tab_legacy_button = pygame.Rect(218, 48, 175, 30)

        self.anim_time = 0.0

    def get_current_roster(self):
        return SPRITE_BACKED_HERO_IDS

    def get_card_rect(self, index):
        cols = 3
        card_w = (self.grid_rect.width - (cols - 1) * 10) // cols
        card_h = 184
        total_h = card_h
        top = self.grid_rect.top + max(0, (self.grid_rect.height - total_h) // 2)
        col = index % cols
        row = index // cols
        x = self.grid_rect.left + col * (card_w + 10)
        y = top + row * (card_h + 10)
        return pygame.Rect(x, y, card_w, card_h)

    def handle_click(self, pos, game):
        # Back button
        if self.back_button.collidepoint(pos):
            game.assets.play("tap")
            return "back"

        # Select / Play button
        if self.select_button.collidepoint(pos):
            return self.confirm_selection(game)

        # Hero Card clicks
        roster = self.get_current_roster()
        for i, h_id in enumerate(roster):
            rect = self.get_card_rect(i)
            if rect.collidepoint(pos):
                self.selected_hero_id = h_id
                game.assets.play("tap")
                return None

        return None

    def handle_key(self, key, game):
        roster = self.get_current_roster()
        cols = 4 if self.tab == "the12" else 3
        try:
            curr_idx = roster.index(self.selected_hero_id)
        except ValueError:
            curr_idx = 0

        if key in (pygame.K_RIGHT, pygame.K_d):
            new_idx = (curr_idx + 1) % len(roster)
            self.selected_hero_id = roster[new_idx]
            game.assets.play("tap")
        elif key in (pygame.K_LEFT, pygame.K_a):
            new_idx = (curr_idx - 1) % len(roster)
            self.selected_hero_id = roster[new_idx]
            game.assets.play("tap")
        elif key in (pygame.K_DOWN, pygame.K_s):
            new_idx = (curr_idx + cols) % len(roster)
            self.selected_hero_id = roster[new_idx]
            game.assets.play("tap")
        elif key in (pygame.K_UP, pygame.K_w):
            new_idx = (curr_idx - cols) % len(roster)
            self.selected_hero_id = roster[new_idx]
            game.assets.play("tap")
        elif key in (pygame.K_RETURN, pygame.K_SPACE):
            return self.confirm_selection(game)
        elif key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            return "back"

        return None

    def confirm_selection(self, game):
        h_id = self.selected_hero_id
        unlocked = is_hero_unlocked(h_id, game.unlocked_heroes, game.level_number, game.progress_coins, game.boss_shards)
        hero = get_hero(h_id)

        if not unlocked:
            # Check if unlockable via coins right now
            if hero.unlock_type == "coins" and game.progress_coins >= hero.unlock_coins:
                game.progress_coins -= hero.unlock_coins
                game.unlocked_heroes.add(h_id)
                game._save_progress()
                self.message = f"{hero.name} UNLOCKED!"
                self.message_timer = 2.5
                game.assets.play("coin")
                return None
            else:
                self.message = f"LOCKED: {hero.unlock_desc}"
                self.message_timer = 2.5
                game.assets.play("hurt")
                return None

        # Confirmed
        game._choose_hero(h_id)
        return "play"

    def update(self, dt):
        self.anim_time += dt
        self.message_timer = max(0.0, self.message_timer - dt)

    def draw(self, screen, game):
        # Dark fantasy semi-transparent backdrop
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((8, 12, 20, 235))
        screen.blit(veil, (0, 0))

        # Title
        title = self.title_font.render("SELECT YOUR HERO", True, GOLD)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 10))

        # Gold & Boss Relic status
        funds_text = f"GOLD: {game.progress_coins}   |   BOSS RELICS: {game.boss_shards}"
        funds_text = self._fit_text(funds_text, self.micro_font, WIDTH // 2 - 36)
        funds = self.micro_font.render(funds_text, True, (255, 230, 140))
        # Keep the counter on its own row, below the heading and above the grid.
        screen.blit(funds, (WIDTH - funds.get_width() - 30, 68))

        # Only fully sprite-backed characters are selectable right now.
        roster_caption = self.small_font.render("AVAILABLE HEROES  /  UNIQUE SPRITES", True, (205, 184, 151))
        screen.blit(roster_caption, (self.grid_rect.left, 61))

        # Left: Grid
        roster = self.get_current_roster()
        mouse = pygame.mouse.get_pos()
        self.hovered_hero_id = None

        for i, h_id in enumerate(roster):
            rect = self.get_card_rect(i)
            hero = get_hero(h_id)
            unlocked = is_hero_unlocked(h_id, game.unlocked_heroes, game.level_number, game.progress_coins, game.boss_shards)
            selected = (h_id == self.selected_hero_id)
            hovered = rect.collidepoint(mouse)
            if hovered:
                self.hovered_hero_id = h_id

            self._draw_hero_card(screen, rect, hero, unlocked, selected, hovered)

        # Right: Showcase panel
        self._draw_showcase(screen, game)

        # Message Banner
        if self.message_timer > 0:
            msg_surf = self.small_font.render(self.message, True, (255, 215, 100))
            bg_rect = msg_surf.get_rect(center=(WIDTH // 2, HEIGHT - 22)).inflate(24, 8)
            pygame.draw.rect(screen, (20, 16, 26), bg_rect)
            pygame.draw.rect(screen, GOLD, bg_rect, 1)
            screen.blit(msg_surf, msg_surf.get_rect(center=(WIDTH // 2, HEIGHT - 22)))
        else:
            hint = self.micro_font.render("ARROWS: NAVIGATE   |   ENTER: CONFIRM   |   ESC: BACK", True, (160, 175, 185))
            screen.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 22)))

    def _draw_tab(self, screen, rect, text, active=False):
        fill = (54, 35, 47) if active else (18, 27, 40)
        border = (190, 78, 82) if active else (81, 107, 121)
        pygame.draw.rect(screen, fill, rect)
        pygame.draw.rect(screen, border, rect, 2 if active else 1)
        lbl = self.micro_font.render(text, True, GOLD if active else (180, 190, 200))
        screen.blit(lbl, lbl.get_rect(center=rect.center))

    def _draw_hero_card(self, screen, rect, hero, unlocked, selected, hovered):
        # Card Background
        bg_col = (43, 32, 43) if selected else (17, 25, 37)
        border_col = hero.color if selected else ((145, 170, 181) if hovered else (58, 79, 94))
        pygame.draw.rect(screen, bg_col, rect)
        pygame.draw.rect(screen, border_col, rect, 2 if (selected or hovered) else 1)
        if selected:
            pygame.draw.rect(screen, (186, 72, 80), (rect.left + 4, rect.top + 4, 3, rect.height - 8))

        if selected:
            # Subtle glow effect
            glow = pygame.Surface(rect.size, pygame.SRCALPHA)
            glow.fill((*hero.color, 35))
            screen.blit(glow, rect.topleft)

        # Portrait thumbnail
        cx, cy = rect.centerx, rect.top + 34
        if hero.base_hero == "archer":
            thumb = self.assets.archer_idle_frames[0]
        elif hero.base_hero == "choco":
            thumb = self.assets.choco_idle_frames[0]
        else:
            thumb = self.assets.idle_frames[0]

        from hero_sprites import tint_surface
        thumb = tint_surface(thumb, hero.sprite_tint)
        thumb_scaled = pygame.transform.scale(thumb, (42, 42))
        screen.blit(thumb_scaled, thumb_scaled.get_rect(center=(cx, cy)))

        # Name
        name_col = hero.color if unlocked else (120, 130, 140)
        name_surf = self.micro_font.render(hero.name.split()[0], True, name_col)
        screen.blit(name_surf, name_surf.get_rect(center=(cx, rect.top + 64)))

        # Lock / Role badge
        if not unlocked:
            lock_lbl = self.micro_font.render("[LOCKED]", True, (240, 130, 110))
            screen.blit(lock_lbl, lock_lbl.get_rect(center=(cx, rect.bottom - 12)))
        else:
            role_word = hero.role.split()[-1]
            role_lbl = self.micro_font.render(role_word, True, (170, 185, 195))
            screen.blit(role_lbl, role_lbl.get_rect(center=(cx, rect.bottom - 12)))

    def _draw_showcase(self, screen, game):
        panel = self.detail_rect
        pygame.draw.rect(screen, (4, 8, 16), panel.move(3, 4))
        pygame.draw.rect(screen, (18, 27, 40), panel)
        pygame.draw.rect(screen, (117, 140, 151), panel, 2)
        pygame.draw.rect(screen, (187, 76, 82), (panel.left + 5, panel.top + 8, 3, panel.height - 16))

        hero = get_hero(self.selected_hero_id)
        unlocked = is_hero_unlocked(hero.hero_id, game.unlocked_heroes, game.level_number, game.progress_coins, game.boss_shards)

        # Hero Name & Role
        name_surf = self.font.render(hero.name, True, hero.color)
        screen.blit(name_surf, (panel.left + 16, panel.top + 16))
        role_surf = self.micro_font.render(hero.role, True, (215, 225, 235))
        screen.blit(role_surf, (panel.left + 16, panel.top + 40))

        # Large animated preview
        preview_box = pygame.Rect(panel.left + 16, panel.top + 60, 120, 130)
        pygame.draw.rect(screen, (12, 20, 32), preview_box)
        pygame.draw.rect(screen, (86, 113, 128), preview_box, 1)

        from hero_sprites import create_hero_frames
        frames = create_hero_frames(self.assets, hero.hero_id)["idle"]
        frame_idx = int(self.anim_time * 5) % len(frames)
        preview_sprite = pygame.transform.scale(frames[frame_idx], (96, 96))
        screen.blit(preview_sprite, preview_sprite.get_rect(center=preview_box.center))

        # Stats Column
        stats_x = panel.left + 150
        stats_y = panel.top + 64
        self._draw_stat_bar(screen, stats_x, stats_y, "HEALTH", hero.max_health, 7, (240, 80, 90))
        self._draw_stat_bar(screen, stats_x, stats_y + 24, "SPEED", int(hero.speed_mult * 10), 14, (110, 210, 245))
        self._draw_stat_bar(screen, stats_x, stats_y + 48, "RANGE", int(hero.attack_range_mult * 10), 15, (140, 240, 120))
        self._draw_stat_bar(screen, stats_x, stats_y + 72, "ARMOR", int(hero.defense_mult * 10), 15, (230, 210, 110))

        # Special Ability Box
        ab_box = pygame.Rect(panel.left + 16, panel.top + 205, panel.width - 32, 105)
        pygame.draw.rect(screen, (15, 24, 36), ab_box)
        pygame.draw.rect(screen, (88, 113, 126), ab_box, 1)
        pygame.draw.line(screen, (158, 57, 69), (ab_box.left + 6, ab_box.top + 4),
                         (ab_box.right - 6, ab_box.top + 4), 1)

        # Skill and cooldown get separate rows so long ability names cannot
        # collide with the timer at narrow desktop/browser sizes.
        skill_max = ab_box.width - 20
        skill_text = self._fit_text(f"SKILL: {hero.ability_name}", self.small_font, skill_max)
        ab_title = self.small_font.render(skill_text, True, GOLD)
        screen.blit(ab_title, (ab_box.left + 10, ab_box.top + 8))
        cd_text = self.micro_font.render(f"Cooldown: {hero.ability_cooldown:.1f}s", True, (160, 220, 240))
        screen.blit(cd_text, (ab_box.right - cd_text.get_width() - 10, ab_box.top + 26))

        # Ability Description (auto-wrapped)
        words = hero.ability_desc.split()
        lines = []
        cur_line = ""
        for w in words:
            if len(cur_line + " " + w) > 34:
                lines.append(cur_line)
                cur_line = w
            else:
                cur_line = (cur_line + " " + w).strip()
        if cur_line:
            lines.append(cur_line)

        for l_idx, line in enumerate(lines):
            line = self._fit_text(line, self.micro_font, ab_box.width - 20)
            line_surf = self.micro_font.render(line, True, (200, 210, 220))
            screen.blit(line_surf, (ab_box.left + 10, ab_box.top + 43 + l_idx * 14))

        # Status / Requirement line
        req_y = panel.top + 322
        if unlocked:
            req_surf = self.micro_font.render("STATUS: UNLOCKED & READY", True, (120, 240, 140))
        else:
            req_surf = self.micro_font.render(f"REQUIREMENT: {hero.unlock_desc}", True, (255, 140, 110))
        screen.blit(req_surf, (panel.left + 16, req_y))

        # Buttons: Select / Unlock
        mouse = pygame.mouse.get_pos()
        sel_btn = self.select_button
        back_btn = self.back_button

        can_coin_unlock = (not unlocked and hero.unlock_type == "coins" and game.progress_coins >= hero.unlock_coins)
        btn_label = "SELECT [ENTER]" if unlocked else (f"UNLOCK ({hero.unlock_coins}G)" if can_coin_unlock else "LOCKED")
        btn_col = (68, 43, 51) if unlocked else ((104, 72, 39) if can_coin_unlock else (43, 52, 63))

        pygame.draw.rect(screen, btn_col, sel_btn)
        pygame.draw.rect(screen, (190, 78, 82) if sel_btn.collidepoint(mouse) else (116, 139, 150), sel_btn, 2)
        lbl_s = self.micro_font.render(btn_label, True, WHITE)
        screen.blit(lbl_s, lbl_s.get_rect(center=sel_btn.center))

        # Back Button
        pygame.draw.rect(screen, (20, 30, 43), back_btn)
        pygame.draw.rect(screen, (190, 78, 82) if back_btn.collidepoint(mouse) else (100, 123, 138), back_btn, 2)
        lbl_b = self.micro_font.render("BACK [ESC]", True, WHITE)
        screen.blit(lbl_b, lbl_b.get_rect(center=back_btn.center))

    @staticmethod
    def _fit_text(text, font, max_width):
        if font.size(text)[0] <= max_width:
            return text
        shortened = text
        while shortened and font.size(shortened + "…")[0] > max_width:
            shortened = shortened[:-1]
        return shortened.rstrip() + "…" if shortened else "…"

    def _draw_stat_bar(self, screen, x, y, label, val, max_val, color):
        lbl = self.micro_font.render(label, True, (170, 180, 190))
        screen.blit(lbl, (x, y))
        bar_rect = pygame.Rect(x + 60, y + 2, 100, 8)
        pygame.draw.rect(screen, (25, 30, 40), bar_rect)
        pygame.draw.rect(screen, (80, 85, 95), bar_rect, 1)
        fill_w = max(0, min(bar_rect.width, int(bar_rect.width * (val / max_val))))
        if fill_w > 0:
            pygame.draw.rect(screen, color, (bar_rect.x, bar_rect.y, fill_w, bar_rect.height))
