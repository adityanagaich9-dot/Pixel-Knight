"""Registry and factory for all heroes in Pixel Knight."""

from .frost_knight import FrostKnight
from .shadow_knight import ShadowKnight
from .inferno_knight import InfernoKnight
from .glacier_knight import GlacierKnight
from .bone_reaper import BoneReaper
from .thorn_ranger import ThornRanger
from .sun_paladin import SunPaladin
from .void_walker import VoidWalker
from .iron_colossus import IronColossus
from .night_assassin import NightAssassin
from .crimson_king import CrimsonKing
from .eternal_knight import EternalKnight

from .legacy_heroes import (
    ClassicKnight,
    NightRanger,
    FlameReaper,
    PixelArcher,
    ChocoWarrior
)

# Registry of hero instances
HERO_INSTANCES = {
    "frost_knight": FrostKnight(),
    "shadow_knight": ShadowKnight(),
    "inferno_knight": InfernoKnight(),
    "glacier_knight": GlacierKnight(),
    "bone_reaper": BoneReaper(),
    "thorn_ranger": ThornRanger(),
    "sun_paladin": SunPaladin(),
    "void_walker": VoidWalker(),
    "iron_colossus": IronColossus(),
    "night_assassin": NightAssassin(),
    "crimson_king": CrimsonKing(),
    "eternal_knight": EternalKnight(),
    # Legacy heroes
    "knight": ClassicKnight(),
    "ranger": NightRanger(),
    "mage": FlameReaper(),
    "archer": PixelArcher(),
    "choco": ChocoWarrior(),
}

# The 12 Main Heroes for the primary grid
THE_12_HERO_IDS = [
    "frost_knight",
    "shadow_knight",
    "inferno_knight",
    "glacier_knight",
    "bone_reaper",
    "thorn_ranger",
    "sun_paladin",
    "void_walker",
    "iron_colossus",
    "night_assassin",
    "crimson_king",
    "eternal_knight",
]

LEGACY_HERO_IDS = ["knight", "ranger", "mage", "archer", "choco"]
ALL_HERO_IDS = THE_12_HERO_IDS + LEGACY_HERO_IDS


def get_hero(hero_id):
    """Retrieves hero object, defaulting to frost_knight if missing."""
    return HERO_INSTANCES.get(hero_id, HERO_INSTANCES["frost_knight"])


def is_hero_unlocked(hero_id, unlocked_set, highest_level=1, coins=0, boss_shards=0):
    if hero_id in unlocked_set:
        return True
    hero = get_hero(hero_id)
    if hero.unlock_type == "free":
        return True
    elif hero.unlock_type == "level":
        return highest_level >= getattr(hero, "unlock_level", 1)
    elif hero.unlock_type == "coins":
        return coins >= getattr(hero, "unlock_coins", 0)
    elif hero.unlock_type == "boss":
        return boss_shards >= getattr(hero, "unlock_shards", 1)
    return False

# Heroes with verified, dedicated animation atlases. New hero classes can
# be added to the selectable roster after original sprite sheets are ready.
SPRITE_BACKED_HERO_IDS = ["knight", "archer", "choco"]
