"""Game mode browser for Pixel Knight.

Each mode reuses the original campaign, heroes, enemies, and combat systems while
applying a small set of gameplay modifiers. Keeping it in one module makes the
mode list easy to tune without touching the campaign content.
"""

import pygame
from settings import WIDTH, HEIGHT, GOLD, WHITE

MODE_DEFINITIONS = [
    {
        "id": "story", "name": "STORY CAMPAIGN", "tag": "12 CHAPTERS",
        "desc": "The full adventure, upgrades, secrets and two bosses.",
        "accent": (214, 177, 105),
        "rules": {},
    },
    {
        "id": "speedrun", "name": "SPEEDRUN", "tag": "8 MINUTES",
        "desc": "Race through the story before the clock reaches zero.",
        "accent": (255, 125, 86),
        "rules": {"timer": 480, "speed_multiplier": 1.10, "enemy_speed": 1.12},
    },
    {
        "id": "survival", "name": "ENDLESS SURVIVAL", "tag": "NEVER ENDS",
        "desc": "The campaign loops forever. Every cleared cycle gets harder.",
        "accent": (223, 83, 103),
        "rules": {"endless": True},
    },
    {
        "id": "boss_rush", "name": "BOSS RUSH", "tag": "BOSS VS BOSS",
        "desc": "Fight the Frost Guardian and Necromancer back-to-back.",
        "accent": (198, 122, 241),
        "rules": {"start_level": 11, "enemy_hp": 0.90},
    },
    {
        "id": "nightmare", "name": "NIGHTMARE", "tag": "HARD MODE",
        "desc": "Enemies are tougher and faster. Begin with only 3 hearts.",
        "accent": (242, 83, 93),
        "rules": {"enemy_hp": 1.70, "enemy_speed": 1.20, "start_health": 3},
    },
    {
        "id": "one_hit", "name": "ONE-HIT SOUL", "tag": "NO MISTAKES",
        "desc": "One hit ends your run. Parry, dodge and master every jump.",
        "accent": (255, 216, 119),
        "rules": {"start_health": 1},
    },
    {
        "id": "gold_rush", "name": "GOLD RUSH", "tag": "TRIPLE GOLD",
        "desc": "You have 5 minutes. Every coin is worth three times more.",
        "accent": (255, 204, 75),
        "rules": {"timer": 300, "coin_multiplier": 3, "speed_multiplier": 1.08},
    },
    {
        "id": "low_gravity", "name": "MOON JUMP", "tag": "LOW GRAVITY",
        "desc": "Float higher and stay airborne longer with boosted jumps.",
        "accent": (92, 215, 245),
        "rules": {"gravity_multiplier": 0.58, "jump_multiplier": 1.12},
    },
    {
        "id": "turbo", "name": "TURBO KNIGHT", "tag": "HIGH SPEED",
        "desc": "Run faster and get your ability and dash ready more quickly.",
        "accent": (89, 240, 173),
        "rules": {"speed_multiplier": 1.48, "cooldown_rate": 1.35},
    },
    {
        "id": "swarm", "name": "SWARM BREAKER", "tag": "FAST ENEMIES",
        "desc": "Enemies move much faster, but have less health. Keep moving!",
        "accent": (255, 154, 78),
        "rules": {"enemy_hp": 0.65, "enemy_speed": 1.60},
    },
    {
        "id": "mirror", "name": "MIRROR TRIALS", "tag": "REVERSED INPUT",
        "desc": "Left becomes right. Relearn movement and fight by instinct.",
        "accent": (109, 171, 255),
        "rules": {"control_inverted": True},
    },
    {
        "id": "explorer", "name": "PEACEFUL EXPLORER", "tag": "NO DAMAGE",
        "desc": "Explore every level without enemy contact or hazard damage.",
        "accent": (135, 224, 157),
        "rules": {"explore": True, "enemy_hp": 0.80},
    },
    {
        "id": "glass_cannon", "name": "GLASS CANNON", "tag": "ONE HEART",
        "desc": "One heart, but weaker foes and faster attacks. Never get hit.",
        "accent": (255, 139, 190),
        "rules": {"start_health": 1, "enemy_hp": 0.70, "speed_multiplier": 1.15, "cooldown_rate": 1.12},
    },
    {
        "id": "giant_slayer", "name": "GIANT SLAYER", "tag": "TOUGH FOES",
        "desc": "Harder enemies guard double coin rewards and rare upgrades.",
        "accent": (238, 119, 82),
        "rules": {"enemy_hp": 1.75, "enemy_speed": 1.12, "coin_multiplier": 2},
    },
    {
        "id": "high_jump", "name": "SKYBOUND", "tag": "MEGA JUMPS",
        "desc": "Lower gravity and huge jumps open alternate routes.",
        "accent": (111, 207, 255),
        "rules": {"gravity_multiplier": 0.78, "jump_multiplier": 1.38},
    },
    {
        "id": "chaos", "name": "CHAOS RELIC", "tag": "MIXED RULES",
        "desc": "Reversed controls, swift foes and a six-minute time limit.",
        "accent": (199, 125, 255),
        "rules": {"timer": 360, "speed_multiplier": 1.18, "gravity_multiplier": 0.90,
                  "jump_multiplier": 1.10, "enemy_hp": 1.20, "enemy_speed": 1.28,
                  "control_inverted": True},
    },
    {
        "id": "relic_hunter", "name": "RELIC HUNTER", "tag": "DOUBLE GOLD",
        "desc": "Gather twice the gold while enemies hit harder and move faster.",
        "accent": (248, 195, 104),
        "rules": {"coin_multiplier": 2, "enemy_hp": 1.15, "enemy_speed": 1.08},
    },
    {
        "id": "heavy_gravity", "name": "HEAVY GRAVITY", "tag": "PRECISION JUMPS",
        "desc": "Shorter jumps and heavier falls make every landing count.",
        "accent": (156, 188, 214),
        "rules": {"gravity_multiplier": 1.38, "jump_multiplier": 0.92, "enemy_speed": 1.12},
    },
]

MODE_CONFIG = {item["id"]: {**item["rules"], "id": item["id"], "name": item["name"]}
               for item in MODE_DEFINITIONS}


class ModeSelectScreen:
    """Keyboard-, mouse-, and touch-friendly mode selection screen."""

    def __init__(self, font, title_font, small_font, micro_font, assets=None):
        self.font = font
        self.title_font = title_font
        self.small_font = small_font
        self.micro_font = micro_font
        self.assets = assets
        self.focus_index = 0
        # Six compact rows fit all 18 modes without scrolling at 960x540.
        # Titles, tags and descriptions use separate lanes inside each card.
        self.card_w = 292
        self.card_h = 58
        self.gap_x = 12
        self.gap_y = 6
        self.start_x = (WIDTH - (self.card_w * 3 + self.gap_x * 2)) // 2
        self.start_y = 73
        self.back_rect = pygame.Rect(WIDTH // 2 - 106, 466, 212, 32)
        self.time = 0.0
        self._veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._veil.fill((4, 8, 18, 220))

    def card_rect(self, index):
        col, row = index % 3, index // 3
        row_count = (len(MODE_DEFINITIONS) + 2) // 3
        remainder = len(MODE_DEFINITIONS) % 3
        if remainder and row == row_count - 1:
            # Center the final row when it contains only one or two cards.
            col += (3 - remainder) // 2
        return pygame.Rect(self.start_x + col * (self.card_w + self.gap_x),
                           self.start_y + row * (self.card_h + self.gap_y),
                           self.card_w, self.card_h)

    def update(self, dt):
        self.time += max(0.0, min(float(dt), 0.05))

    def handle_click(self, position):
        if self.back_rect.collidepoint(position):
            self._tap()
            return "back"
        for index in range(len(MODE_DEFINITIONS)):
            if self.card_rect(index).collidepoint(position):
                self.focus_index = index
                self._tap()
                return MODE_DEFINITIONS[index]["id"]
        return None

    def handle_key(self, key):
        if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            return "back"
        if key in (pygame.K_LEFT, pygame.K_a):
            self.focus_index = (self.focus_index - 1) % len(MODE_DEFINITIONS)
        elif key in (pygame.K_RIGHT, pygame.K_d):
            self.focus_index = (self.focus_index + 1) % len(MODE_DEFINITIONS)
        elif key in (pygame.K_UP, pygame.K_w):
            self.focus_index = (self.focus_index - 3) % len(MODE_DEFINITIONS)
        elif key in (pygame.K_DOWN, pygame.K_s):
            self.focus_index = (self.focus_index + 3) % len(MODE_DEFINITIONS)
        elif key in (pygame.K_RETURN, pygame.K_SPACE):
            self._tap()
            return MODE_DEFINITIONS[self.focus_index]["id"]
        return None

    def _tap(self):
        if self.assets:
            try:
                self.assets.play("tap")
            except (AttributeError, pygame.error):
                pass

    def draw(self, screen, world=None):
        if world is not None:
            world.draw_background(screen, 0)
        else:
            screen.fill((9, 14, 28))
        screen.blit(self._veil, (0, 0))

        title = self.title_font.render("CHOOSE YOUR MODE", True, (239, 219, 176))
        shadow = self.title_font.render("CHOOSE YOUR MODE", True, (4, 7, 14))
        # Fit the heading rather than allowing it to push the subtitle off-screen.
        if title.get_width() > WIDTH - 32:
            title = pygame.transform.smoothscale(title, (WIDTH - 32, title.get_height()))
            shadow = pygame.transform.smoothscale(shadow, (WIDTH - 32, shadow.get_height()))
        screen.blit(shadow, shadow.get_rect(center=(WIDTH // 2 + 2, 24 + 2)))
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 24)))
        subtitle_text = f"{len(MODE_DEFINITIONS)} MODES  •  PICK YOUR CHALLENGE"
        subtitle = self.small_font.render(subtitle_text, True, (151, 181, 193))
        screen.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 55)))

        mouse = pygame.mouse.get_pos()
        for index, mode in enumerate(MODE_DEFINITIONS):
            rect = self.card_rect(index)
            selected = index == self.focus_index
            hovered = rect.collidepoint(mouse)
            accent = mode["accent"]
            base = (26, 35, 54) if not (selected or hovered) else (34, 47, 70)
            pygame.draw.rect(screen, (5, 8, 15), rect.move(3, 3), border_radius=5)
            pygame.draw.rect(screen, base, rect, border_radius=5)
            pygame.draw.rect(screen, accent if selected or hovered else (61, 77, 96), rect, 2 if selected or hovered else 1, border_radius=5)
            pygame.draw.rect(screen, accent, (rect.left + 8, rect.top + 10, 4, rect.height - 20))
            tag = self.micro_font.render(mode["tag"], True, accent)
            title_max = max(64, rect.width - tag.get_width() - 44)
            name_text = self._fit(mode["name"], self.small_font, title_max)
            name = self.small_font.render(name_text, True, (247, 232, 198) if selected or hovered else (222, 226, 229))
            screen.blit(name, (rect.left + 20, rect.top + 5))
            screen.blit(tag, (rect.right - tag.get_width() - 10, rect.top + 7))
            lines = self._wrap(mode["desc"], self.micro_font, rect.width - 30)
            y = rect.top + 28
            for line in lines[:2]:
                text = self.micro_font.render(line, True, (166, 181, 195))
                screen.blit(text, (rect.left + 20, y))
                y += 12

        pygame.draw.rect(screen, (8, 13, 24), self.back_rect.move(3, 3), border_radius=4)
        pygame.draw.rect(screen, (28, 38, 56), self.back_rect, border_radius=4)
        pygame.draw.rect(screen, (128, 146, 159), self.back_rect, 1, border_radius=4)
        back = self.micro_font.render("BACK TO TITLE", True, (227, 218, 190))
        screen.blit(back, back.get_rect(center=self.back_rect.center))
        hint_text = "CLICK A MODE  •  ARROWS TO SELECT  •  ENTER TO CONFIRM"
        hint = self._fit(hint_text, self.micro_font, WIDTH - 28)
        hint = self.micro_font.render(hint, True, (132, 153, 166))
        screen.blit(hint, hint.get_rect(center=(WIDTH // 2, 521)))

    @staticmethod
    def _fit(text, font, max_width):
        if font.size(text)[0] <= max_width:
            return text
        shortened = text
        while shortened and font.size(shortened + "…")[0] > max_width:
            shortened = shortened[:-1]
        return shortened.rstrip() + "…" if shortened else "…"

    def _wrap(self, text, font, max_width):
        words, lines, current = text.split(), [], ""
        for word in words:
            candidate = f"{current} {word}".strip()
            if current and font.size(candidate)[0] > max_width:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)
        return lines
