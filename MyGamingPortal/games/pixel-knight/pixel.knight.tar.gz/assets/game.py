"""Game loop and scene flow for Pixel Knight Level 1."""

import os
import json
import math
import random
import sys
import asyncio
from pathlib import Path

import pygame

from settings import (
    WIDTH,
    HEIGHT,
    FPS,
    TITLE,
    WORLD_WIDTH,
    GROUND_Y,
    TILE,
    MAX_HEALTH,
    ATTACK_COOLDOWN,
    SPRITES,
    SOUNDS,
    MUSIC,
    FONT_PATH,
    WHITE,
    GOLD,
    ROOT,
)
from camera import Camera
from effects import Effects
from falling_rock import FallingRock
from turret import Turret, TurretBolt
from enemy import Bat, BoneGuard, CampaignBoss, Crab, FireWisp, FlyingDemon, Slime, StormOrb
from menu import Menu
from player import Player
from shop import ItemShop
from world import World
from mobile_controls import MobileControls
from projectile import Arrow, ChocolateBolt, ChocolateMeteor, ChocolatePuddle
from levels import BOSS_LEVEL_IDS, next_level
from heroes import ALL_HERO_IDS, THE_12_HERO_IDS, get_hero, is_hero_unlocked
from hero_select import HeroSelectScreen
from mode_select import ModeSelectScreen, MODE_CONFIG

# Raw TCP is available in the desktop build but browser sandboxes require a
# WebSocket relay. The portal includes a separate browser-friendly Duel page.
if sys.platform in ("emscripten", "wasi"):
    OnlineLobbyScreen = None
else:
    try:
        from online_multiplayer import OnlineLobbyScreen
    except (ImportError, OSError):
        OnlineLobbyScreen = None


class Assets:
    """Loads the game assets and cuts sprite sheets into frames."""

    def __init__(self):
        self.sprites_root = SPRITES
        # The supplied Knight sheet is repacked into nine animation rows of
        # fixed 64x64 frames with a shared scale and foot anchor.
        knight_atlas = pygame.image.load(
            ROOT / "assets" / "heroes" / "knight_animation_atlas.png"
        ).convert_alpha()

        def knight_row(row, count=3):
            return [
                knight_atlas.subsurface(
                    pygame.Rect(index * 64, row * 64, 64, 64)
                ).copy()
                for index in range(count)
            ]

        self.idle_frames = knight_row(0)
        self.walk_frames = knight_row(1)
        self.run_frames = knight_row(2)
        self.attack_frames = knight_row(3)
        self.defend_frames = knight_row(4)
        self.jump_frames = knight_row(5)
        self.hurt_frames = knight_row(6)
        self.die_frames = knight_row(7, 2)
        self.skill_frames = knight_row(8, 2)
        self.roll_frames = self.skill_frames

        # Compatibility with player.py versions that use assets.player_frames.
        self.player_frames = self.run_frames

        # The supplied green Archer sheet is cropped into fixed 64px cells.
        # The final frames in shorter rows are left transparent in the atlas.
        archer_atlas = pygame.image.load(
            ROOT / "assets" / "heroes" / "archer_animation_atlas.png"
        ).convert_alpha()

        def archer_row(row, count):
            return [
                archer_atlas.subsurface(
                    pygame.Rect(index * 64, row * 64, 64, 64)
                ).copy()
                for index in range(count)
            ]

        self.archer_idle_frames = archer_row(0, 5)
        self.archer_walk_frames = archer_row(1, 6)
        self.archer_run_frames = archer_row(2, 6)
        self.archer_bow_frames = archer_row(3, 5)
        self.archer_melee_frames = archer_row(4, 8)
        self.archer_defend_frames = archer_row(5, 5)
        self.archer_jump_frames = archer_row(6, 6)
        self.archer_hurt_frames = archer_row(7, 5)
        self.archer_death_frames = archer_row(8, 4)
        self.archer_multi_frames = archer_row(9, 7)
        self.archer_dash_frames = archer_row(10, 5)

        choco_atlas = pygame.image.load(
            ROOT / "assets" / "heroes" / "choco_warrior_animation_atlas.png"
        ).convert_alpha()

        def choco_row(row, count):
            return [
                choco_atlas.subsurface(pygame.Rect(i * 64, row * 64, 64, 64)).copy()
                for i in range(count)
            ]

        self.choco_idle_frames = choco_row(0, 12)
        self.choco_walk_frames = choco_row(1, 16)
        self.choco_run_frames = self.choco_walk_frames
        self.choco_shoot_frames = choco_row(2, 12)
        # This sheet has no melee or ultimate row. Reuse its supplied shooting
        # poses while the existing combat effects handle the strong chocolate attacks.
        self.choco_melee_frames = self.choco_shoot_frames
        self.choco_jump_frames = choco_row(3, 12)
        self.choco_hurt_frames = choco_row(4, 6)
        self.choco_death_frames = choco_row(5, 12)
        self.choco_ultimate_frames = self.choco_shoot_frames

        self.bat_animations = {
            "idle": self._enemy_strip("bat_idle_fly.png", 64, 64, 9),
            "fly": self._enemy_strip("bat_run.png", 64, 64, 8),
            "attack": self._enemy_strip("bat_attack.png", 64, 64, 8),
            "hurt": self._enemy_strip("bat_hurt.png", 64, 64, 5),
            "death": self._enemy_strip("bat_death.png", 64, 64, 12),
        }
        self.skeleton_animations = {}
        for color in ("white", "yellow"):
            self.skeleton_animations[color] = {
                "idle": self._enemy_strip(f"skeleton_{color}_idle.png", 96, 64, 8),
                "walk": self._enemy_strip(f"skeleton_{color}_walk.png", 96, 64, 10),
                "attack": self._enemy_strip(f"skeleton_{color}_attack.png", 96, 64, 10),
                "hurt": self._enemy_strip(f"skeleton_{color}_hurt.png", 96, 64, 5),
                "death": self._enemy_strip(f"skeleton_{color}_death.png", 96, 64, 13),
            }
        self.flying_demon_animations = {
            "idle": self._enemy_strip("flying_demon_idle.png", 81, 71, 4),
            "fly": self._enemy_strip("flying_demon_flying.png", 81, 71, 4),
            "attack": self._enemy_strip("flying_demon_attack.png", 81, 71, 8),
            "hurt": self._enemy_strip("flying_demon_hurt.png", 81, 71, 4),
            "death": self._enemy_strip("flying_demon_death.png", 81, 71, 7),
        }
        self.frost_guardian_animations = {
            action: self._enemy_strip(f"frost_guardian_{action}.png", 128, 128, count)
            for action, count in (("idle", 6), ("walk", 10), ("attack", 14),
                                  ("hurt", 7), ("death", 16))
        }
        necromancer_atlas = pygame.image.load(
            ROOT / "assets" / "enemies" / "necromancer_atlas.png"
        ).convert_alpha()
        self.necromancer_animations = {
            action: [
                necromancer_atlas.subsurface(pygame.Rect(i * 128, row * 128, 128, 128)).copy()
                for i in range(count)
            ]
            for action, row, count in (("idle", 0, 8), ("walk", 1, 8),
                                       ("attack", 2, 13), ("hurt", 5, 5),
                                       ("death", 6, 9))
        }

        self.slime_frames = self._frames(
            "slime_green.png",
            frame_width=24,
            frame_height=24,
            count=4,
            row=1,
            scale=1,
        )
        self.slime_frames = self._normalize_frames(
            self.slime_frames,
            canvas_size=(48, 48),
            max_sprite_size=(38, 30),
        )
        self.purple_slime_frames = self._frames(
            "slime_purple.png",
            frame_width=24,
            frame_height=24,
            count=4,
            row=1,
            scale=1,
        )
        self.purple_slime_frames = self._normalize_frames(
            self.purple_slime_frames,
            canvas_size=(48, 48),
            max_sprite_size=(38, 30),
        )

        # Six transparent frames supplied for the Bone Guard's walk cycle.
        self.bone_guard_frames = self._horizontal_frames(
            "bone_guard_walk.png",
            count=6,
        )
        self.bone_guard_frames = self._normalize_frames(
            self.bone_guard_frames,
            canvas_size=(44, 50),
            max_sprite_size=(34, 42),
        )

        # Use only the supplied Idle and Aim rows. Shared sizing and a fixed
        # stone-base anchor keep the turret from changing size between poses.
        turret_sources = self._horizontal_frames("turret_idle_strip.png", count=4)
        turret_sources.extend(self._horizontal_frames("turret_aim_strip.png", count=6))
        normalized_turrets = self._normalize_frames(
            turret_sources,
            canvas_size=(96, 96),
            max_sprite_size=(90, 90),
        )
        self.turret_idle_frames = normalized_turrets[:4]
        self.turret_aim_frames = normalized_turrets[4:]

        self.coin_frames = self._frames(
            "coin.png",
            frame_width=16,
            frame_height=16,
            count=6,
            row=0,
            scale=2,
        )

        # Falling-rock trap sprites supplied for the Cold + Peaceful levels.
        self.falling_rock_fall_frames = self._frames(
            "falling_rock_fall.png",
            frame_width=112,
            frame_height=112,
            count=6,
            row=0,
            scale=1,
        )
        self.falling_rock_impact_frames = self._frames(
            "falling_rock_impact.png",
            frame_width=112,
            frame_height=112,
            count=5,
            row=0,
            scale=1,
        )

        # Grass and ground tiles from the platform sprite sheet.
        self.tile_ground = self._crop(
            "world_tileset.png",
            (0, 0, 16, 16),
            (32, 32),
        )
        self.ground_fill_tiles = [
            self._crop("world_tileset.png", (0, 16, 16, 16), (32, 32)),
            self._crop("world_tileset.png", (16, 16, 16, 16), (32, 32)),
        ]
        self.platform_top = pygame.transform.scale(
            self._image("grass_platform_4tile_seamless.png"),
            (TILE * 4, TILE),
        )

        # The bundled atlas contains matching terrain caps and fill tiles for
        # all campaign biomes, plus pixel-art landmarks used by the maps.
        world_atlas = self._image("world_tileset.png")
        self.terrain_tiles = {}
        for column in range(9):
            cap = world_atlas.subsurface(pygame.Rect(column * 16, 0, 16, 16)).copy()
            fill = world_atlas.subsurface(pygame.Rect(column * 16, 16, 16, 16)).copy()
            self.terrain_tiles[column] = (
                pygame.transform.scale(cap, (TILE, TILE)),
                pygame.transform.scale(fill, (TILE, TILE)),
            )

        prop_rects = {
            "tree": (32, 80, 48, 64),
            "bush": (16, 48, 16, 16),
            "crate": (112, 48, 16, 16),
            "broken_crate": (112, 64, 16, 16),
            "sign": (128, 48, 16, 16),
            "ladder": (144, 48, 16, 48),
            "crystal": (80, 48, 16, 48),
            "mushroom_gold": (112, 96, 16, 16),
            "mushroom_cream": (128, 96, 16, 16),
            "mushroom_purple": (112, 112, 16, 16),
            "mushroom_teal": (128, 112, 16, 16),
        }
        self.world_props = {
            name: world_atlas.subsurface(pygame.Rect(source_rect)).copy()
            for name, source_rect in prop_rects.items()
        }

        self.sounds = {}
        for name in ("jump", "coin", "hurt", "tap", "explosion", "power_up"):
            try:
                sound = pygame.mixer.Sound(SOUNDS / f"{name}.wav")
                vol = 0.35 if name == "coin" else (0.45 if name == "jump" else 0.50)
                sound.set_volume(vol)
                self.sounds[name] = sound
            except (pygame.error, FileNotFoundError):
                self.sounds[name] = None

    @staticmethod
    def _image(filename):
        image = pygame.image.load(SPRITES / filename).convert_alpha()
        # The supplied running-strip image has a solid white backdrop.
        # Treat that exact white as transparent so it does not show around the knight.
        if filename == "knight_run.png":
            image.set_colorkey((255, 255, 255))
        return image

    def _frames(
        self,
        filename,
        frame_width,
        frame_height,
        count,
        row=0,
        scale=1,
    ):
        sheet = self._image(filename)
        frames = []

        for column in range(count):
            frame = pygame.Surface(
                (frame_width, frame_height),
                pygame.SRCALPHA,
            )

            source_rect = pygame.Rect(
                column * frame_width,
                row * frame_height,
                frame_width,
                frame_height,
            )
            frame.blit(sheet, (0, 0), source_rect)

            # The supplied running sheet has whitespace inside each frame.
            # Crop to the visible knight pixels so its feet align with platforms.
            if filename == "knight_run.png":
                visible = frame.get_bounding_rect()
                if visible.width and visible.height:
                    frame = frame.subsurface(visible).copy()

            if scale != 1:
                frame = pygame.transform.scale(
                    frame,
                    (frame.get_width() * scale, frame.get_height() * scale),
                )

            frames.append(frame)

        return frames

    @staticmethod
    def _enemy_strip(filename, frame_width, frame_height, count):
        sheet = pygame.image.load(
            ROOT / "assets" / "enemies" / filename
        ).convert_alpha()
        return [
            sheet.subsurface(pygame.Rect(i * frame_width, 0, frame_width, frame_height)).copy()
            for i in range(count)
        ]

    def _horizontal_frames(self, filename, count):
        """Split a horizontal strip evenly, including uneven final pixels."""
        sheet = self._image(filename)
        frames = []
        for index in range(count):
            left = round(index * sheet.get_width() / count)
            right = round((index + 1) * sheet.get_width() / count)
            frame = pygame.Surface(
                (right - left, sheet.get_height()),
                pygame.SRCALPHA,
            )
            frame.blit(sheet, (0, 0), pygame.Rect(left, 0, right - left, sheet.get_height()))
            frames.append(frame)
        return frames

    def _crop(self, filename, source_rect, output_size):
        image = self._image(filename)
        tile = pygame.Surface(
            (source_rect[2], source_rect[3]),
            pygame.SRCALPHA,
        )
        tile.blit(image, (0, 0), pygame.Rect(source_rect))
        return pygame.transform.scale(tile, output_size)

    @staticmethod
    def _normalize_knight_frames(frames):
        normalized = []
        canvas_size = (64, 64)
        target_width, target_height = 28, 38

        for frame in frames:
            bounds = frame.get_bounding_rect()
            visible = frame.subsurface(bounds).copy()
            scale = min(
                target_width / visible.get_width(),
                target_height / visible.get_height(),
            )
            size = (
                max(1, round(visible.get_width() * scale)),
                max(1, round(visible.get_height() * scale)),
            )
            sprite = pygame.transform.scale(visible, size)

            canvas = pygame.Surface(canvas_size, pygame.SRCALPHA)
            canvas.blit(
                sprite,
                (
                    (canvas_size[0] - sprite.get_width()) // 2,
                    canvas_size[1] - sprite.get_height(),
                ),
            )
            normalized.append(canvas)

        return normalized

    @staticmethod
    def _normalize_frames(frames, canvas_size, max_sprite_size):
        normalized = []
        target_width, target_height = max_sprite_size

        for frame in frames:
            bounds = frame.get_bounding_rect()
            visible = frame.subsurface(bounds).copy()
            scale = min(
                target_width / visible.get_width(),
                target_height / visible.get_height(),
            )
            size = (
                max(1, round(visible.get_width() * scale)),
                max(1, round(visible.get_height() * scale)),
            )
            sprite = pygame.transform.scale(visible, size)
            canvas = pygame.Surface(canvas_size, pygame.SRCALPHA)
            canvas.blit(
                sprite,
                (
                    (canvas_size[0] - sprite.get_width()) // 2,
                    canvas_size[1] - sprite.get_height(),
                ),
            )
            normalized.append(canvas)

        return normalized

    @staticmethod
    def _normalize_shared_frames(frames, canvas_size, max_sprite_size):
        visible_frames = []
        for frame in frames:
            bounds = frame.get_bounding_rect()
            if bounds.width == 0 or bounds.height == 0:
                visible_frames.append(None)
            else:
                visible_frames.append(frame.subsurface(bounds).copy())

        populated = [frame for frame in visible_frames if frame is not None]
        if not populated:
            return [pygame.Surface(canvas_size, pygame.SRCALPHA) for _ in frames]

        max_width, max_height = max_sprite_size
        shared_scale = min(
            max_width / max(frame.get_width() for frame in populated),
            max_height / max(frame.get_height() for frame in populated),
        )
        normalized = []
        for visible in visible_frames:
            canvas = pygame.Surface(canvas_size, pygame.SRCALPHA)
            if visible is not None:
                size = (
                    max(1, round(visible.get_width() * shared_scale)),
                    max(1, round(visible.get_height() * shared_scale)),
                )
                sprite = pygame.transform.scale(visible, size)
                canvas.blit(
                    sprite,
                    ((canvas_size[0] - sprite.get_width()) // 2,
                     canvas_size[1] - sprite.get_height()),
                )
            normalized.append(canvas)
        return normalized

    def play(self, name):
        sound = self.sounds.get(name)
        if sound:
            sound.play()


class Game:
    CHOCO_UNLOCK_PRICE = 50

    def __init__(self):
        self.is_mobile_runtime = (
            sys.platform in ("android", "ios", "emscripten", "wasi")
            or bool(os.environ.get("ANDROID_ARGUMENT"))
        )
        self.mobile_controls_enabled = self.is_mobile_runtime or os.environ.get("PIXEL_KNIGHT_MOBILE") == "1"
        # Android uses a true fullscreen landscape surface with a fixed 16:9
        # logical canvas. SDL scales the pixel-art viewport without stretching
        # characters; desktop keeps its resizable window.
        display_flags = (
            pygame.SCALED | pygame.FULLSCREEN
            if self.is_mobile_runtime
            else pygame.SCALED | pygame.RESIZABLE
        )
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), display_flags)
        pygame.display.set_caption(TITLE)

        self.clock = pygame.time.Clock()
        self.font = self._font(19)
        self.small_font = self._font(15)
        self.micro_font = self._font(11)
        self.title_font = self._font(46)

        self.assets = Assets()
        self.menu = Menu(
            self.font,
            self.title_font,
            self.assets,
            self.micro_font,
            touch_controls_enabled=self.mobile_controls_enabled,
            touch_controls_locked=self.is_mobile_runtime,
        )
        # Phone builds are always landscape fullscreen; the setting is shown
        # as ON rather than offering a mode that can strand the touch layout.
        self.menu.fullscreen_enabled = self.is_mobile_runtime
        self.shop = ItemShop(self.font, self.small_font, self.title_font)
        self.camera = Camera(WIDTH, HEIGHT, WORLD_WIDTH)
        self.hero_select_screen = HeroSelectScreen(self.font, self.title_font, self.small_font, self.micro_font, self.assets)
        self.mode_select_screen = ModeSelectScreen(self.font, self.title_font, self.small_font, self.micro_font, self.assets)

        self.state = "menu"
        self.online_lobby = None
        self.online_duel = None
        self.online_server = None
        self.online_client = None
        self.progress_coins, self.unlocked_heroes, self.boss_shards = self._load_progress()
        self.boss_drop = None
        self.boss_drop_spawned = False
        self.boss_checkpoint = None
        self.hero_select_message = ""
        # Start with the dedicated Knight atlas. Placeholder/tinted heroes
        # stay hidden until they receive their own complete sprite sheets.
        self.selected_hero = "knight"
        self.menu.selected_hero = self.selected_hero
        self.hero_select_from_menu = False
        self.hero_select_from_mode_select = False
        self.selected_game_mode = "story"
        self.mode_config = MODE_CONFIG["story"]
        self.survival_cycles = 0
        self.mode_time_remaining = None
        self.mode_elapsed = 0.0
        self.mode_timed_out = False
        self.menu_resume_state = None
        self.running = True
        self.jump_pressed = False
        self.explore_mode = False
        self.speed_bonus = 0
        self.shield_charges = 0
        self.max_health = MAX_HEALTH
        self.level_number = 1
        self.level_banner_timer = 0.0
        self.mobile_controls = MobileControls()
        self.mobile_pointers = {}
        self.turret_bolts = []
        self.player_arrows = []
        self.choco_meteors = []
        self.choco_puddles = []
        self.active_abilities = []
        self.choco_ultimate_timer = 0.0
        self.choco_ultimate_next = 0.0
        self.choco_meteors_left = 0
        self.turrets = []
        self.effects = Effects()
        self._was_dashing = False
        self._was_on_ground = False

        # In-level leave confirmation UI.
        self.leave_rect = self._leave_button_rect()
        self.leave_yes_rect = pygame.Rect(WIDTH // 2 - 126, HEIGHT // 2 + 42, 110, 46)
        self.leave_no_rect = pygame.Rect(WIDTH // 2 + 16, HEIGHT // 2 + 42, 110, 46)

        self.level_start_coins = self.progress_coins
        self.reset_level(1)
        self.start_music()

    def _leave_button_rect(self):
        if self.mobile_controls_enabled:
            return pygame.Rect(WIDTH - 82, 112, 70, 38)
        return pygame.Rect(WIDTH - 142, HEIGHT - 82, 126, 40)

    @staticmethod
    def _progress_file():
        # python-for-android provides ANDROID_PRIVATE as a writable per-app
        # directory. Desktop builds continue to use the standard user profile.
        if os.environ.get("ANDROID_PRIVATE"):
            data_root = Path(os.environ["ANDROID_PRIVATE"])
        else:
            data_root = Path(os.environ.get("APPDATA", Path.home()))
        return data_root / "Pixel Knight" / "profile.json"

    def _load_progress(self):
        unlocked = {"frost_knight", "knight", "ranger", "mage", "archer"}
        try:
            profile = json.loads(self._progress_file().read_text(encoding="utf-8"))
            coins = max(0, int(profile.get("coins", 0)))
            boss_shards = max(0, int(profile.get("boss_shards", 0)))
            for h in profile.get("unlocked_heroes", []):
                unlocked.add(h)
            return coins, unlocked, boss_shards
        except (OSError, ValueError, TypeError):
            return 0, unlocked, 0

    def _save_progress(self):
        path = self._progress_file()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({
                "coins": self.progress_coins,
                "boss_shards": getattr(self, "boss_shards", 0),
                "unlocked_heroes": sorted(self.unlocked_heroes),
            }, indent=2), encoding="utf-8")
        except OSError:
            pass

    def _award_coin(self, amount=1):
        amount = max(1, int(amount * self.mode_config.get("coin_multiplier", 1)))
        self.player.coins += amount
        self.progress_coins += amount
        self.level_start_coins = self.player.coins
        self._save_progress()

    def _retry_level(self):
        checkpoint = self.boss_checkpoint
        if checkpoint and checkpoint["level"] == self.level_number:
            self.reset_level(
                checkpoint["level"],
                carried_coins=checkpoint["coins"],
                carried_health=checkpoint["health"],
                carried_speed_bonus=checkpoint["speed"],
                carried_shields=checkpoint["shields"],
            )
        else:
            retry_health = int(self.mode_config.get("start_health", MAX_HEALTH))
            self.reset_level(carried_health=retry_health)

    def _select_hero(self, hero_type):
        if hero_type == "choco" and hero_type not in self.unlocked_heroes:
            if self.progress_coins < self.CHOCO_UNLOCK_PRICE:
                self.hero_select_message = (
                    f"CHOCO WARRIOR COSTS {self.CHOCO_UNLOCK_PRICE} GOLD  •  "
                    f"YOU HAVE {self.progress_coins}"
                )
                return
            self.progress_coins -= self.CHOCO_UNLOCK_PRICE
            self.player.coins = max(0, self.player.coins - self.CHOCO_UNLOCK_PRICE)
            self.level_start_coins = self.player.coins
            self.unlocked_heroes.add("choco")
            self._save_progress()
            self.hero_select_message = "CHOCO WARRIOR UNLOCKED!"
        self._choose_hero(hero_type)

    def _spend_coins(self, amount):
        self.player.coins -= amount
        self.progress_coins = max(0, self.progress_coins - amount)
        self.level_start_coins = self.player.coins
        self._save_progress()

    def _finger_position(self, event):
        """Convert SDL's normalized physical touch point to the 16:9 game canvas.

        On modern phones the screen can be much wider than 16:9. The game
        preserves pixel-art proportions and centers its viewport; touches in
        the side bars are ignored instead of being mapped to the wrong button.
        """
        try:
            window_w, window_h = pygame.display.get_window_size()
        except (AttributeError, pygame.error):
            window_w, window_h = WIDTH, HEIGHT
        window_w = max(1, int(window_w))
        window_h = max(1, int(window_h))

        scale = min(window_w / WIDTH, window_h / HEIGHT)
        view_w = WIDTH * scale
        view_h = HEIGHT * scale
        offset_x = (window_w - view_w) * 0.5
        offset_y = (window_h - view_h) * 0.5
        px = float(event.x) * window_w
        py = float(event.y) * window_h

        if px < offset_x or px >= offset_x + view_w or py < offset_y or py >= offset_y + view_h:
            return (-1000, -1000)
        x = round((px - offset_x) / scale)
        y = round((py - offset_y) / scale)
        return (max(0, min(WIDTH - 1, x)), max(0, min(HEIGHT - 1, y)))

    def _activate_mobile_control(self, control):
        if self.state != "playing":
            return
        if control == "jump":
            self.jump_pressed = True
        elif control == "attack":
            self.start_player_attack()
        elif control == "dash":
            self.player.start_dash()
        elif control == "ability":
            self.trigger_hero_ability()
        elif control == "shield" and self.player.hero_type == "choco" and self.player.ultimate_charge >= 100:
            self.activate_chocolate_rain()

    def trigger_hero_ability(self):
        if not self.player.health or self.player.ability_cooldown > 0:
            return False
        hero_obj = getattr(self.player, "hero_obj", None)
        if hero_obj and hasattr(hero_obj, "trigger_ability"):
            hero_obj.trigger_ability(self.player, self)
            self.player.ability_cooldown = getattr(hero_obj, "ability_cooldown", 5.0)
            self.player.ability_anim_timer = 0.4
            return True
        return False

    def start_player_attack(self, heavy=False):
        if not self.player.start_attack(heavy=heavy):
            return False
        self.assets.play("tap")
        if self.world.react_to_attack(self.player.rect.centerx, self.camera.offset.x):
            color = (130, 255, 100) if self.player.hero_type == "archer" else (255, 132, 48) if self.player.hero_type == "choco" else (123, 230, 250)
            self.effects.impact_ring(
                self.player.rect.centerx,
                self.player.rect.centery,
                color,
            )
        return True

    def activate_chocolate_rain(self):
        if self.player.hero_type != "choco" or self.player.ultimate_charge < 100 or self.choco_ultimate_timer > 0:
            return False
        self.player.ultimate_charge = 0
        self.player.ability_anim_timer = 0.8
        self.choco_ultimate_timer = 4.0
        self.choco_ultimate_next = 0.12
        self.choco_meteors_left = 7
        self.effects.impact_ring(self.player.rect.centerx, self.player.rect.centery, (255, 123, 39))
        self.effects.camera_shake(4, 0.16)
        self.assets.play("tap")
        return True

    def _update_chocolate_abilities(self, dt):
        if self.player.hero_type != "choco":
            return
        if self.choco_ultimate_timer > 0:
            self.choco_ultimate_timer = max(0.0, self.choco_ultimate_timer - dt)
            self.choco_ultimate_next -= dt
            if self.choco_meteors_left and self.choco_ultimate_next <= 0:
                targets = [e for e in self.enemies if e.alive and not getattr(e, "dying", False)]
                nearby = [e for e in targets if abs(e.rect.centerx - self.player.rect.centerx) < 680]
                if nearby:
                    target = random.choice(nearby)
                    x = target.rect.centerx + random.randint(-44, 44)
                    y = target.rect.bottom
                else:
                    x = max(24, min(self.world.world_width - 24,
                                   self.player.rect.centerx + self.player.facing * random.randint(140, 480)))
                    surfaces = [p.top for p in self.world.platforms
                                if p.left <= x <= p.right and p.top >= self.player.rect.top]
                    y = min(surfaces) if surfaces else GROUND_Y
                self.choco_meteors.append(ChocolateMeteor(x, y))
                self.choco_meteors_left -= 1
                self.choco_ultimate_next = 0.48

        for meteor in self.choco_meteors:
            meteor.update(dt)
            if not meteor.impact:
                continue
            self.choco_puddles.append(ChocolatePuddle(meteor.x, meteor.target_y))
            self.effects.impact_ring(meteor.x, meteor.target_y - 6, (255, 116, 35))
            self.effects.hit_spark(meteor.x, meteor.target_y - 12, 1, heavy=True)
            self.effects.camera_shake(3, 0.12)
            for enemy in self.enemies:
                if not enemy.alive or getattr(enemy, "dying", False):
                    continue
                dx = enemy.rect.centerx - meteor.x
                dy = enemy.rect.bottom - meteor.target_y
                if dx * dx + dy * dy > 64 * 64:
                    continue
                defeated = enemy.take_hit()
                enemy.choco_slow_timer = 2.7
                if not isinstance(enemy, Turret):
                    enemy.rect.x += 16 if dx >= 0 else -16
                self.effects.floating_text(enemy.rect.centerx, enemy.rect.top - 8, "SLOWED", (255, 174, 92))
                if defeated:
                    self.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    self._award_coin()
                    self.assets.play("coin")
        self.choco_meteors = [m for m in self.choco_meteors if m.alive]
        for puddle in self.choco_puddles:
            puddle.update(dt)
            for enemy in self.enemies:
                if enemy.alive and puddle.contains(enemy.rect):
                    enemy.choco_slow_timer = max(getattr(enemy, "choco_slow_timer", 0.0), 0.35)
        self.choco_puddles = [p for p in self.choco_puddles if p.timer > 0]

    def _update_active_abilities(self, dt):
        for ab in self.active_abilities:
            if hasattr(ab, "update"):
                try:
                    ab.update(dt)
                except TypeError:
                    ab.update(dt, player_center=(self.player.rect.centerx, self.player.rect.centery))
            for enemy in self.enemies:
                if enemy.alive and not getattr(enemy, "dying", False):
                    if hasattr(ab, "check_hit") and ab.check_hit(enemy):
                        defeated = enemy.take_hit()
                        if getattr(self.player, "hero_type", "") in ("frost_knight", "glacier_knight"):
                            enemy.choco_slow_timer = 2.5
                        self.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, self.player.facing, heavy=True)
                        if defeated:
                            self.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                            self._award_coin()
                            self.assets.play("coin")
                        else:
                            self.assets.play("tap")
        self.active_abilities = [ab for ab in self.active_abilities if getattr(ab, "alive", True)]

    def draw_active_abilities(self):
        for ab in self.active_abilities:
            if hasattr(ab, "draw"):
                ab.draw(self.screen, self.camera)

    def draw_chocolate_abilities(self):
        for puddle in self.choco_puddles:
            puddle.draw(self.screen, self.camera)
        for meteor in self.choco_meteors:
            meteor.draw(self.screen, self.camera)

    def _handle_pointer_down(self, pointer_id, position):
        if self.state == "playing":
            if not self.mobile_controls_enabled:
                return
            if self.leave_rect.collidepoint(position):
                self.mobile_pointers.clear()
                self.state = "confirm_leave"
                return
            control = self.mobile_controls.hit_test(position)
            if control is not None:
                previously_held = set(self.mobile_pointers.values())
                self.mobile_pointers[pointer_id] = control
                if control not in previously_held:
                    self._activate_mobile_control(control)
            return
        self._handle_mouse_button_down(position, 1)

    def _handle_pointer_move(self, pointer_id, position):
        if pointer_id not in self.mobile_pointers:
            return
        previously_held = set(self.mobile_pointers.values())
        control = self.mobile_controls.hit_test(position)
        old_control = self.mobile_pointers.pop(pointer_id)
        if control is not None:
            self.mobile_pointers[pointer_id] = control
        if control is not None and control != old_control and control not in previously_held:
            self._activate_mobile_control(control)

    def _handle_mouse_button_down(self, position, button):
        if self.state == "hero_select" and button == 1:
            action = self.hero_select_screen.handle_click(position, self)
            if action == "back":
                self.hero_select_from_menu = False
                if self.hero_select_from_mode_select:
                    self.hero_select_from_mode_select = False
                    self.state = "mode_select"
                else:
                    self.state = "menu"
            elif action == "play":
                self.hero_select_from_menu = False
        elif self.state == "mode_select" and button == 1:
            self._handle_mode_select_action(self.mode_select_screen.handle_click(position))
        elif self.state == "online_unavailable" and button == 1:
            self.state = "menu"
        elif self.state == "menu":
            self._handle_menu_action(self.menu.handle_click(position))
        elif self.state == "playing" and button == 1:
            if self.leave_rect.collidepoint(position):
                self.state = "confirm_leave"
            elif not self.mobile_controls_enabled:
                self.start_player_attack()
        elif self.state == "confirm_leave" and button == 1:
            if self.leave_yes_rect.collidepoint(position):
                self._return_to_menu("playing")
                pygame.display.set_caption("Pixel Knight")
            elif self.leave_no_rect.collidepoint(position):
                self.state = "playing"
        elif self.state == "shop":
            action = self.shop.handle_click(position)
            if action == "continue":
                self.continue_from_shop()
            elif action in ("heart", "speed", "ward"):
                self.buy_shop_item(action)
        elif self.state == "paused":
            self.state = "playing"
        elif self.state in ("game_over", "complete"):
            if self.state == "game_over":
                if self.mode_timed_out:
                    self.begin_adventure()
                else:
                    self._retry_level()
                    self.state = "playing"
            else:
                self._return_to_menu()

    def _font(self, size):
        try:
            return pygame.font.Font(str(FONT_PATH), size)
        except (pygame.error, FileNotFoundError):
            return pygame.font.Font(None, size)

    def start_music(self):
        try:
            music_file = MUSIC / "time_for_adventure.ogg" if (MUSIC / "time_for_adventure.ogg").exists() else MUSIC / "time_for_adventure.mp3"
            pygame.mixer.music.load(str(music_file))
            pygame.mixer.music.set_volume(self.menu.music_volume if self.menu.music_enabled else 0.0)
            pygame.mixer.music.play(-1)
        except (pygame.error, FileNotFoundError):
            pass

    def apply_music_setting(self):
        """Apply the menu's music switch without changing sound effects."""
        try:
            pygame.mixer.music.set_volume(self.menu.music_volume if self.menu.music_enabled else 0.0)
        except pygame.error:
            pass

    def begin_adventure(self):
        """Start a fresh run with the selected mode's rules applied."""
        self.mode_config = MODE_CONFIG.get(self.selected_game_mode, MODE_CONFIG["story"])
        self.survival_cycles = 0
        self.mode_time_remaining = self.mode_config.get("timer")
        self.mode_elapsed = 0.0
        self.mode_timed_out = False
        self.speed_bonus = 0
        self.shield_charges = 0
        self.explore_mode = bool(self.mode_config.get("explore", False) or self.menu.explore_mode)
        self.level_start_coins = self.progress_coins
        start_level = int(self.mode_config.get("start_level", 1))
        starting_health = int(self.mode_config.get("start_health", MAX_HEALTH))
        self.reset_level(start_level, carried_health=starting_health)
        self.state = "playing"
        self.menu_resume_state = "playing"
        self.menu.continue_available = True
        self.assets.play("tap")

    def _configure_player_for_mode(self):
        """Reapply player modifiers whenever a level creates a fresh Player."""
        if not hasattr(self, "player"):
            return
        cfg = getattr(self, "mode_config", MODE_CONFIG["story"])
        self.player.speed_multiplier = float(cfg.get("speed_multiplier", 1.0))
        self.player.gravity_multiplier = float(cfg.get("gravity_multiplier", 1.0))
        self.player.jump_multiplier = float(cfg.get("jump_multiplier", 1.0))
        self.player.cooldown_rate = float(cfg.get("cooldown_rate", 1.0))
        self.player.control_inverted = bool(cfg.get("control_inverted", False))
        if cfg.get("start_health"):
            self.player.health = min(self.player.max_health, int(self.player.health))

    def _scale_enemies_for_mode(self):
        """Apply per-mode enemy toughness, scaling endless runs as they loop."""
        cfg = getattr(self, "mode_config", MODE_CONFIG["story"])
        multiplier = float(cfg.get("enemy_hp", 1.0))
        if cfg.get("endless"):
            multiplier *= 1.0 + min(2.0, self.survival_cycles * 0.12)
        seen = set()
        targets = list(getattr(self, "enemies", []))
        boss = getattr(self, "boss", None)
        if boss is not None:
            targets.append(boss)
        for enemy in targets:
            if enemy is None or id(enemy) in seen:
                continue
            seen.add(id(enemy))
            base_health = getattr(enemy, "max_health", None)
            if not isinstance(base_health, (int, float)) or base_health <= 0:
                continue
            scaled = max(1, int(round(base_health * multiplier)))
            enemy.max_health = scaled
            enemy.health = scaled

    def _return_to_menu(self, resume_state=None):
        self.menu_resume_state = resume_state
        self.menu.continue_available = resume_state is not None
        self.menu.focus_index = 1 if resume_state is not None else 0
        self.state = "menu"
        pygame.display.set_caption("Pixel Knight")

    def _toggle_fullscreen(self):
        """Toggle desktop fullscreen; mobile builds stay fullscreen landscape."""
        if self.is_mobile_runtime:
            self.menu.fullscreen_enabled = True
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.SCALED | pygame.FULLSCREEN)
            return
        try:
            pygame.display.toggle_fullscreen()
        except (pygame.error, AttributeError):
            flags = pygame.SCALED | pygame.FULLSCREEN if self.menu.fullscreen_enabled else pygame.SCALED | pygame.RESIZABLE
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)

    def _handle_menu_action(self, action):
        if action == "play":
            self.hero_select_from_menu = False
            self.hero_select_from_mode_select = False
            self.state = "mode_select"
        elif action == "heroes":
            self.hero_select_from_menu = True
            self.state = "hero_select"
        elif action == "online":
            if OnlineLobbyScreen is None:
                self.state = "online_unavailable"
            else:
                if self.online_lobby:
                    self.online_lobby.close()
                self.online_lobby = OnlineLobbyScreen(self)
                self.state = "online_lobby"
        elif action == "continue" and self.menu.continue_available:
            if self.menu_resume_state == "game_over":
                self._retry_level()
            self.state = "playing"
            self.menu_resume_state = "playing"
        elif action in ("music", "volume"):
            self.apply_music_setting()
        elif action == "controls":
            if self.is_mobile_runtime:
                # Never allow a phone player to disable the only input method.
                self.menu.touch_controls_enabled = True
                self.mobile_controls_enabled = True
            else:
                self.mobile_controls_enabled = self.menu.touch_controls_enabled
            self.leave_rect = self._leave_button_rect()
            self.mobile_pointers.clear()
        elif action == "fullscreen":
            if self.is_mobile_runtime:
                self.menu.fullscreen_enabled = True
            else:
                self._toggle_fullscreen()
        elif action == "quit":
            self.running = False

    def _handle_mode_select_action(self, action):
        if action == "back":
            self.state = "menu"
            self.assets.play("tap")
        elif action in MODE_CONFIG:
            self.selected_game_mode = action
            self.hero_select_from_menu = False
            self.hero_select_from_mode_select = True
            self.hero_select_screen.selected_hero_id = self.selected_hero
            self.state = "hero_select"
            self.assets.play("tap")

    @staticmethod
    def _hero_card_rect(index):
        card_w, gap = 168, 12
        start_x = (WIDTH - (card_w * 5 + gap * 4)) // 2
        return pygame.Rect(start_x + index * (card_w + gap), 145, card_w, 238)

    def _choose_hero(self, hero_type):
        self.selected_hero = hero_type
        self.menu.selected_hero = hero_type
        if self.hero_select_from_menu:
            # If this menu was opened during a paused run, swap the active
            # character in place so Continue keeps the current level progress.
            if self.menu_resume_state == "playing":
                self._switch_player_hero(hero_type)
            self.hero_select_from_menu = False
            self.state = "menu"
        else:
            self.hero_select_from_mode_select = False
            self.begin_adventure()

    def _switch_player_hero(self, hero_type):
        old = self.player
        replacement = Player(old.rect.x, old.rect.y, self.assets, hero_type)
        replacement.rect.size = old.rect.size
        replacement.velocity.update(old.velocity)
        replacement.health = old.health
        replacement.coins = old.coins
        replacement.speed_bonus = old.speed_bonus
        replacement.shield_charges = old.shield_charges
        replacement.ultimate_charge = old.ultimate_charge if hero_type == "choco" else 0.0
        replacement.facing = old.facing
        replacement.on_ground = old.on_ground
        replacement.standing_platform = old.standing_platform
        replacement.spawn = old.spawn.copy()
        replacement.invulnerable = old.invulnerable
        self.player = replacement
        self.player_arrows = []
        self.choco_meteors = []
        self.choco_puddles = []
        self.choco_ultimate_timer = 0.0
        self.choco_meteors_left = 0

    def _falling_rock_specs(self):
        """Normalize falling-rock specs; old 3-value layouts still work."""
        specs = []
        for spec in getattr(self.world.layout, "FALLING_ROCKS", []):
            if len(spec) >= 4:
                specs.append(tuple(spec[:4]))
            else:
                x, target_y, delay = spec
                specs.append((x, target_y, delay, -48))
        return specs

    def reset_level(
        self,
        level_number=None,
        carried_coins=None,
        carried_health=MAX_HEALTH,
        carried_speed_bonus=None,
        carried_shields=None,
    ):
        if level_number is not None:
            if level_number != self.level_number:
                self.boss_checkpoint = None
            self.level_number = level_number
        if carried_coins is None:
            # Dying or restarting keeps the coins you arrived with.
            carried_coins = getattr(self, "level_start_coins", 0)
        self.level_start_coins = carried_coins
        if carried_speed_bonus is not None:
            self.speed_bonus = carried_speed_bonus
        if carried_shields is not None:
            self.shield_charges = carried_shields

        self.level_banner_timer = 0.0
        self.boss_drop = None
        self.boss_drop_spawned = False
        self.world = World(self.assets, self.level_number)
        if not hasattr(self.world, "candy_stashes"):
            self.world.candy_stashes = [
                pygame.Rect(x, y, 26, 26)
                for x, y in getattr(self.world.layout, "CANDY_STASHES", [])
            ]
        self.camera.world_width = self.world.world_width
        self.boss_arena_active = False
        self.world.boss_arena_active = False
        self.falling_rocks = [
            FallingRock(
                x, target_y,
                self.assets.falling_rock_fall_frames,
                self.assets.falling_rock_impact_frames,
                delay,
                spawn_y,
            )
            for x, target_y, delay, spawn_y in self._falling_rock_specs()
        ]
        self.player = Player(72, GROUND_Y - 48, self.assets, self.selected_hero)
        self.player.coins = carried_coins
        self.player.health = carried_health
        self.player.speed_bonus = self.speed_bonus
        self.player.shield_charges = self.shield_charges
        slime_health = 3 if self.level_number >= 8 else 2 if self.level_number >= 4 else 1
        slime_frames = (self.assets.purple_slime_frames
                       if getattr(self.world.layout, "SLIME_STYLE", "green") == "purple"
                       else self.assets.slime_frames)
        self.enemies = [Slime(x, y, slime_frames, left, right, health=slime_health)
                        for x, y, left, right in self.world.enemy_spawns]
        self.enemies.extend(
            Crab(x, y, left, right, health=2)
            for x, y, left, right in self.world.crab_spawns
        )
        self.enemies.extend(
            BoneGuard(x, y, left, right, health=3,
                      animations=self.assets.skeleton_animations[
                          "white" if i % 2 == 0 else "yellow"])
            for i, (x, y, left, right) in enumerate(self.world.bone_guard_spawns)
        )
        flying_health = 2 if self.level_number >= 8 else 1
        self.enemies.extend(Bat(x, y, left, right, health=flying_health,
                                animations=self.assets.bat_animations)
                            for x, y, left, right in self.world.flying_enemy_spawns)
        self.enemies.extend(FlyingDemon(x, y, left, right, health=4,
                                        animations=self.assets.flying_demon_animations)
                            for x, y, left, right in self.world.demon_spawns)
        self.enemies.extend(StormOrb(x, y, left, right, health=2)
                            for x, y, left, right in self.world.storm_orb_spawns)
        self.enemies.extend(FireWisp(x, y, left, right, health=2)
                            for x, y, left, right in self.world.fire_wisp_spawns)
        self.boss = None
        if self.world.boss_spawn:
            kind, x, y, left, right = self.world.boss_spawn
            if kind == "frost":
                boss_frames, boss_name, boss_health = self.assets.frost_guardian_animations, "FROST GUARDIAN", 14
                boss_scale, boss_hitbox = 1.9, (160, 190)
            else:
                boss_frames, boss_name, boss_health = self.assets.necromancer_animations, "NECROMANCER", 16
                boss_scale, boss_hitbox = 1.0, (88, 100)
            self.boss = CampaignBoss(
                x, y, left, right, boss_frames, boss_name, boss_health,
                sprite_scale=boss_scale, hitbox_size=boss_hitbox,
            )
        self.turrets = [
            Turret(center_x, base_y, self.assets.turret_idle_frames, self.assets.turret_aim_frames)
            for center_x, base_y in self.world.turret_spawns
        ]
        self.enemies.extend(self.turrets)
        self.turret_bolts = []
        self.player_arrows = []
        self.choco_meteors = []
        self.choco_puddles = []
        self.active_abilities = []
        self.choco_ultimate_timer = 0.0
        self.choco_ultimate_next = 0.0
        self.choco_meteors_left = 0
        self._was_dashing = False
        self._was_on_ground = False

        # Mode rules travel with the run across level resets.
        self._configure_player_for_mode()
        self._scale_enemies_for_mode()

        # Ground hand-authored enemies only after the World and enemy lists exist.
        self._ground_enemies_on_platforms()

        self.camera.offset.x = 0
        pygame.display.set_caption(f"Pixel Knight — {self.world.name.title()}")

    def _ground_enemies_on_platforms(self):
        """Place ground enemies on the nearest platform directly under them.

        Old level spawn coordinates were mostly hand-authored, so this keeps
        every enemy's feet locked to floating/raised platforms without moving
        enemies that are intentionally below or flying.
        """
        platforms = self.world.platforms

        for enemy in self.enemies:
            if isinstance(enemy, (Bat, StormOrb, FireWisp, Turret)):
                continue
            best = None
            best_gap = 10**9
            for platform in platforms:
                if enemy.rect.right <= platform.left or enemy.rect.left >= platform.right:
                    continue
                gap = platform.top - enemy.rect.bottom
                if -4 <= gap <= 90 and gap < best_gap:
                    best = platform
                    best_gap = gap
            if best is not None:
                enemy.rect.bottom = best.top
                if hasattr(enemy, "home_y"):
                    enemy.home_y = float(best.top)
                if hasattr(enemy, "ground_y"):
                    enemy.ground_y = best.top

    async def run_async(self):
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000.0, 1 / 30)
            self.handle_events()
            self.update(dt)
            self.draw()
            await asyncio.sleep(0)

        # Close online threads and sockets even when the window is closed while
        # hosting or playing a network match.
        try:
            if self.online_lobby:
                self.online_lobby.close()
            if self.online_client:
                self.online_client.close()
            if self.online_server:
                self.online_server.stop()
        except (AttributeError, OSError):
            pass
        pygame.quit()

    def run(self):
        asyncio.run(self.run_async())

    def handle_events(self):
        self.jump_pressed = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            elif getattr(pygame, "WINDOWFOCUSLOST", None) is not None and event.type == pygame.WINDOWFOCUSLOST:
                if self.is_mobile_runtime and self.state == "playing":
                    self.state = "paused"

            elif event.type == pygame.FINGERDOWN:
                pointer_id = ("finger", event.finger_id)
                self._handle_pointer_down(pointer_id, self._finger_position(event))

            elif event.type == pygame.FINGERMOTION:
                pointer_id = ("finger", event.finger_id)
                position = self._finger_position(event)
                self._handle_pointer_move(pointer_id, position)
                self._handle_menu_action(self.menu.handle_pointer_motion(position))

            elif event.type == pygame.FINGERUP:
                self.mobile_pointers.pop(("finger", event.finger_id), None)
                self.menu.end_pointer()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F11 and not self.is_mobile_runtime:
                    self.menu.fullscreen_enabled = not self.menu.fullscreen_enabled
                    self._toggle_fullscreen()
                if self.state == "online_lobby" and self.online_lobby:
                    self.online_lobby.handle_event(event)
                elif self.state == "online_duel" and self.online_duel:
                    self.online_duel.handle_event(event)
                elif self.state == "menu":
                    self._handle_menu_action(self.menu.handle_key(event.key))

                elif self.state == "hero_select":
                    action = self.hero_select_screen.handle_key(event.key, self)
                    if action == "back":
                        self.hero_select_from_menu = False
                        if self.hero_select_from_mode_select:
                            self.hero_select_from_mode_select = False
                            self.state = "mode_select"
                        else:
                            self.state = "menu"
                    elif action == "play":
                        self.hero_select_from_menu = False

                elif self.state == "mode_select":
                    self._handle_mode_select_action(self.mode_select_screen.handle_key(event.key))

                elif self.state == "online_unavailable":
                    if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_SPACE):
                        self.state = "menu"

                elif self.state == "playing":
                    if event.key == pygame.K_ESCAPE:
                        self.state = "paused"
                    elif event.key in (
                        pygame.K_SPACE,
                        pygame.K_w,
                        pygame.K_UP,
                    ):
                        self.jump_pressed = True
                    elif event.key == pygame.K_j:
                        self.start_player_attack()
                    elif event.key == pygame.K_q:
                        self.trigger_hero_ability()
                    elif event.key == pygame.K_k and self.player.hero_type == "choco":
                        self.start_player_attack(heavy=True)
                    elif event.key == pygame.K_u and self.player.hero_type == "choco":
                        self.activate_chocolate_rain()
                    elif event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
                        self.player.start_dash()

                elif self.state == "paused":
                    if event.key == pygame.K_ESCAPE:
                        self.state = "playing"
                    elif event.key == pygame.K_RETURN:
                        self._retry_level()
                        self.state = "playing"
                    elif event.key == pygame.K_m:
                        self._return_to_menu("playing")

                elif self.state == "shop":
                    if event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                        self.continue_from_shop()
                    elif event.key == pygame.K_1:
                        self.buy_shop_item("heart")
                    elif event.key == pygame.K_2:
                        self.buy_shop_item("speed")
                    elif event.key == pygame.K_3:
                        self.buy_shop_item("ward")

                elif self.state in ("game_over", "complete"):
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        if self.state == "game_over":
                            if self.mode_timed_out:
                                self.begin_adventure()
                            else:
                                self._retry_level()
                                self.state = "playing"
                        else:
                            self._return_to_menu()
                    elif event.key == pygame.K_ESCAPE:
                        self._return_to_menu("game_over" if self.state == "game_over" else None)

            elif event.type == pygame.TEXTINPUT:
                if self.state == "online_lobby" and self.online_lobby:
                    self.online_lobby.handle_event(event)

            elif event.type == pygame.MOUSEBUTTONDOWN:
                # SDL can emit mouse events for the same touch already handled above.
                if getattr(event, "touch", False):
                    continue
                if self.state == "online_lobby" and self.online_lobby:
                    self.online_lobby.handle_event(event)
                elif self.state == "online_duel" and self.online_duel:
                    self.online_duel.handle_event(event)
                elif self.mobile_controls_enabled and self.state == "playing" and event.button == 1:
                    self._handle_pointer_down(("mouse", 1), event.pos)
                else:
                    self._handle_mouse_button_down(event.pos, event.button)

            elif event.type == pygame.MOUSEMOTION:
                if ("mouse", 1) in self.mobile_pointers:
                    self._handle_pointer_move(("mouse", 1), event.pos)
                if self.state == "menu":
                    self._handle_menu_action(self.menu.handle_pointer_motion(event.pos))

            elif event.type == pygame.MOUSEBUTTONUP:
                self.mobile_pointers.pop(("mouse", event.button), None)
                self.menu.end_pointer()
                if self.state == "online_duel" and self.online_duel:
                    self.online_duel.handle_event(event)

    def update(self, dt):
        # Menu animation has its own state and never advances the world simulation.
        if self.state in ("menu", "online_unavailable"):
            self.menu.update(dt)
            self.effects.update(dt)
            return
        if self.state == "mode_select":
            self.mode_select_screen.update(dt)
            self.effects.update(dt)
            return
        if self.state == "online_lobby":
            if self.online_lobby:
                self.online_lobby.update(dt)
            return
        if self.state == "online_duel":
            if self.online_duel:
                self.online_duel.update(dt)
            return

        # Confirmation freezes the current level without resetting any state.
        if self.state == "confirm_leave":
            self.effects.update(dt)
            return
        if self.state == "shop":
            self.shop.message_timer = max(0.0, self.shop.message_timer - dt)
            return
        if self.state == "hero_select":
            self.hero_select_screen.update(dt)
            return
        if self.state != "playing":
            self.effects.update(dt)
            return

        self.mode_elapsed += dt
        if self.mode_time_remaining is not None:
            self.mode_time_remaining = max(0.0, self.mode_time_remaining - dt)
            if self.mode_time_remaining <= 0.0:
                self.mode_timed_out = True
                self.state = "game_over"
                self.effects.camera_shake(7, 0.22)
                return

        if self.effects.hitstop > 0:
            self.effects.update(dt)
            self.effects.ambient(dt, self.camera.offset.x, getattr(self.world.layout, "THEME", "valley"))
            return

        self.level_banner_timer = max(0.0, self.level_banner_timer - dt)
        self.world.update(dt, self.player)
        for rock in self.falling_rocks:
            rock.update(dt)
        self.effects.update(dt)
        self.effects.ambient(dt, self.camera.offset.x, getattr(self.world.layout, "THEME", "valley"))

        keys = pygame.key.get_pressed()
        was_dashing = self.player.dashing
        was_on_ground = self.player.on_ground
        fall_speed = self.player.velocity.y
        self.player.update(
            dt,
            keys,
            self.world.platforms,
            self.jump_pressed,
            virtual_controls=set(self.mobile_pointers.values()),
        )
        if self.boss and self.world.boss_arena:
            arena_left, arena_right = self.world.boss_arena
            if (self.boss.alive and not self.boss_arena_active
                    and self.player.rect.left >= arena_left + 24):
                self.boss_arena_active = True
                self.boss.encounter_active = True
                self.boss_checkpoint = {
                    "level": self.level_number,
                    "coins": self.player.coins,
                    "health": self.player.health,
                    "speed": self.speed_bonus,
                    "shields": self.shield_charges,
                }
                self.level_start_coins = self.player.coins
                if self.boss not in self.enemies:
                    self.enemies.append(self.boss)
                self.world.boss_arena_active = True
                self.effects.camera_shake(4, 0.18)
                self.effects.impact_ring(arena_left + 12, GROUND_Y - 66,
                                         (95, 206, 242) if self.boss.name == "FROST GUARDIAN" else (235, 79, 123),
                                         heavy=True)
                self.effects.floating_text(self.player.rect.centerx,
                                           self.player.rect.top - 18,
                                           "CHECKPOINT SET", (178, 233, 255))
            if self.boss_arena_active:
                if self.boss.alive:
                    if self.player.rect.left < arena_left + 24:
                        self.player.rect.left = arena_left + 24
                        self.player.velocity.x = max(0, self.player.velocity.x)
                    if self.player.rect.right > arena_right - 24:
                        self.player.rect.right = arena_right - 24
                        self.player.velocity.x = min(0, self.player.velocity.x)
                else:
                    self.boss_arena_active = False
                    self.world.boss_arena_active = False
        self._update_chocolate_abilities(dt)
        self._update_active_abilities(dt)

        if self.player.double_jump_anim_timer > 0 and self.player.double_jump_trail_timer <= 0:
            self.effects.add_afterimage(self.player.image, self.player.rect)
            self.player.double_jump_trail_timer = 0.055
        self.player.double_jump_trail_timer = max(0.0, self.player.double_jump_trail_timer - dt)

        if self.player.dashing:
            ghost = self.player.image
            if self.player.facing < 0:
                ghost = pygame.transform.flip(ghost, True, False)
            self.effects.add_afterimage(ghost, self.player.rect)

        if self.player.dashing and not was_dashing:
            self.effects.dash_burst(
                self.player.rect.centerx - self.player.facing * 12,
                self.player.rect.centery,
                self.player.facing,
            )
        if self.player.on_ground and not was_on_ground:
            self.effects.landing(
                self.player.rect.centerx,
                self.player.rect.bottom,
                heavy=fall_speed > 520,
            )

        if self.player.did_jump:
            self.assets.play("jump")
            if self.player.did_double_jump:
                self.effects.double_jump_burst(self.player.rect.centerx, self.player.rect.centery)
            else:
                self.effects.jump_puff(self.player.rect.centerx, self.player.rect.bottom)
        if self.player.attacking:
            if self.player.hero_type == "choco":
                if self.player.attack_active and not self.player.attack_shot_fired:
                    self.player_arrows.append(
                        ChocolateBolt(
                            self.player.rect.centerx + self.player.facing * 24,
                            self.player.rect.centery - 3,
                            self.player.facing,
                            heavy=self.player.attack_heavy,
                        )
                    )
                    self.player.attack_shot_fired = True
                self.player.slash_effect_spawned = True
            elif getattr(getattr(self.player, "hero_obj", None), "base_hero", "knight") == "archer" or self.player.hero_type == "archer":
                if self.player.attack_active and not self.player.attack_shot_fired:
                    arrow_y = self.player.rect.centery - 4
                    offsets = (-10, 0, 10) if self.player.combo_step == 2 else (0,)
                    for offset in offsets:
                        self.player_arrows.append(
                            Arrow(
                                self.player.rect.centerx + self.player.facing * 22,
                                arrow_y + offset,
                                self.player.facing,
                                color=getattr(getattr(self.player, "hero_obj", None), "color", (151, 255, 90)),
                            )
                        )
                    self.player.attack_shot_fired = True
                self.player.slash_effect_spawned = True
            # Spawn one slash trail per sword attack, early enough to lead the hitbox.
            elif not getattr(self.player, "slash_effect_spawned", False):
                self.effects.sword_slash(
                    self.player.rect.centerx + self.player.facing * 12,
                    self.player.rect.centery,
                    self.player.facing,
                    self.player.combo_step,
                )
                self.player.slash_effect_spawned = True
        else:
            self.player.slash_effect_spawned = False

        # Flame dispensers are active hazards during gameplay.
        # They are disabled by World on the peaceful/cold levels.
        for dispenser in self.world.flame_dispensers:
            if (
                dispenser.damages(self.player.rect, beam_top=0)
                and not self.explore_mode
                and not self.player.invulnerable
            ):
                defeated = self.damage_player(dispenser.x)
                self.effects.flame_burst(dispenser.x, self.player.rect.top)
                if defeated:
                    self.state = "game_over"
                    return

        for rock in self.falling_rocks:
            if (
                rock.active
                and not rock.damage_done
                and not self.explore_mode
                and rock.damage_rect().colliderect(self.player.rect)
            ):
                rock.damage_done = True
                defeated = self.damage_player(rock.rect.centerx)
                if defeated:
                    self.state = "game_over"
                    return

        for enemy in self.enemies:
            enemy.choco_slow_timer = max(0.0, getattr(enemy, "choco_slow_timer", 0.0) - dt)
            enemy_dt = dt * (0.56 if enemy.choco_slow_timer > 0 else 1.0)
            enemy_dt *= float(self.mode_config.get("enemy_speed", 1.0))
            if self.mode_config.get("endless"):
                enemy_dt *= 1.0 + min(1.0, self.survival_cycles * 0.05)
            if isinstance(enemy, Turret):
                shot = enemy.update_ai(enemy_dt, self.player, self.world.platforms)
                if shot is not None:
                    self.turret_bolts.append(shot)
                    self.assets.play("tap")
            elif hasattr(enemy, "update_ai"):
                enemy.update_ai(enemy_dt, self.player)
            else:
                enemy.update(enemy_dt)

            if not enemy.alive or getattr(enemy, "dying", False):
                continue

            if not enemy.rect.colliderect(self.player.rect):
                continue

            # Explore Mode keeps contact harmless while leaving enemies visible.
            if self.explore_mode:
                continue

            # Stomp: landing on an enemy's head damages it and bounces the knight.
            if (
                self.player.velocity.y > 120
                and self.player.rect.bottom - enemy.rect.top < 22
                and not isinstance(enemy, (Bat, StormOrb, FireWisp, Turret))
            ):
                stomp_defeated = enemy.take_hit()
                self.player.velocity.y = -430
                self.player.rect.bottom = enemy.rect.top
                self.player.invulnerable = max(self.player.invulnerable, 0.25)
                self.effects.hit_spark(enemy.rect.centerx, enemy.rect.top, self.player.facing, heavy=False)
                if stomp_defeated:
                    self.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    self._award_coin()
                    self.assets.play("coin")
                else:
                    self.assets.play("tap")
                continue

            # Already recovering from a hit: don't re-trigger hurt effects/sound every frame.
            if self.player.invulnerable > 0:
                continue

            defeated = self.damage_player(enemy.rect.centerx)

            if self.player.last_hit_kind == "parry":
                parried_enemy_defeated = enemy.take_hit()
                if not isinstance(enemy, Turret):
                    enemy.rect.x += self.player.facing * 28
                    if hasattr(enemy, "direction"):
                        enemy.direction = self.player.facing
                self.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, self.player.facing, heavy=True)
                if parried_enemy_defeated:
                    self.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    self._award_coin()
                    self.assets.play("coin")

            if defeated:
                self.state = "game_over"
                return

        if self.boss and not self.boss.alive and not self.boss_drop_spawned:
            self.boss_drop = pygame.Rect(self.boss.rect.centerx - 14, GROUND_Y - 34, 28, 28)
            self.boss_drop_spawned = True
            self.effects.floating_text(self.boss.rect.centerx, GROUND_Y - 72,
                                       "BOSS RELIC", (255, 221, 123))
            self.effects.impact_ring(self.boss.rect.centerx, GROUND_Y - 18,
                                     (255, 185, 83), heavy=True)
        if self.boss_drop and self.boss_drop.colliderect(self.player.rect):
            self.boss_drop = None
            self.boss_shards += 1
            self._save_progress()
            self.effects.floating_text(self.player.rect.centerx,
                                       self.player.rect.top - 14,
                                       "RELIC +1", (255, 221, 123))
            self.effects.impact_ring(self.player.rect.centerx, self.player.rect.centery,
                                     (255, 185, 83), heavy=True)
            self.assets.play("coin")

        for arrow in self.player_arrows:
            arrow.update(dt)
            if any(arrow.rect.colliderect(platform) for platform in self.world.platforms):
                arrow.alive = False
                continue
            if isinstance(arrow, ChocolateBolt):
                target = next((enemy for enemy in self.enemies
                               if enemy.alive and not getattr(enemy, "dying", False)
                               and arrow.rect.colliderect(enemy.rect)), None)
                if target is not None:
                    arrow.alive = False
                    cx, cy = target.rect.center
                    victims = []
                    for enemy in self.enemies:
                        if not enemy.alive or getattr(enemy, "dying", False):
                            continue
                        dx, dy = enemy.rect.centerx - cx, enemy.rect.centery - cy
                        if enemy is target or (arrow.heavy and dx * dx + dy * dy <= arrow.radius * arrow.radius):
                            victims.append(enemy)
                    for enemy in victims:
                        defeated = enemy.take_hit()
                        if not isinstance(enemy, Turret):
                            enemy.rect.x += arrow.direction * (30 if arrow.heavy else 18)
                            if hasattr(enemy, "left"):
                                enemy.rect.x = max(enemy.left, min(enemy.rect.x, enemy.right - enemy.rect.width))
                        if arrow.heavy:
                            enemy.choco_slow_timer = max(getattr(enemy, "choco_slow_timer", 0.0), 0.65)
                        self.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, arrow.direction, heavy=arrow.heavy)
                        self.effects.impact_ring(enemy.rect.centerx, enemy.rect.centery, (255, 116, 39), heavy=arrow.heavy)
                        self.effects.floating_text(enemy.rect.centerx, enemy.rect.top - 8,
                                                   "SPLASH" if arrow.heavy else "CHOCO",
                                                   (255, 183, 96))
                        if defeated:
                            self.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                            self._award_coin()
                            self.assets.play("coin")
                    self.player.ultimate_charge = min(100.0, self.player.ultimate_charge + (25 if arrow.heavy else 14))
                    if arrow.heavy:
                        self.effects.camera_shake(2, 0.08)
                continue
            for enemy in self.enemies:
                if not enemy.alive or getattr(enemy, "dying", False) or not arrow.rect.colliderect(enemy.rect):
                    continue
                arrow.alive = False
                defeated = enemy.take_hit()
                if not isinstance(enemy, Turret):
                    enemy.rect.x += arrow.direction * 22
                    if hasattr(enemy, "left"):
                        enemy.rect.x = max(enemy.left, min(enemy.rect.x, enemy.right - enemy.rect.width))
                self.effects.hit_spark(enemy.rect.centerx, enemy.rect.centery, arrow.direction, heavy=False)
                self.effects.floating_text(enemy.rect.centerx, enemy.rect.top - 8, "HIT", (167, 255, 115))
                if defeated:
                    self.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                    self._award_coin()
                    self.assets.play("coin")
                else:
                    self.assets.play("tap")
                break
        self.player_arrows = [arrow for arrow in self.player_arrows if arrow.alive]

        # Sword combat: only the active frames of the swing can damage an enemy,
        # and each swing can hit each enemy once.
        base_h = getattr(getattr(self.player, "hero_obj", None), "base_hero", "knight")
        if self.player.attack_active and base_h not in ("archer", "choco") and self.player.hero_type not in ("archer", "choco"):
            blade_box = self.player.attack_rect()
            for enemy in self.enemies:
                if not enemy.alive or getattr(enemy, "dying", False) or id(enemy) in self.player.attack_hit_targets:
                    continue
                if blade_box.colliderect(enemy.rect):
                    defeated = enemy.take_hit()
                    self.player.attack_hit_targets.add(id(enemy))
                    # Small knockback makes hits readable without changing enemy AI.
                    if not isinstance(enemy, Turret):
                        push = self.player.facing * 24
                        enemy.rect.x += push
                        if hasattr(enemy, "left"):
                            enemy.rect.x = max(enemy.left, min(enemy.rect.x, enemy.right - enemy.rect.width))
                    heavy_hit = self.player.combo_step >= 2
                    self.effects.hit_spark(
                        enemy.rect.centerx,
                        enemy.rect.centery,
                        self.player.facing,
                        heavy=heavy_hit,
                    )
                    self.effects.floating_text(
                        enemy.rect.centerx,
                        enemy.rect.top - 8,
                        "CRIT" if heavy_hit else "HIT",
                        (255, 210, 90) if heavy_hit else (230, 245, 255),
                    )
                    if defeated:
                        self.effects.enemy_defeat(enemy.rect.centerx, enemy.rect.centery)
                        self._award_coin()
                        self.assets.play("coin")
                    else:
                        self.assets.play("tap")

        for bolt in self.turret_bolts:
            was_alive = bolt.alive
            bolt.update(dt, self.world.platforms)
            if was_alive and not bolt.alive:
                self.effects.impact_ring(bolt.rect.centerx, bolt.rect.centery, (100, 188, 219))
                self.effects.hit_spark(bolt.rect.centerx, bolt.rect.centery, 1, heavy=False)
                continue
            if bolt.alive and bolt.rect.colliderect(self.player.rect) and not self.explore_mode:
                bolt.alive = False
                self.effects.hit_spark(bolt.rect.centerx, bolt.rect.centery, -1, heavy=False)
                if self.player.invulnerable <= 0:
                    defeated = self.damage_player(bolt.rect.centerx)
                    self.player.velocity.x += 190 if bolt.rect.centerx < self.player.rect.centerx else -190
                    if defeated:
                        self.state = "game_over"
                        return
        self.turret_bolts = [bolt for bolt in self.turret_bolts if bolt.alive]

        for hazard in self.world.hazards:
            if not hazard.colliderect(self.player.rect):
                continue
            if self.explore_mode:
                continue

            defeated = self.damage_player(hazard.centerx)
            if defeated:
                self.state = "game_over"
                return

        for coin in self.world.coins[:]:
            if coin.colliderect(self.player.rect):
                self.world.coins.remove(coin)
                self._award_coin()
                self.effects.coin_burst(coin.centerx, coin.centery)
                self.assets.play("coin")

        for stash in getattr(self.world, "candy_stashes", [])[:]:
            if stash.colliderect(self.player.rect):
                self.world.candy_stashes.remove(stash)
                self._award_coin(5)
                self.effects.impact_ring(stash.centerx, stash.centery,
                                         (255, 157, 73), heavy=True)
                self.effects.floating_text(stash.centerx, stash.top - 14,
                                           "+5 CANDY GOLD", (255, 195, 117))
                self.assets.play("coin")

        # Falling is a reset, not an instant-death punishment. This keeps the
        # challenge focused on combat and route choices instead of repeated
        # one-mistake deaths.
        if self.player.rect.top > HEIGHT + 220:
            self.player.rect.topleft = self.player.spawn
            self.player.velocity.update(0, 0)
            self.player.invulnerable = 1.2
            self.player.on_ground = False
            self.player.standing_platform = None

        boss_alive = any(getattr(enemy, "is_boss", False) and enemy.alive
                         for enemy in self.enemies)
        if self.player.rect.colliderect(self.world.goal) and not boss_alive:
            if self.mode_config.get("id") == "boss_rush" and self.level_number == 11:
                self.next_level_number = 12
            else:
                self.next_level_number = next_level(self.level_number)
            if self.next_level_number is None and self.mode_config.get("endless"):
                self.survival_cycles += 1
                self.next_level_number = 1
                self.shop.show_message(
                    f"Cycle {self.survival_cycles + 1} begins! Enemies grow stronger."
                )
                self.state = "shop"
                self.assets.play("tap")
            elif self.next_level_number is not None:
                if self.mode_config.get("id") == "boss_rush":
                    self.shop.show_message("One boss down. Prepare for the final boss!")
                else:
                    self.shop.show_message("Choose one or more upgrades, or continue onward.")
                self.state = "shop"
                self.assets.play("tap")
            else:
                self.state = "complete"
                self.effects.level_complete(self.player.rect.centerx, self.player.rect.centery)
                self.effects.camera_shake(10, 0.3)

        self.camera.update(self.player.rect, dt)

    def draw(self):
        if self.state in ("menu", "online_unavailable"):
            self.menu.draw(self.screen, self.world)
            if self.state == "online_unavailable":
                self.draw_overlay("BROWSER DUEL", "Open Online Duel from the Gaming Portal. Press Enter.")
        elif self.state == "mode_select":
            self.mode_select_screen.draw(self.screen, self.world)
        elif self.state == "online_lobby" and self.online_lobby:
            self.online_lobby.draw(self.screen)
        elif self.state == "online_duel" and self.online_duel:
            self.online_duel.draw(self.screen)
        elif self.state == "hero_select":
            self.hero_select_screen.draw(self.screen, self)
        elif self.state == "shop":
            self.world.draw_background(self.screen, self.camera.offset.x)
            self.world.draw(self.screen, self.camera)
            self.draw_falling_rocks()
            self.draw_flame_dispensers()
            self.draw_enemies()
            self.draw_boss_drop()
            self.draw_active_abilities()
            self.effects.draw(self.screen, self.camera)
            self.draw_player()
            self.draw_hud()
            self.shop.draw(self.screen, self)
        else:
            self.world.draw_background(
                self.screen,
                self.camera.offset.x,
            )
            self.world.draw(self.screen, self.camera)
            self.draw_falling_rocks()
            self.draw_flame_dispensers()
            self.draw_enemies()
            self.draw_boss_drop()
            self.draw_chocolate_abilities()
            self.draw_active_abilities()
            self.draw_turret_bolts()
            for arrow in self.player_arrows:
                arrow.draw(self.screen, self.camera)
            self.effects.draw(self.screen, self.camera)
            self.draw_player()
            self.draw_hud()

            if self.state in ("playing", "confirm_leave"):
                self.draw_leave_button()
            if self.state == "playing" and self.mobile_controls_enabled:
                self.mobile_controls.draw(
                    self.screen,
                    self.micro_font,
                    set(self.mobile_pointers.values()),
                    roll_ready=self.player.on_ground,
                )

            if self.state in ("paused", "game_over", "complete"):
                titles = {
                    "paused": "PAUSED",
                    "game_over": "TIME UP!" if self.mode_timed_out else "GAME OVER",
                    "complete": "GAME COMPLETE!",
                }
                hints = {
                    "paused": "Tap anywhere to resume" if self.mobile_controls_enabled else "Esc resume   Enter restart   M menu",
                    "game_over": "Tap to try again" if self.mobile_controls_enabled else "Enter try again   Esc menu",
                    "complete": "Tap for title" if self.mobile_controls_enabled else "Enter return to title   Esc menu",
                }
                self.draw_overlay(
                    titles[self.state],
                    hints[self.state],
                )

            if self.level_banner_timer > 0:
                self.draw_level_banner()

            if self.state == "confirm_leave":
                self.draw_leave_confirmation()

        # Impact flash, critical-health pulse, and camera shake are visual only.
        self.effects.low_health = (
            self.state in ("playing", "paused", "shop") and self.player.health == 1
        )
        self.effects.draw_screen_fx(self.screen, WIDTH, HEIGHT)

        if self.effects.shake > 0:
            frame = self.screen.copy()
            strength = max(0, int(self.effects.shake_strength * min(1.0, self.effects.shake / 0.14)))
            dx = random.randint(-strength, strength) if strength else 0
            dy = random.randint(-strength, strength) if strength else 0
            self.screen.fill((8, 12, 18))
            self.screen.blit(frame, (dx, dy))

        pygame.display.flip()



    def draw_leave_button(self):
        """Draw the in-level button used to safely return to the main menu."""
        rect = self.leave_rect
        shadow = rect.move(3, 3)
        pygame.draw.rect(self.screen, (8, 12, 16), shadow)
        pygame.draw.rect(self.screen, (62, 78, 82), rect)
        pygame.draw.rect(self.screen, (180, 155, 92), rect, 2)
        label = self.small_font.render("MENU", True, WHITE) if self.mobile_controls_enabled else self.font.render("LEAVE", True, WHITE)
        self.screen.blit(label, label.get_rect(center=rect.center))

    def draw_leave_confirmation(self):
        """Pause the level visually and ask for confirmation before leaving."""
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((4, 7, 12, 175))
        self.screen.blit(veil, (0, 0))

        panel = pygame.Rect(WIDTH // 2 - 250, HEIGHT // 2 - 115, 500, 235)
        pygame.draw.rect(self.screen, (8, 13, 18), panel.move(6, 6))
        pygame.draw.rect(self.screen, (48, 61, 65), panel)
        pygame.draw.rect(self.screen, (190, 157, 91), panel, 3)
        pygame.draw.rect(self.screen, (20, 29, 31), panel.inflate(-14, -14), 2)

        title = self.font.render("RETURN TO MENU?", True, GOLD)
        self.screen.blit(title, title.get_rect(center=(panel.centerx, panel.top + 48)))
        question = self.small_font.render("Do you want to return?", True, WHITE)
        self.screen.blit(question, question.get_rect(center=(panel.centerx, panel.top + 88)))

        for rect, text in ((self.leave_yes_rect, "YES"), (self.leave_no_rect, "NO")):
            pygame.draw.rect(self.screen, (25, 37, 40), rect.move(3, 3))
            pygame.draw.rect(self.screen, (65, 82, 84), rect)
            pygame.draw.rect(self.screen, (190, 157, 91), rect, 2)
            label = self.font.render(text, True, WHITE)
            self.screen.blit(label, label.get_rect(center=rect.center))

        hint = self.micro_font.render("YES: return to title   NO: continue level", True, (190, 204, 159))
        self.screen.blit(hint, hint.get_rect(center=(panel.centerx, panel.bottom - 22)))

    def buy_shop_item(self, item):
        prices = {"heart": 6, "speed": 10, "ward": 8}
        price = prices[item]
        pay_with_relic = item == "ward" and self.boss_shards > 0
        if self.player.coins < price and not pay_with_relic:
            self.shop.show_message("You need more coins for that item.")
            return
        if item == "heart" and self.player.health >= self.max_health:
            self.shop.show_message("Your health is already full.")
            return
        if item == "speed" and self.speed_bonus >= 54:
            self.shop.show_message("The swift rune is fully upgraded.")
            return
        if item == "ward" and self.shield_charges >= 3:
            self.shop.show_message("You cannot carry more ward charms.")
            return

        if pay_with_relic:
            self.boss_shards -= 1
            self._save_progress()
        else:
            self._spend_coins(price)
        if item == "heart":
            self.player.health += 1
            self.shop.show_message("Heart Tonic bought: restored one heart!")
        elif item == "speed":
            self.speed_bonus += 18
            self.player.speed_bonus = self.speed_bonus
            self.shop.show_message("Swift Rune bought: you run faster!")
        else:
            self.shield_charges += 1
            self.player.shield_charges = self.shield_charges
            self.shop.show_message(
                "Ward Charm bought with a boss relic!" if pay_with_relic
                else "Ward Charm bought: one hit will be blocked."
            )
        self.assets.play("coin")

    def continue_from_shop(self):
        self.reset_level(
            self.next_level_number,
            carried_coins=self.player.coins,
            carried_health=self.player.health,
            carried_speed_bonus=self.speed_bonus,
            carried_shields=self.shield_charges,
        )
        self.level_banner_timer = 2.4
        self.state = "playing"

    def damage_player(self, source_x):
        """Apply one hit and play feedback that matches what actually happened."""
        previous_health = self.player.health
        previous_shields = self.player.shield_charges
        defeated = self.player.hit(source_x)
        self.shield_charges = self.player.shield_charges

        if self.player.last_hit_kind == "parry":
            self.effects.perfect_parry(self.player.rect.centerx, self.player.rect.centery)
            self.assets.play("tap")
        elif self.player.last_hit_blocked:
            self.effects.shield_block(self.player.rect.centerx, self.player.rect.centery)
            self.assets.play("tap")
        elif self.player.shield_charges < previous_shields:
            self.effects.ward_block(self.player.rect.centerx, self.player.rect.centery)
            self.assets.play("tap")
        elif self.player.health < previous_health:
            self.effects.player_hurt(self.player.rect.centerx, self.player.rect.centery)
            self.assets.play("hurt")
        return defeated

    def draw_player(self):
        image = self.player.image

        if self.player.facing < 0:
            image = pygame.transform.flip(image, True, False)

        screen_rect = self.camera.apply(self.player.rect)

        # Blink while invulnerable after damage.
        if (
            self.player.invulnerable
            and int(pygame.time.get_ticks() / 90) % 2
        ):
            return

        self.screen.blit(
            image,
            (
                screen_rect.centerx - image.get_width() // 2,
                screen_rect.bottom - image.get_height(),
            ),
        )
        if self.player.double_jump_anim_timer > 0:
            progress = 1.0 - self.player.double_jump_anim_timer / 0.28
            spin = pygame.transform.rotate(image, -360 * max(0.0, min(1.0, progress)))
            self.screen.blit(spin, spin.get_rect(center=screen_rect.center))

        if self.player.attacking:
            glow = pygame.Surface((64, 64), pygame.SRCALPHA)
            palettes = {"knight": ((145, 215, 255), (255, 210, 90), (255, 120, 210)), "ranger": ((184, 130, 255), (220, 190, 255), (130, 220, 255)), "mage": ((255, 112, 48), (255, 190, 64), (255, 70, 35)), "choco": ((255, 143, 55), (255, 199, 89), (191, 74, 35))}
            color = palettes.get(self.player.hero_type, palettes["knight"])[min(2, self.player.combo_step)]
            pygame.draw.circle(glow, (*color, 55), (32, 32), 28)
            self.screen.blit(glow, (screen_rect.centerx - 32, screen_rect.centery - 32))


    def draw_falling_rocks(self):
        for rock in self.falling_rocks:
            rock.draw(self.screen, self.camera)

    def draw_flame_dispensers(self):
        beam_top = max(0, getattr(self.world.layout, "BEAM_TOP", 0))
        for dispenser in self.world.flame_dispensers:
            dispenser.draw(self.screen, self.camera, beam_top=beam_top)

    def draw_enemies(self):
        for enemy in self.enemies:
            if not enemy.alive:
                continue

            if isinstance(enemy, Turret):
                enemy.draw(self.screen, self.camera)
                if enemy.max_health > 1 and not enemy.dying:
                    sprite_rect = enemy.visual_rect(self.camera)
                    bar = pygame.Rect(sprite_rect.centerx - 22, sprite_rect.top - 9, 44, 6)
                    pygame.draw.rect(self.screen, (27, 21, 22), bar)
                    pygame.draw.rect(self.screen, (183, 138, 78), bar, 1)
                    fill = bar.inflate(-4, -3)
                    fill.width = round(fill.width * max(0, enemy.health) / enemy.max_health)
                    if fill.width:
                        pygame.draw.rect(self.screen, (67, 185, 211), fill)
                continue

            image = enemy.image

            if enemy.direction < 0:
                image = pygame.transform.flip(image, True, False)

            screen_rect = self.camera.apply(enemy.rect)
            self.screen.blit(
                image,
                (
                    screen_rect.centerx - image.get_width() // 2,
                    screen_rect.bottom - image.get_height(),
                ),
            )
            if getattr(enemy, "is_boss", False):
                if not self.boss_arena_active:
                    continue
                bar = pygame.Rect(WIDTH // 2 - 190, 32, 380, 17)
                pygame.draw.rect(self.screen, (24, 16, 29), bar, border_radius=4)
                pygame.draw.rect(self.screen, (165, 185, 205), bar, 2, border_radius=4)
                fill = bar.inflate(-6, -6)
                fill.width = round(fill.width * max(0, enemy.health) / enemy.max_health)
                if fill.width:
                    if enemy.phase >= 2:
                        tint = (255, 143, 72)
                    else:
                        tint = (96, 205, 246) if enemy.name == "FROST GUARDIAN" else (189, 66, 105)
                    pygame.draw.rect(self.screen, tint, fill, border_radius=3)
                title_text = enemy.name + ("  •  ENRAGED" if enemy.phase >= 2 else "")
                title = self.small_font.render(title_text, True,
                                               (255, 176, 112) if enemy.phase >= 2 else (247, 236, 219))
                self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 8))
                continue
            if enemy.max_health > 1:
                bar = pygame.Rect(screen_rect.centerx - 22, screen_rect.top - 10, 44, 8)
                pygame.draw.rect(self.screen, (30, 24, 23), bar)
                pygame.draw.rect(self.screen, (177, 132, 72), bar, 1)
                fill = bar.copy()
                fill.width = round((bar.width - 4) * max(0, enemy.health) / enemy.max_health)
                fill.inflate_ip(-4, -4)
                if fill.width:
                    pygame.draw.rect(self.screen, (202, 72, 65), fill)

    def draw_turret_bolts(self):
        for bolt in self.turret_bolts:
            bolt.draw(self.screen, self.camera)

    def draw_boss_drop(self):
        if not self.boss_drop:
            return
        rect = self.camera.apply(self.boss_drop)
        bob = round(math.sin(pygame.time.get_ticks() * 0.006) * 3)
        cx, cy = rect.centerx, rect.centery + bob
        pygame.draw.circle(self.screen, (255, 181, 70), (cx, cy), 22, 1)
        pygame.draw.polygon(self.screen, (255, 227, 137),
                            ((cx, cy - 15), (cx + 12, cy), (cx, cy + 15), (cx - 12, cy)))
        pygame.draw.polygon(self.screen, (179, 79, 57),
                            ((cx, cy - 9), (cx + 6, cy), (cx, cy + 9), (cx - 6, cy)))
        pygame.draw.circle(self.screen, (255, 249, 207), (cx - 3, cy - 4), 2)

    def draw_hud(self):
        """Compact pixel HUD with real cooldown bars and safe text bounds."""
        # Main status panel
        panel = pygame.Rect(16, 14, 350, 96)
        self.draw_ancient_panel(panel)

        # Hearts
        for index in range(MAX_HEALTH):
            self.draw_pixel_heart(
                panel.left + 16 + index * 27,
                panel.top + 13,
                index < self.player.health,
            )

        hero_label = self.small_font.render(self.player.hero_name, True, self.player.hero_color)
        self.screen.blit(hero_label, (panel.left + 15, panel.top + 72))

        # Coins
        coin = pygame.transform.scale(self.assets.coin_frames[0], (20, 20))
        self.screen.blit(coin, (panel.left + 15, panel.top + 46))
        coin_text = self.micro_font.render(f"{self.player.coins:03d}", True, GOLD)
        self.screen.blit(coin_text, (panel.left + 39, panel.top + 49))

        # Small upgrade badges; fixed-width slots prevent overflow.
        rune_text = self.micro_font.render(f"RUNE {self.speed_bonus // 18}", True, (202, 185, 143))
        ward_text = self.micro_font.render(f"WARD {self.shield_charges}", True, (202, 185, 143))
        self.screen.blit(rune_text, (panel.left + 92, panel.top + 49))
        self.screen.blit(ward_text, (panel.left + 158, panel.top + 49))

        right_badges = ("EXPLORE · " if self.explore_mode else "") + f"RELIC {self.boss_shards}"
        right_badges_img = self.micro_font.render(right_badges, True,
                                                  (169, 222, 160) if self.explore_mode else (255, 211, 123))
        self.screen.blit(right_badges_img, (panel.left + 230, panel.top + 49))

        # Progress panel with safe clipped level name.
        badge = pygame.Rect(WIDTH - 284, 14, 268, 82)
        self.draw_ancient_panel(badge)
        world_name = self.world.name.removeprefix("THE ")
        level_name = (
            world_name if self.level_number in BOSS_LEVEL_IDS
            else f"LEVEL {self.level_number:02d}  {world_name}"
        )
        while self.micro_font.size(level_name)[0] > badge.width - 24 and len(level_name) > 12:
            level_name = level_name[:-2] + "…"
        level_text = self.micro_font.render(level_name, True, (242, 221, 173))
        self.screen.blit(level_text, (badge.left + 12, badge.top + 12))

        progress = max(0.0, min(1.0, self.player.rect.centerx / self.world.world_width))
        bar = pygame.Rect(badge.left + 12, badge.top + 37, badge.width - 24, 9)
        pygame.draw.rect(self.screen, (18, 22, 24), bar)
        pygame.draw.rect(self.screen, (123, 91, 51), bar, 1)
        fill = bar.copy()
        fill.width = max(0, round((bar.width - 4) * progress))
        fill.inflate_ip(-4, -4)
        if fill.width > 0:
            pygame.draw.rect(self.screen, GOLD, fill)

        mode_name = self.mode_config.get("name", "STORY CAMPAIGN")
        mode_text_value = mode_name
        if self.mode_time_remaining is not None:
            seconds_left = max(0, int(self.mode_time_remaining))
            mode_text_value += f"  •  {seconds_left // 60:02d}:{seconds_left % 60:02d}"
        mode_text_value = self._fit_hud_text(mode_text_value, self.micro_font, WIDTH - 40)
        mode_label = self.micro_font.render(mode_text_value, True, (239, 220, 173))
        mode_badge = pygame.Rect(WIDTH // 2 - max(104, mode_label.get_width() // 2 + 11), 76,
                                 max(208, mode_label.get_width() + 22), 21)
        pygame.draw.rect(self.screen, (9, 14, 23), mode_badge, border_radius=3)
        pygame.draw.rect(self.screen, (91, 104, 119), mode_badge, 1, border_radius=3)
        self.screen.blit(mode_label, mode_label.get_rect(center=mode_badge.center))

        if self.player.hero_type == "choco":
            charge_title = self.micro_font.render("CHOCOLATE RAIN  [U]", True, (255, 188, 101))
            self.screen.blit(charge_title, (panel.left + 182, panel.top + 70))
            charge_bar = pygame.Rect(panel.left + 182, panel.top + 87, 152, 9)
            pygame.draw.rect(self.screen, (30, 18, 18), charge_bar)
            pygame.draw.rect(self.screen, (196, 92, 40), charge_bar, 1)
            charge_fill = charge_bar.inflate(-4, -4)
            charge_fill.width = round(charge_fill.width * max(0.0, min(1.0, self.player.ultimate_charge / 100)))
            if charge_fill.width:
                pygame.draw.rect(self.screen, (255, 126, 41), charge_fill)

        if not self.mobile_controls_enabled:
            # Combat HUD keeps the Knight's four core actions easy to scan.
            cards_y = HEIGHT - 92
            card_width = 120
            card_x = (16, 144, 272, 400, 528)
            self.draw_cooldown_card(
                pygame.Rect(card_x[0], cards_y, card_width, 50),
                "CHOCO SHOT" if self.player.hero_type == "choco" else "SLASH",
                self.player.attack_cooldown,
                max(0.001, ATTACK_COOLDOWN),
                "LMB / J",
                combo=self.player.combo_step + 1,
            )
            self.draw_cooldown_card(
                pygame.Rect(card_x[1], cards_y, card_width, 50),
                "DASH / ROLL",
                self.player.dash_cooldown,
                0.75,
                "SHIFT / S+DIR",
            )
            # Ability Card
            hero_obj = getattr(self.player, "hero_obj", None)
            ab_name = getattr(hero_obj, "ability_name", "ABILITY").split()[0]
            ab_max_cd = getattr(hero_obj, "ability_cooldown", 5.0)
            self.draw_cooldown_card(
                pygame.Rect(card_x[2], cards_y, card_width, 50),
                ab_name,
                self.player.ability_cooldown,
                ab_max_cd,
                "PRESS Q",
            )
            jump_ready = self.player.on_ground or self.player.jumps_used < 2
            self.draw_status_card(
                pygame.Rect(card_x[3], cards_y, card_width, 50),
                "AIR JUMP",
                "READY" if jump_ready else "SPENT",
                "SPACE x2",
                active=jump_ready,
            )
            guard_text = "PARRY!" if self.player.parry_timer > 0 else "GUARD UP" if self.player.blocking else "HOLD E"
            self.draw_status_card(
                pygame.Rect(card_x[4], cards_y, card_width, 50),
                "SHIELD",
                guard_text,
                "FRONT BLOCK",
                active=self.player.blocking or self.player.parry_timer > 0,
            )

        # Combo display appears only while chaining attacks.
        if self.player.combo_window > 0 and self.player.combo_step > 0:
            combo = self.title_font.render(
                f"{self.player.combo_step + 1} HIT!",
                True,
                (239, 219, 145),
            )
            self.screen.blit(combo, (WIDTH - combo.get_width() - 34, HEIGHT - 146))

    def draw_cooldown_card(self, rect, title, remaining, duration, hint, combo=0):
        self.draw_ancient_panel(rect)
        title_room = rect.width - (30 if combo else 18)
        title = self._fit_hud_text(title, self.micro_font, title_room)
        title_image = self.micro_font.render(title, True, (242, 221, 173))
        self.screen.blit(title_image, (rect.left + 9, rect.top + 5))

        ratio = 0.0 if remaining <= 0 else max(0.0, min(1.0, remaining / duration))
        track = pygame.Rect(rect.left + 9, rect.top + 21, rect.width - 18, 8)
        pygame.draw.rect(self.screen, (15, 19, 21), track)
        pygame.draw.rect(self.screen, (123, 91, 51), track, 1)
        fill = track.inflate(-2, -2)
        fill.width = round(fill.width * ratio)
        if fill.width > 0:
            pygame.draw.rect(self.screen, (74, 167, 213) if ratio > 0 else (239, 219, 145), fill)

        if remaining > 0.001:
            value = f"{remaining:.1f}s"
        else:
            value = "READY"
        value_image = self.micro_font.render(value, True, (239, 239, 224))
        self.screen.blit(value_image, (rect.right - value_image.get_width() - 9, rect.top + 34))

        # Keep the key hint and READY/cooldown value in disjoint horizontal
        # slots. On narrow cards, truncate the hint instead of letting labels touch.
        value_x = rect.right - value_image.get_width() - 9
        hint_room = max(8, value_x - (rect.left + 9) - 7)
        hint = self._fit_hud_text(hint, self.micro_font, hint_room)
        hint_image = self.micro_font.render(hint, True, (157, 151, 134))
        self.screen.blit(hint_image, (rect.left + 9, rect.top + 34))

        if combo:
            c = self.micro_font.render(f"x{combo}", True, (255, 211, 83))
            self.screen.blit(c, (rect.right - c.get_width() - 9, rect.top + 5))

    def draw_status_card(self, rect, title, status, hint, active=False):
        self.draw_ancient_panel(rect)
        title_image = self.micro_font.render(title, True, (242, 221, 173))
        self.screen.blit(title_image, (rect.left + 9, rect.top + 5))
        status_color = (122, 218, 190) if active else (173, 151, 125)
        status_image = self.small_font.render(status, True, status_color)
        self.screen.blit(status_image, (rect.left + 9, rect.top + 17))
        hint_image = self.micro_font.render(hint, True, (157, 151, 134))
        self.screen.blit(hint_image, (rect.left + 9, rect.top + 36))

    @staticmethod
    def _fit_hud_text(text, font, max_width):
        if font.size(text)[0] <= max_width:
            return text
        shortened = text
        while shortened and font.size(shortened + "…")[0] > max_width:
            shortened = shortened[:-1]
        return shortened.rstrip() + "…" if shortened else "…"

    def draw_ancient_panel(self, rect):
        """Unified dark-steel UI panel with warm relic trim and a crimson accent."""
        pygame.draw.rect(self.screen, (3, 7, 14), rect.move(4, 5))
        pygame.draw.rect(self.screen, (70, 88, 103), rect)
        pygame.draw.rect(self.screen, (17, 26, 39), rect.inflate(-5, -5))
        pygame.draw.rect(self.screen, (125, 145, 154), rect.inflate(-10, -10), 1)
        pygame.draw.line(self.screen, (192, 151, 96), (rect.left + 8, rect.top + 5),
                         (rect.right - 8, rect.top + 5), 1)
        pygame.draw.rect(self.screen, (157, 51, 66), (rect.left + 7, rect.top + 7, 3, max(4, rect.height - 14)))
        for x, y in ((rect.left + 6, rect.top + 6), (rect.right - 10, rect.top + 6),
                     (rect.left + 6, rect.bottom - 10), (rect.right - 10, rect.bottom - 10)):
            pygame.draw.rect(self.screen, (187, 154, 105), (x, y, 4, 4))

    def draw_level_banner(self):
        alpha = min(235, round(235 * min(1.0, self.level_banner_timer * 2)))
        banner = pygame.Surface((640, 82), pygame.SRCALPHA)
        pygame.draw.rect(banner, (37, 35, 34, alpha), banner.get_rect())
        pygame.draw.rect(banner, (194, 153, 86, alpha), banner.get_rect(), 3)
        pygame.draw.rect(banner, (225, 190, 118, alpha), banner.get_rect().inflate(-10, -10), 1)
        label_text = (
            self.world.name if self.level_number in BOSS_LEVEL_IDS
            else f"LEVEL {self.level_number:02d}  -  {self.world.name}"
        )
        label_text = self._fit_hud_text(label_text, self.font, banner.get_width() - 28)
        label = self.font.render(
            label_text,
            True,
            GOLD,
        )
        banner.blit(
            label,
            (banner.get_width() // 2 - label.get_width() // 2, 17),
        )
        if self.level_number == 4:
            hint = self.small_font.render("TURRETS TRACK YOU  -  KEEP MOVING", True, WHITE)
            banner.blit(hint, (banner.get_width() // 2 - hint.get_width() // 2, 52))
        elif self.level_number == 8:
            hint = self.small_font.render("ARMORED SLIMES TAKE 3 SWORD HITS", True, WHITE)
            banner.blit(hint, (banner.get_width() // 2 - hint.get_width() // 2, 52))
        self.screen.blit(banner, (WIDTH // 2 - banner.get_width() // 2, 106))

    def draw_pixel_heart(self, x, y, full):
        pattern = (
            "01100110",
            "11111111",
            "11111111",
            "01111110",
            "00111100",
            "00011000",
        )
        color = (238, 91, 96) if full else (86, 92, 100)
        pixel = 2
        for row, line in enumerate(pattern):
            for column, value in enumerate(line):
                if value == "1":
                    pygame.draw.rect(
                        self.screen,
                        color,
                        (x + column * pixel, y + row * pixel, pixel, pixel),
                    )

    def draw_overlay(self, title, hint):
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((12, 19, 29, 175))
        self.screen.blit(shade, (0, 0))

        card = pygame.Rect(WIDTH // 2 - 270, 182, 540, 176)
        self.draw_ancient_panel(card)
        pygame.draw.line(self.screen, (157, 51, 66), (card.left + 28, 271), (card.right - 28, 271), 2)

        # Overlay text must stay inside the panel even on narrow/touch layouts.
        title = self._fit_hud_text(title, self.title_font, card.width - 48)
        title_image = self.title_font.render(title, True, GOLD)
        self.screen.blit(
            title_image,
            (WIDTH // 2 - title_image.get_width() // 2, 213),
        )

        hint = self._fit_hud_text(hint, self.font, card.width - 52)
        hint_image = self.font.render(hint, True, WHITE)
        self.screen.blit(
            hint_image,
            (WIDTH // 2 - hint_image.get_width() // 2, 292),
        )
