"""Cinematic pixel-art title menu for Pixel Knight.

The menu deliberately reuses the game's world background, hero animation frames,
font, and Traveler's Shop item catalogue. It is a presentation layer only: it
never resets or updates the active gameplay simulation.
"""

import math
import random

import pygame

from settings import WIDTH, HEIGHT, GOLD, WHITE
from shop import ItemShop


class Menu:
    INTRO_DURATION = 7.8
    BUTTON_W = 232
    BUTTON_H = 44

    def __init__(self, font, title_font, assets=None, micro_font=None,
                 touch_controls_enabled=False, touch_controls_locked=False):
        self.font = font
        self.title_font = title_font
        self.micro_font = micro_font or font
        self.assets = assets

        self.settings_open = False
        self.armory_open = False
        self.explore_mode = False
        self.music_enabled = True
        self.music_volume = 0.22
        self.fullscreen_enabled = False
        self.touch_controls_locked = bool(touch_controls_locked)
        self.touch_controls_enabled = bool(touch_controls_enabled or self.touch_controls_locked)
        self.control_slider_dragging = False
        self.music_volume_dragging = False
        self.continue_available = False
        self.focus_index = 0
        self.settings_focus = 0
        self.selected_hero = "knight"

        # Three mode/hero actions on the left and four utility actions on
        # the right. ONLINE is visible on the title screen without crowding the hero.
        right_x = WIDTH - 28 - self.BUTTON_W
        self.main_buttons = [
            pygame.Rect(28, 190, self.BUTTON_W, self.BUTTON_H),       # New game
            pygame.Rect(28, 250, self.BUTTON_W, self.BUTTON_H),       # Continue
            pygame.Rect(28, 310, self.BUTTON_W, self.BUTTON_H),       # Heroes
            pygame.Rect(right_x, 166, self.BUTTON_W, 40),             # Armory
            pygame.Rect(right_x, 220, self.BUTTON_W, 40),             # Online
            pygame.Rect(right_x, 274, self.BUTTON_W, 40),             # Settings
            pygame.Rect(right_x, 328, self.BUTTON_W, 40),             # Exit
        ]
        self.main_labels = ("PLAY MODES", "CONTINUE", "HEROES", "ARMORY", "ONLINE", "SETTINGS", "EXIT")
        self.button_hover = [0.0] * len(self.main_buttons)
        self.hero_rect = pygame.Rect(354, 148, 252, 300)

        # Options rows.
        self.music_rect = pygame.Rect(330, 166, 300, 36)
        self.volume_rect = pygame.Rect(330, 208, 300, 36)
        self.explore_rect = pygame.Rect(330, 250, 300, 36)
        self.fullscreen_rect = pygame.Rect(330, 292, 300, 36)
        self.controls_rect = pygame.Rect(330, 334, 300, 44)
        self.back_rect = pygame.Rect(358, 392, 244, 38)

        # Armory is a catalogue for the existing in-run upgrades. Buying remains
        # in ItemShop so that currency, health, and run progression stay intact.
        self.armory_panel = pygame.Rect(206, 122, 548, 314)
        self.armory_back_rect = pygame.Rect(358, 374, 244, 40)
        self.armory_cards = [pygame.Rect(234 + i * 166, 217, 150, 130) for i in range(3)]

        self.intro_elapsed = 0.0
        self.intro_active = True
        self.anim_time = 0.0
        self.lightning_flash = 0.0
        self.next_lightning_time = random.uniform(6.0, 10.0)
        self.particles = [
            [
                random.uniform(12, WIDTH - 12),
                random.uniform(24, HEIGHT - 12),
                random.uniform(-8.0, 8.0),
                random.uniform(7.0, 22.0),
                random.choice((1, 1, 2, 2, 3)),
                random.choice(((194, 65, 74), (213, 112, 80), (136, 169, 181), (171, 128, 94))),
            ]
            for _ in range(34)
        ]
        self._last_hero_id = None
        self._hero_idle_frames = []
        self._scene_layer = self._build_pixel_moon_scene()
        self._title_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._buttons_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._hero_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._hero_halo = pygame.Surface((176, 176), pygame.SRCALPHA)
        self._backdrop_veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._backdrop_veil.fill((5, 9, 20, 116))
        self._intro_shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._modal_shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._modal_shade.fill((4, 8, 18, 200))

    @staticmethod
    def _ease(value):
        value = max(0.0, min(1.0, value))
        return value * value * (3.0 - 2.0 * value)

    def update(self, dt):
        """Advance intro and atmosphere using frame-independent time."""
        dt = max(0.0, min(float(dt), 0.05))
        self.anim_time += dt
        mouse = pygame.mouse.get_pos()
        blend = min(1.0, dt * 12.0)
        for index, rect in enumerate(self.main_buttons):
            enabled = index != 1 or self.continue_available
            target = 1.0 if enabled and (index == self.focus_index or rect.collidepoint(mouse)) else 0.0
            self.button_hover[index] += (target - self.button_hover[index]) * blend
        if self.intro_active:
            self.intro_elapsed += dt
            if self.intro_elapsed >= self.INTRO_DURATION:
                self.intro_active = False
        self.lightning_flash = max(0.0, self.lightning_flash - dt)
        if self.anim_time >= self.next_lightning_time:
            self.lightning_flash = 0.12
            self.next_lightning_time = self.anim_time + random.uniform(8.0, 14.0)

        for particle in self.particles:
            particle[0] += particle[2] * dt
            particle[1] -= particle[3] * dt
            if particle[1] < -6:
                particle[0] = random.uniform(8, WIDTH - 8)
                particle[1] = HEIGHT + random.uniform(4, 28)
                particle[2] = random.uniform(-8.0, 8.0)
                particle[3] = random.uniform(7.0, 22.0)
            if particle[0] < -5:
                particle[0] = WIDTH + 4
            elif particle[0] > WIDTH + 5:
                particle[0] = -4

    def skip_intro(self):
        self.intro_elapsed = self.INTRO_DURATION
        self.intro_active = False

    def handle_click(self, position):
        # A click skips the intro and still activates the chosen control.
        if self.intro_active:
            self.skip_intro()

        if self.armory_open:
            if self.armory_back_rect.collidepoint(position) or not self.armory_panel.collidepoint(position):
                self.armory_open = False
            return None

        if self.settings_open:
            if self.music_rect.collidepoint(position):
                self.music_enabled = not self.music_enabled
                self._tap()
                return "music"
            if self.volume_rect.collidepoint(position):
                self.music_volume_dragging = True
                action = self._set_music_volume_from_x(position[0])
                self._tap()
                return action
            if self.explore_rect.collidepoint(position) and not self.continue_available:
                self.explore_mode = not self.explore_mode
                self._tap()
                return "mode"
            if self.fullscreen_rect.collidepoint(position):
                self.fullscreen_enabled = not self.fullscreen_enabled
                self._tap()
                return "fullscreen"
            if self.controls_rect.collidepoint(position):
                self.control_slider_dragging = True
                action = self._set_touch_mode_from_x(position[0])
                self._tap()
                return action
            if self.back_rect.collidepoint(position):
                self.settings_open = False
                self.control_slider_dragging = False
                self.music_volume_dragging = False
                self._tap()
                return "back"
            return None

        for index, rect in enumerate(self.main_buttons):
            if rect.collidepoint(position):
                if index == 1 and not self.continue_available:
                    return None
                self.focus_index = index
                action = self._main_action(index)
                if action or self.settings_open or self.armory_open:
                    self._tap()
                return action

        if self.hero_rect.collidepoint(position):
            self._tap()
            return "heroes"
        return None

    def _tap(self):
        if self.assets:
            try:
                self.assets.play("tap")
            except (AttributeError, pygame.error):
                pass

    def _music_track_rect(self):
        return pygame.Rect(self.volume_rect.left + 113, self.volume_rect.centery - 4, 142, 8)

    def _set_music_volume_from_x(self, x):
        track = self._music_track_rect()
        volume = max(0.0, min(1.0, (x - track.left) / max(1, track.width)))
        if abs(volume - self.music_volume) < 0.01:
            return None
        self.music_volume = round(volume, 2)
        return "volume"

    def _cycle_music_volume(self):
        levels = (0.0, 0.1, 0.22, 0.35, 0.5, 0.75, 1.0)
        current = min(range(len(levels)), key=lambda idx: abs(levels[idx] - self.music_volume))
        self.music_volume = levels[(current + 1) % len(levels)]
        return "volume"

    def _mode_track_rect(self):
        return pygame.Rect(self.controls_rect.left + 145, self.controls_rect.centery - 4, 132, 8)

    def _set_touch_mode_from_x(self, x):
        # Phones need the on-screen gamepad; disabling it would leave a touch-
        # only player without movement or combat input.
        if self.touch_controls_locked:
            changed = not self.touch_controls_enabled
            self.touch_controls_enabled = True
            return "controls" if changed else None
        enabled = x < self._mode_track_rect().centerx
        if enabled == self.touch_controls_enabled:
            return None
        self.touch_controls_enabled = enabled
        return "controls"

    def handle_pointer_motion(self, position):
        if self.settings_open and self.music_volume_dragging:
            return self._set_music_volume_from_x(position[0])
        if self.settings_open and self.control_slider_dragging:
            return self._set_touch_mode_from_x(position[0])
        return None

    def end_pointer(self):
        self.control_slider_dragging = False
        self.music_volume_dragging = False

    def handle_key(self, key):
        if self.intro_active and key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
            self.skip_intro()
            return None

        if self.armory_open:
            if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE, pygame.K_RETURN, pygame.K_SPACE):
                self.armory_open = False
            return None

        if self.settings_open:
            if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.settings_open = False
                self.control_slider_dragging = False
                self.music_volume_dragging = False
                return "back"
            if key in (pygame.K_UP, pygame.K_w):
                self.settings_focus = (self.settings_focus - 1) % 6
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.settings_focus = (self.settings_focus + 1) % 6
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self._tap()
                if self.settings_focus == 0:
                    self.music_enabled = not self.music_enabled
                    return "music"
                if self.settings_focus == 1:
                    return self._cycle_music_volume()
                if self.settings_focus == 2:
                    if not self.continue_available:
                        self.explore_mode = not self.explore_mode
                        return "mode"
                    return None
                if self.settings_focus == 3:
                    self.fullscreen_enabled = not self.fullscreen_enabled
                    return "fullscreen"
                if self.settings_focus == 4:
                    if self.touch_controls_locked:
                        self.touch_controls_enabled = True
                        return "controls"
                    self.touch_controls_enabled = not self.touch_controls_enabled
                    return "controls"
                self.settings_open = False
                self.control_slider_dragging = False
                self.music_volume_dragging = False
                return "back"
            return None

        if key in (pygame.K_UP, pygame.K_w):
            self._move_focus(-1)
        elif key in (pygame.K_DOWN, pygame.K_s):
            self._move_focus(1)
        elif key in (pygame.K_LEFT, pygame.K_a):
            self._move_side(-1)
        elif key in (pygame.K_RIGHT, pygame.K_d):
            self._move_side(1)
        elif key in (pygame.K_h, pygame.K_v):
            return "heroes"
        elif key in (pygame.K_RETURN, pygame.K_SPACE):
            self._tap()
            return self._main_action(self.focus_index)
        return None

    def _move_focus(self, direction):
        columns = ([0, 1, 2], [3, 4, 5, 6])
        current_column = 0 if self.focus_index < 3 else 1
        column = columns[current_column]
        try:
            row = column.index(self.focus_index)
        except ValueError:
            row = 0
        for step in range(1, len(column) + 1):
            candidate = column[(row + direction * step) % len(column)]
            if candidate != 1 or self.continue_available:
                self.focus_index = candidate
                return

    def _move_side(self, direction):
        columns = ([0, 1, 2], [3, 4, 5, 6])
        current_column = 0 if self.focus_index < 3 else 1
        target_column = columns[(current_column + direction) % 2]
        current_y = self.main_buttons[self.focus_index].centery
        candidates = [i for i in target_column if i != 1 or self.continue_available]
        if candidates:
            self.focus_index = min(candidates, key=lambda i: abs(self.main_buttons[i].centery - current_y))

    def _main_action(self, index):
        if index == 0:
            return "play"
        if index == 1:
            return "continue" if self.continue_available else None
        if index == 2:
            return "heroes"
        if index == 3:
            self.armory_open = True
            return None
        if index == 4:
            return "online"
        if index == 5:
            self.settings_open = True
            self.settings_focus = 0
            return "settings"
        if index == 6:
            return "quit"
        return None

    def draw(self, screen, world=None):
        self._draw_backdrop(screen, world)
        screen.blit(self._scene_layer, (0, 0))
        self._draw_bats(screen)
        self._draw_particles(screen)
        self._draw_lightning(screen)

        if self.intro_active:
            self._draw_intro(screen)
        else:
            self._draw_knight(screen, 255)
            self._draw_title(screen)
            self._draw_main_buttons(screen)
            self._draw_footer(screen)

        if self.settings_open:
            self._draw_settings(screen)
        elif self.armory_open:
            self._draw_armory(screen)

    def _draw_intro(self, screen):
        # Reveal the game's actual forest/castle backdrop from black first.
        black_alpha = round(255 * (1.0 - self._ease(self.intro_elapsed / 1.35)))
        if black_alpha > 0:
            self._intro_shade.fill((0, 0, 0, black_alpha))
            screen.blit(self._intro_shade, (0, 0))

        hero_alpha = round(255 * self._ease((self.intro_elapsed - 1.15) / 1.75))
        if hero_alpha:
            self._draw_knight(screen, hero_alpha)

        title_alpha = round(255 * self._ease((self.intro_elapsed - 2.35) / 1.15))
        if title_alpha:
            self._draw_layer(self._title_layer, screen, title_alpha,
                             lambda target: self._draw_title(target, shift_y=round((1 - title_alpha / 255) * 12)))

        buttons_alpha = round(255 * self._ease((self.intro_elapsed - 3.8) / 1.05))
        if buttons_alpha:
            self._draw_layer(
                self._buttons_layer, screen, buttons_alpha,
                lambda target: (self._draw_main_buttons(target, shift_y=round((1 - buttons_alpha / 255) * 12)),
                                self._draw_footer(target)),
            )

        # The footer appears with the buttons at 3.8s. Hide this prompt before
        # it can occupy the same bottom line as the footer hints.
        if 0.35 < self.intro_elapsed < 3.65:
            prompt_text = ("TAP ANYWHERE TO SKIP INTRO" if self.touch_controls_locked else
                           "PRESS ENTER / SPACE / ESC TO SKIP INTRO")
            prompt_text = self._fit_text(prompt_text, self.micro_font, WIDTH - 36)
            prompt = self.micro_font.render(prompt_text, True, (220, 208, 179))
            shadow = self.micro_font.render(prompt_text, True, (12, 16, 24))
            x = WIDTH - prompt.get_width() - 18
            y = HEIGHT - 22
            screen.blit(shadow, (x + 2, y + 2))
            screen.blit(prompt, (x, y))

    @staticmethod
    def _draw_layer(layer, screen, alpha, draw_callback):
        layer.set_alpha(None)
        layer.fill((0, 0, 0, 0))
        draw_callback(layer)
        layer.set_alpha(max(0, min(255, int(alpha))))
        screen.blit(layer, (0, 0))
        layer.set_alpha(None)

    def _draw_backdrop(self, screen, world):
        if world is not None:
            world.draw_background(screen, 0)
        else:
            top, bottom = (14, 22, 42), (39, 57, 75)
            for y in range(0, HEIGHT, 8):
                amount = y / HEIGHT
                color = tuple(round(top[i] + (bottom[i] - top[i]) * amount) for i in range(3))
                pygame.draw.rect(screen, color, (0, y, WIDTH, 8))
        screen.blit(self._backdrop_veil, (0, 0))

    def _build_pixel_moon_scene(self):
        """Create a small pixel-grid moon/castle accent that fits the game's art."""
        scale = 4
        scene = pygame.Surface((WIDTH // scale, HEIGHT // scale), pygame.SRCALPHA)
        # Low-contrast halo then the blocky crimson moon.
        pygame.draw.circle(scene, (101, 27, 46, 38), (WIDTH // (2 * scale), 36), 27)
        pygame.draw.circle(scene, (132, 29, 53, 108), (WIDTH // (2 * scale), 36), 21)
        pygame.draw.circle(scene, (192, 55, 72, 138), (WIDTH // (2 * scale), 36), 18)
        pygame.draw.circle(scene, (118, 26, 47, 135), (WIDTH // (2 * scale), 36), 14)
        for x, y, w, h, shade in (
            (106, 25, 4, 2, (225, 86, 91, 80)), (125, 30, 3, 2, (219, 74, 83, 80)),
            (112, 39, 5, 2, (222, 78, 83, 75)), (121, 43, 3, 2, (92, 20, 37, 135)),
            (101, 35, 3, 3, (97, 22, 39, 150)), (132, 39, 2, 4, (97, 22, 39, 150)),
        ):
            pygame.draw.rect(scene, shade, (x, y, w, h))

        # Castle silhouette: coarse rectangles and stepped roofs, not painted art.
        stone = (9, 15, 27, 175)
        roof = (12, 19, 32, 195)
        pygame.draw.rect(scene, stone, (87, 47, 16, 26))
        pygame.draw.rect(scene, roof, (85, 43, 20, 5))
        pygame.draw.rect(scene, roof, (88, 39, 3, 4))
        pygame.draw.rect(scene, roof, (95, 39, 3, 4))
        pygame.draw.rect(scene, stone, (103, 42, 13, 31))
        pygame.draw.rect(scene, roof, (101, 38, 17, 5))
        pygame.draw.rect(scene, roof, (106, 32, 3, 6))
        pygame.draw.rect(scene, roof, (112, 35, 3, 3))
        pygame.draw.rect(scene, stone, (116, 48, 19, 25))
        pygame.draw.rect(scene, roof, (114, 44, 23, 5))
        pygame.draw.rect(scene, roof, (119, 39, 3, 5))
        pygame.draw.rect(scene, roof, (127, 41, 3, 3))
        pygame.draw.rect(scene, stone, (134, 54, 12, 19))
        pygame.draw.rect(scene, roof, (132, 50, 16, 5))
        pygame.draw.rect(scene, (29, 24, 38, 190), (101, 56, 3, 5))
        pygame.draw.rect(scene, (29, 24, 38, 190), (112, 59, 3, 5))
        pygame.draw.rect(scene, (29, 24, 38, 190), (125, 57, 3, 5))
        # Bridge / battlement silhouette keeps the center grounded.
        pygame.draw.rect(scene, (8, 13, 24, 155), (78, 70, 77, 3))
        pygame.draw.rect(scene, (8, 13, 24, 155), (84, 73, 3, 7))
        pygame.draw.rect(scene, (8, 13, 24, 155), (103, 73, 3, 7))
        pygame.draw.rect(scene, (8, 13, 24, 155), (128, 73, 3, 7))
        pygame.draw.rect(scene, (8, 13, 24, 155), (147, 73, 3, 7))
        return pygame.transform.scale(scene, (WIDTH, HEIGHT))

    def _draw_title(self, screen, shift_y=0):
        title = "PIXEL KNIGHT"
        title_img = self.title_font.render(title, True, (228, 220, 190))
        if title_img.get_width() > WIDTH - 40:
            target_w = WIDTH - 40
            title_img = pygame.transform.smoothscale(title_img, (target_w, title_img.get_height()))
        title_x = WIDTH // 2 - title_img.get_width() // 2
        title_y = 18 + shift_y
        shadow = self.title_font.render(title, True, (8, 13, 25))
        if shadow.get_size() != title_img.get_size():
            shadow = pygame.transform.smoothscale(shadow, title_img.get_size())
        screen.blit(shadow, (title_x + 4, title_y + 4))
        screen.blit(title_img, (title_x, title_y))
        # Thin pixel rails and a central diamond echo the game's relic UI.
        sub_text = self._fit_text("THE FORGOTTEN FOREST", self.font, WIDTH - 48)
        sub = self.font.render(sub_text, True, (172, 191, 196))
        screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 82 + shift_y)))
        line_y = 105 + shift_y
        pygame.draw.line(screen, (113, 133, 145), (347, line_y), (436, line_y), 2)
        pygame.draw.line(screen, (113, 133, 145), (524, line_y), (613, line_y), 2)
        pygame.draw.polygon(screen, (203, 162, 88), ((480, line_y - 7), (487, line_y), (480, line_y + 7), (473, line_y)))
        pygame.draw.rect(screen, (42, 54, 68), (478, line_y - 2, 4, 4))
        pygame.draw.rect(screen, (155, 52, 65), (335, line_y - 2, 5, 5))
        pygame.draw.rect(screen, (155, 52, 65), (620, line_y - 2, 5, 5))

    def _draw_main_buttons(self, screen, shift_y=0):
        mouse = pygame.mouse.get_pos()
        for index, (rect, label) in enumerate(zip(self.main_buttons, self.main_labels)):
            moved = rect.move(0, shift_y)
            enabled = index != 1 or self.continue_available
            hover_amount = self.button_hover[index]
            self._draw_button(
                screen,
                moved,
                label,
                active=(hover_amount > 0.06),
                enabled=enabled,
                hover_amount=hover_amount,
            )

    def _draw_footer(self, screen):
        panel = pygame.Rect(350, 467, 260, 43)
        pygame.draw.rect(screen, (7, 12, 21), panel.move(3, 4))
        pygame.draw.rect(screen, (51, 65, 78), panel)
        pygame.draw.rect(screen, (147, 132, 98), panel.inflate(-4, -4), 1)
        pygame.draw.rect(screen, (157, 52, 64), (panel.left + 7, panel.top + 8, 3, panel.height - 16))
        title = self.micro_font.render("THE FALLEN KINGDOM", True, (226, 204, 160))
        screen.blit(title, title.get_rect(center=(panel.centerx, panel.top + 15)))
        sub = self.micro_font.render("A DARK FANTASY QUEST", True, (149, 167, 177))
        screen.blit(sub, sub.get_rect(center=(panel.centerx, panel.top + 31)))
        if self.touch_controls_locked:
            hint_left_text = "TAP A MENU OPTION TO PLAY"
            hint_right_text = "TAP THE KNIGHT TO CHOOSE A HERO"
        else:
            hint_left_text = "UP / DOWN  SELECT     ENTER  CONFIRM"
            hint_right_text = "CLICK THE KNIGHT TO CHOOSE A HERO"
        hint_left = self.micro_font.render(hint_left_text, True, (165, 179, 187))
        screen.blit(hint_left, (18, HEIGHT - hint_left.get_height() - 7))
        hint_right = self.micro_font.render(hint_right_text, True, (165, 179, 187))
        screen.blit(hint_right, (WIDTH - hint_right.get_width() - 18, HEIGHT - hint_right.get_height() - 7))

    def _draw_settings(self, screen):
        self._modal_shade.fill((4, 8, 18, 195))
        screen.blit(self._modal_shade, (0, 0))
        panel = pygame.Rect(286, 78, 388, 396)
        self._draw_panel(screen, panel, highlighted=True)
        self._center(screen, self.title_font, "SETTINGS", 112, (226, 211, 173), shadow=True)
        sub = self.micro_font.render("CUSTOMIZE YOUR JOURNEY", True, (157, 179, 188))
        screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 150)))
        mouse = pygame.mouse.get_pos()
        self._draw_button(screen, self.music_rect,
                          "MUSIC   [ ON ]" if self.music_enabled else "MUSIC   [ OFF ]",
                          active=(self.settings_focus == 0 or self.music_rect.collidepoint(mouse)))
        self._draw_volume_slider(screen, mouse)
        explore_locked = self.continue_available
        explore_label = ("EXPLORE   [ LOCKED ]" if explore_locked else
                         "EXPLORE   [ ON ]" if self.explore_mode else "EXPLORE   [ OFF ]")
        self._draw_button(screen, self.explore_rect, explore_label,
                          active=(self.settings_focus == 2 or self.explore_rect.collidepoint(mouse)),
                          enabled=not explore_locked)
        self._draw_button(screen, self.fullscreen_rect,
                          "FULLSCREEN   [ ON ]" if self.fullscreen_enabled else "FULLSCREEN   [ OFF ]",
                          active=(self.settings_focus == 3 or self.fullscreen_rect.collidepoint(mouse)))
        self._draw_mode_slider(screen, mouse)
        self._draw_button(screen, self.back_rect, "BACK TO MENU",
                          active=(self.settings_focus == 5 or self.back_rect.collidepoint(mouse)))
        hint_text = ("TOUCH TO CHANGE OPTIONS   •   BACK TO MENU" if self.touch_controls_locked else
                     "F11  TOGGLE FULLSCREEN     ESC  RETURN")
        hint = self.micro_font.render(hint_text, True, (164, 178, 187))
        screen.blit(hint, hint.get_rect(center=(WIDTH // 2, 451)))

    def _draw_armory(self, screen):
        self._modal_shade.fill((4, 8, 18, 200))
        screen.blit(self._modal_shade, (0, 0))
        self._draw_panel(screen, self.armory_panel, highlighted=True)
        self._center(screen, self.title_font, "ARMORY", 151, (226, 211, 173), shadow=True)
        sub = self.micro_font.render("TRAVELER'S SHOP UPGRADE CATALOGUE", True, (157, 179, 188))
        screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 185)))

        mouse = pygame.mouse.get_pos()
        for index, (key, name, cost, descriptions) in enumerate(ItemShop.ITEMS):
            rect = self.armory_cards[index]
            self._draw_panel(screen, rect, highlighted=rect.collidepoint(mouse))
            title = self.micro_font.render(name, True, (230, 207, 160))
            screen.blit(title, title.get_rect(center=(rect.centerx, rect.top + 19)))
            lines = []
            for sentence in descriptions:
                lines.extend(self._wrap_text(sentence, self.micro_font, rect.width - 18))
            y = rect.top + 43
            for line in lines[:3]:
                image = self.micro_font.render(line, True, (175, 192, 197))
                screen.blit(image, image.get_rect(center=(rect.centerx, y)))
                y += 17
            cost_img = self.micro_font.render(f"COST  {cost} COINS*", True, (213, 166, 98))
            screen.blit(cost_img, cost_img.get_rect(center=(rect.centerx, rect.bottom - 15)))

        note = self.micro_font.render("*WARD CHARM MAY ALSO USE A BOSS RELIC", True, (157, 170, 178))
        screen.blit(note, note.get_rect(center=(WIDTH // 2, 356)))
        self._draw_button(screen, self.armory_back_rect, "BACK TO MENU",
                          active=self.armory_back_rect.collidepoint(mouse))
        note2 = self.micro_font.render("UPGRADES ARE PURCHASED BETWEEN STAGES", True, (157, 170, 178))
        screen.blit(note2, note2.get_rect(center=(WIDTH // 2, 423)))

    def _draw_volume_slider(self, screen, mouse):
        rect = self.volume_rect
        active = self.settings_focus == 1 or rect.collidepoint(mouse)
        self._draw_panel(screen, rect, highlighted=active)
        label = self.micro_font.render("VOLUME", True, (214, 211, 190))
        screen.blit(label, (rect.left + 10, rect.centery - label.get_height() // 2))
        track = self._music_track_rect()
        pygame.draw.rect(screen, (9, 14, 22), track)
        pygame.draw.rect(screen, (91, 110, 122), track, 1)
        inner = track.inflate(-2, -2)
        inner.width = round(inner.width * self.music_volume)
        if inner.width > 0:
            pygame.draw.rect(screen, (166, 61, 72) if active else (121, 148, 159), inner)
        knob_x = track.left + round(track.width * self.music_volume)
        pygame.draw.rect(screen, (226, 195, 145), (knob_x - 3, track.centery - 5, 6, 10))
        pct = self.micro_font.render(f"{round(self.music_volume * 100):02d}%", True, (227, 212, 180))
        screen.blit(pct, (rect.right - pct.get_width() - 9, rect.centery - pct.get_height() // 2))

    def _draw_mode_slider(self, screen, mouse):
        rect = self.controls_rect
        self._draw_panel(screen, rect, highlighted=(self.settings_focus == 4 or rect.collidepoint(mouse)))
        label = self.micro_font.render("TOUCH CONTROLS", True, (214, 211, 190))
        screen.blit(label, (rect.left + 10, rect.centery - label.get_height() // 2))
        if self.touch_controls_locked:
            status = self.micro_font.render("ON  •  PHONE MODE", True, (222, 200, 155))
            screen.blit(status, (rect.right - status.get_width() - 10,
                                 rect.centery - status.get_height() // 2))
            return
        track = self._mode_track_rect()
        pygame.draw.rect(screen, (9, 14, 22), track)
        pygame.draw.rect(screen, (91, 110, 122), track, 1)
        touch_x = track.left + 5
        pc_x = track.right - 5
        knob_x = touch_x if self.touch_controls_enabled else pc_x
        touch_color = (222, 200, 155) if self.touch_controls_enabled else (121, 141, 153)
        pc_color = (121, 141, 153) if self.touch_controls_enabled else (222, 200, 155)
        touch_label = self.micro_font.render("TOUCH", True, touch_color)
        pc_label = self.micro_font.render("PC", True, pc_color)
        screen.blit(touch_label, (rect.left + 131, rect.bottom - 14))
        screen.blit(pc_label, (rect.left + 260, rect.bottom - 14))
        pygame.draw.rect(screen, (217, 184, 124), (knob_x - 4, track.centery - 5, 8, 10))

    def _draw_knight(self, screen, alpha=255):
        frames = self._get_hero_frames()
        if not frames:
            return
        index = int(self.anim_time * 3.2) % len(frames)
        frame = frames[index]
        target_h = 228
        target_w = max(1, round(frame.get_width() * target_h / max(1, frame.get_height())))
        scaled = pygame.transform.scale(frame, (target_w, target_h))
        bob = round(math.sin(self.anim_time * 2.1) * 2)
        center_x = WIDTH // 2
        ground_y = 440

        hero_layer = self._hero_layer
        hero_layer.set_alpha(None)
        hero_layer.fill((0, 0, 0, 0))
        # A restrained halo gives separation but retains hard pixel edges.
        halo = self._hero_halo
        halo.fill((0, 0, 0, 0))
        pulse = 15 + round(4 * (math.sin(self.anim_time * 1.8) + 1))
        pygame.draw.circle(halo, (143, 48, 62, pulse), (88, 88), 72)
        hero_layer.blit(halo, halo.get_rect(center=(center_x, ground_y - 123 + bob)))
        # Little stepped stone dais, kept in the same blocky palette as level art.
        pygame.draw.polygon(hero_layer, (15, 23, 33, 245),
                            ((center_x - 106, ground_y - 6), (center_x - 88, ground_y - 19),
                             (center_x + 87, ground_y - 19), (center_x + 106, ground_y - 6)))
        pygame.draw.rect(hero_layer, (51, 67, 77, 245), (center_x - 88, ground_y - 19, 175, 4))
        pygame.draw.rect(hero_layer, (157, 125, 79, 230), (center_x - 76, ground_y - 15, 152, 2))
        hero_layer.blit(scaled, scaled.get_rect(midbottom=(center_x, ground_y - 17 + bob)))
        if alpha < 255:
            hero_layer.set_alpha(max(0, min(255, int(alpha))))
        screen.blit(hero_layer, (0, 0))
        hero_layer.set_alpha(None)

    def _get_hero_frames(self):
        if not self.assets:
            return []
        if self._last_hero_id != self.selected_hero:
            self._last_hero_id = self.selected_hero
            self._hero_idle_frames = []
            try:
                from hero_sprites import create_hero_frames
                frames = create_hero_frames(self.assets, self.selected_hero).get("idle") or []
                self._hero_idle_frames = list(frames)
            except (KeyError, AttributeError, IndexError, pygame.error):
                self._hero_idle_frames = []
        return self._hero_idle_frames

    def _draw_bats(self, screen):
        """Small pixel silhouettes drift behind the central hero."""
        for index, speed in enumerate((18.0, 25.0, 15.0, 21.0)):
            x = int((index * 255 + self.anim_time * speed) % (WIDTH + 48)) - 24
            y = 128 + round(math.sin(self.anim_time * 0.9 + index * 1.8) * 13)
            color = (7, 12, 23)
            if int(self.anim_time * 3.0 + index) % 2:
                points = ((x - 10, y - 3), (x - 5, y), (x - 2, y + 3), (x, y),
                          (x + 2, y + 3), (x + 5, y), (x + 10, y - 3),
                          (x + 5, y + 2), (x, y + 3), (x - 5, y + 2))
            else:
                points = ((x - 10, y + 2), (x - 5, y - 1), (x - 2, y + 2), (x, y),
                          (x + 2, y + 2), (x + 5, y - 1), (x + 10, y + 2),
                          (x + 5, y + 3), (x, y + 4), (x - 5, y + 3))
            pygame.draw.polygon(screen, color, points)

    def _draw_lightning(self, screen):
        """Occasional, restrained lightning keeps the title screen alive."""
        if self.lightning_flash <= 0:
            return
        fade = self.lightning_flash / 0.12
        flash = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        flash.fill((112, 139, 171, round(18 * fade)))
        screen.blit(flash, (0, 0))
        bolt = ((842, 28), (830, 57), (839, 57), (819, 91), (833, 83), (826, 111))
        color = (169, 196, 217)
        for a, b in zip(bolt, bolt[1:]):
            pygame.draw.line(screen, color, a, b, 2)
        pygame.draw.line(screen, (112, 150, 178), (839, 57), (850, 73), 1)

    def _draw_particles(self, screen):
        for x, y, _drift, _speed, size, color in self.particles:
            pygame.draw.rect(screen, color, (round(x), round(y), size, size))
            if size > 1 and color[0] > 170:
                pygame.draw.rect(screen, (236, 143, 103), (round(x), round(y) + size, 1, 2))

    def _draw_button(self, screen, rect, label, active=False, enabled=True, hover_amount=None):
        # Sharp rectangular edges and a one-pixel glint preserve the game's pixel UI.
        if hover_amount is None:
            hover_amount = 1.0 if active else 0.0
        hover_amount = max(0.0, min(1.0, hover_amount))
        active = active or hover_amount > 0.06
        pygame.draw.rect(screen, (3, 7, 14), rect.move(4, 5))
        base = (28, 39, 53) if enabled else (29, 33, 41)
        if active and enabled:
            base = (61, 36, 47)
        pygame.draw.rect(screen, (71, 88, 101), rect)
        pygame.draw.rect(screen, base, rect.inflate(-4, -4))
        outline = (190, 74, 78) if active and enabled else (123, 145, 155)
        if not enabled:
            outline = (66, 76, 84)
        pygame.draw.rect(screen, outline, rect.inflate(-8, -8), 1)
        pygame.draw.line(screen, (202, 170, 112) if active else (78, 104, 119),
                         (rect.left + 8, rect.top + 4), (rect.right - 8, rect.top + 4), 1)
        if active and enabled:
            rail_len = max(1, round((rect.width - 24) * hover_amount))
            pygame.draw.line(screen, (190, 65, 76), (rect.left + 12, rect.top + 4),
                             (rect.left + 12 + rail_len, rect.top + 4), 1)
        # A tiny crimson indicator replaces large glows.
        accent_w = 2 + round(2 * hover_amount) if active and enabled else 3
        pygame.draw.rect(screen, (190, 65, 76) if active and enabled else (66, 87, 100),
                         (rect.left + 7, rect.centery - 4, accent_w, 8))
        color = (239, 226, 195) if enabled else (111, 123, 129)
        label_image = self.font.render(label, True, color)
        screen.blit(label_image, label_image.get_rect(center=rect.center))
        if active and enabled:
            pygame.draw.rect(screen, (224, 169, 105), rect.inflate(2, 2), 1)

    def _draw_panel(self, screen, rect, highlighted=False):
        pygame.draw.rect(screen, (3, 7, 14), rect.move(4, 5))
        pygame.draw.rect(screen, (74, 90, 102), rect)
        fill = (23, 31, 44) if not highlighted else (42, 34, 43)
        pygame.draw.rect(screen, fill, rect.inflate(-4, -4))
        pygame.draw.rect(screen, (133, 151, 157), rect.inflate(-9, -9), 1)
        pygame.draw.line(screen, (191, 148, 91), (rect.left + 8, rect.top + 5),
                         (rect.right - 8, rect.top + 5), 1)
        for x, y in ((rect.left + 5, rect.top + 5), (rect.right - 9, rect.top + 5),
                     (rect.left + 5, rect.bottom - 9), (rect.right - 9, rect.bottom - 9)):
            pygame.draw.rect(screen, (181, 63, 75) if highlighted else (162, 139, 100), (x, y, 4, 4))

    @staticmethod
    def _draw_rune_line(screen, y):
        pygame.draw.line(screen, (111, 105, 77), (52, y), (130, y), 2)
        pygame.draw.line(screen, (111, 105, 77), (226, y), (304, y), 2)
        pygame.draw.rect(screen, GOLD, (43, y - 3, 6, 6))
        pygame.draw.rect(screen, GOLD, (307, y - 3, 6, 6))
        pygame.draw.polygon(screen, GOLD, [(178, y - 7), (185, y), (178, y + 7), (171, y)])
        pygame.draw.rect(screen, (52, 61, 63), (176, y - 2, 4, 4))

    @staticmethod
    def _center(screen, font, text, y, color, shadow=False):
        image = font.render(text, True, color)
        x = WIDTH // 2 - image.get_width() // 2
        top = y - image.get_height() // 2
        if shadow:
            shade = font.render(text, True, (5, 9, 17))
            screen.blit(shade, (x + 3, top + 3))
        screen.blit(image, (x, top))

    @staticmethod
    def _fit_text(text, font, max_width):
        if font.size(text)[0] <= max_width:
            return text
        value = text
        while value and font.size(value + "…")[0] > max_width:
            value = value[:-1]
        return value.rstrip() + "…" if value else "…"

    @staticmethod
    def _wrap_text(text, font, max_width):
        lines = []
        current = ""
        for word in text.split():
            candidate = f"{current} {word}".strip()
            if current and font.size(candidate)[0] > max_width:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)
        return lines
