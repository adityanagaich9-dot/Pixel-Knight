import asyncio
import pygame
from game import Game


async def main():
    pygame.init()
    try:
        await Game().run_async()
    finally:
        pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())