"""Between-stage merchant screen and purchase buttons."""

import pygame

from settings import WIDTH, HEIGHT, GOLD, WHITE


class ItemShop:
    ITEMS = (
        ("heart", "HEART TONIC", 6, ("Restore 1 lost heart.", "Heal before next stage.")),
        ("speed", "SWIFT RUNE", 10, ("Run faster everywhere.", "Stacks 3 times.")),
        ("ward", "WARD CHARM", 8, ("Block 1 enemy hit.", "Carry 3 charms.")),
    )

    def __init__(self, font, small_font, title_font):
        self.font = font
        self.small_font = small_font
        self.title_font = title_font
        self.card_rects = [pygame.Rect(86 + index * 268, 184, 252, 196) for index in range(3)]
        self.continue_rect = pygame.Rect(WIDTH // 2 - 128, 420, 256, 50)
        self.message = "Choose one or more upgrades, or continue onward."
        self.message_timer = 0.0

    def handle_click(self, position):
        if self.continue_rect.collidepoint(position):
            return "continue"
        for index, rect in enumerate(self.card_rects):
            if rect.collidepoint(position):
                return self.ITEMS[index][0]
        return None

    def show_message(self, message):
        self.message = message
        self.message_timer = 2.2

    def draw(self, screen, game):
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((12, 13, 21, 205))
        screen.blit(shade, (0, 0))

        panel = pygame.Rect(40, 28, 880, 490)
        self._panel(screen, panel, bright=True)
        self._center(screen, self.title_font, "TRAVELER'S SHOP", 78, GOLD)
        self._center(screen, self.small_font, "A REST BEFORE THE NEXT STAGE", 119, (211, 197, 154))
        funds = self.font.render(
            f"COINS  {game.player.coins:02d}     BOSS RELICS  {game.boss_shards:02d}",
            True, (255, 220, 117),
        )
        screen.blit(funds, (WIDTH // 2 - funds.get_width() // 2, 145))

        for index, (key, name, cost, description) in enumerate(self.ITEMS):
            rect = self.card_rects[index]
            self._panel(screen, rect, bright=rect.collidepoint(pygame.mouse.get_pos()))
            title = self.font.render(name, True, GOLD)
            screen.blit(title, (rect.centerx - title.get_width() // 2, rect.top + 18))
            # Keep the description compact so it can never collide with the cost/state text.
            desc_font = getattr(game, "micro_font", self.small_font)
            description_y = rect.top + 58
            for line in description:
                wrapped = self._wrap_text(line, desc_font, rect.width - 30)
                for wrapped_line in wrapped:
                    image = desc_font.render(wrapped_line, True, WHITE)
                    screen.blit(image, (rect.centerx - image.get_width() // 2, description_y))
                    description_y += desc_font.get_linesize() + 2

            # The state/cost line gets its own reserved area above the BUY button.
            detail = self._item_state(key, cost, game)
            detail_image = desc_font.render(detail, True, (209, 185, 131))
            detail_y = rect.bottom - 67
            screen.blit(detail_image, (rect.centerx - detail_image.get_width() // 2, detail_y))
            buy = pygame.Rect(rect.left + 22, rect.bottom - 43, rect.width - 44, 31)
            self._panel(screen, buy, bright=buy.collidepoint(pygame.mouse.get_pos()))
            label = self.small_font.render(f"BUY  [{index + 1}]", True, WHITE)
            screen.blit(label, (buy.centerx - label.get_width() // 2, buy.centery - label.get_height() // 2))

        if self.message_timer > 0:
            color = (255, 218, 123)
        else:
            color = (192, 193, 176)
        self._center(screen, self.small_font, self.message, 397, color)
        self._panel(screen, self.continue_rect, bright=self.continue_rect.collidepoint(pygame.mouse.get_pos()))
        self._center_in_rect(screen, self.font, "CONTINUE", self.continue_rect, WHITE)
        self._center(screen, self.small_font, "1 / 2 / 3 TO BUY     ENTER TO LEAVE", 492, (192, 193, 176))

    @staticmethod
    def _wrap_text(text, font, max_width):
        """Wrap shop copy to stay inside its card at every supported font."""
        lines = []
        current = ""
        for word in text.split():
            candidate = f"{current} {word}".strip()
            if current and font.size(candidate)[0] > max_width:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)
        return lines

    def _item_state(self, key, cost, game):
        if key == "heart" and game.player.health >= game.max_health:
            return "HEALTH FULL"
        if key == "speed" and game.speed_bonus >= 54:
            return "MAXED OUT"
        if key == "ward" and game.shield_charges >= 3:
            return "MAXED OUT"
        if key == "ward" and game.boss_shards > 0:
            return "COST  1 BOSS RELIC"
        return f"COST  {cost} COINS"

    @staticmethod
    def _panel(screen, rect, bright=False):
        # Match the redesigned title menu: hard pixel edges, dark steel, and relic trim.
        fill = (48, 34, 45) if bright else (19, 28, 41)
        pygame.draw.rect(screen, (3, 7, 14), rect.move(4, 5))
        pygame.draw.rect(screen, (70, 88, 103), rect)
        pygame.draw.rect(screen, fill, rect.inflate(-5, -5))
        pygame.draw.rect(screen, (129, 147, 156), rect.inflate(-10, -10), 1)
        pygame.draw.line(screen, (192, 151, 96), (rect.left + 8, rect.top + 5),
                         (rect.right - 8, rect.top + 5), 1)
        pygame.draw.rect(screen, (157, 51, 66) if bright else (132, 69, 75),
                         (rect.left + 6, rect.top + 7, 3, max(4, rect.height - 14)))

    @staticmethod
    def _center(screen, font, text, y, color):
        image = font.render(text, True, color)
        screen.blit(image, (WIDTH // 2 - image.get_width() // 2, y - image.get_height() // 2))

    @staticmethod
    def _center_in_rect(screen, font, text, rect, color):
        image = font.render(text, True, color)
        screen.blit(image, (rect.centerx - image.get_width() // 2, rect.centery - image.get_height() // 2))
